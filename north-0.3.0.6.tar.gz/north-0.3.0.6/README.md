#North Robotics north Package

Install with:

> pip install ./path/to/this/package.tar.gz