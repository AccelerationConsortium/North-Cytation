from collections import deque
from inspect import isgeneratorfunction  # all tasks must be generators, used to determine if Callable needs promotion
from sortedcontainers import SortedList
from typing import Any, Callable, Dict, Iterable, List, Optional, Union

from time import perf_counter


class Task:

    def __init__(self, task_id: int, func: Callable, max_t: Any = 1, priority: int = 1, cond: Callable = None):
        """
        Represents a function registered with the scheduler. Users should not instantiate a Task object directly, but
        should instead decorate any functions to be treated as Tasks with the @task(...) decorator or the create_task
        function.

        Parameters
        ----------
        task_id: int
            used to id task for visualization
        func: Callable
            The function which contains the task behavior
        max_t: Any
            The maximum time the function will take to execute in seconds (float), or 'auto' to find via sim
        priority: int
            The task priority relative to other tasks, larger int = higher priority
        cond: Callable
            The function which must return True in order for the task to run
        """

        self.name = func.__name__
        self.task_id = task_id
        self.func = func
        self.max_t = max_t
        self.priority = priority
        self.cond = cond
        self.gen_func = func if isgeneratorfunction(func) else self._make_gen(func)

    def __repr__(self):
        return f'Task {self.task_id}: {self.name}'

    @staticmethod
    def _make_gen(func):
        """
        Converts a function to a generator function

        Parameters
        ----------
        func: Callable
            The function to convert

        Returns
        -------
        A Generator function

        """

        # todo: consider functools.wraps(func)
        def wrapped(*args, **kwargs):
            yield func(*args, **kwargs)

        return wrapped


class TaskInstance:

    def __init__(self, T: Task, args_list: Optional[List[Any]] = None, kwargs_dict: Optional[Dict[str, Any]] = None):
        """
        Represents a single call to a Task function, used internally by the Scheduler.

        Parameters
        ----------
        T: Task
            Makes an instance of this Task
        args_list: List[Any]
            The positional args to pass to the Task function
        kwargs_dict: Dict[str, Any]
            A dict of keyword args {keyword, argument} to pass to the Task function
        """
        self.task = T
        self.cond = T.cond
        self.max_t = T.max_t
        self.priority = T.priority
        self.resume_t = None
        self._desired_resume_t = None

        self.args = [] if args_list is None else args_list
        if not isinstance(self.args, Iterable):
            self.args = [self.args]
        self.kwargs = {} if kwargs_dict is None else kwargs_dict

        self.gen = self.gen_func(*self.args, **self.kwargs)

        sched_print(f'Created new task instance of {self} with args: {self.args} and {self.kwargs}')

    def __next__(self):
        self._desired_resume_t = None
        self.resume_t = None
        return next(self.gen)

    def __repr__(self):
        return self.name

    def check_condition(self):
        return self.cond() if self.cond is not None else True

    @property
    def name(self):
        return self.task.name

    @property
    def task_id(self):
        return self.task.task_id

    @property
    def func(self):
        return self.task.func

    @property
    def gen_func(self):
        return self.task.gen_func

    @ property
    def end_t(self):
        return self.resume_t + self.max_t

    @property
    def desired_resume_t(self):
        return self._desired_resume_t

    @desired_resume_t.setter
    def desired_resume_t(self, new_desired_resume_t):
        self._desired_resume_t = new_desired_resume_t
        self.resume_t = new_desired_resume_t  # both times start off the same, and resume_t gets pushed if required


class Batch:
    #  todo: make threadsafe, maybe using semaphore class. For now not using it because don't want acq() to block

    def __init__(self, n: int=1):
        """
        A simple implementation of a counted semaphore. Could be used to manage how many instances of a task chain may
        be active at a time.

        Parameters
        ----------
        n: int
            The number of available slots in the batch
        """
        self._slots = n

    def acquire(self):
        """
        Check if there are any slots available in the batch and, if so, take one. Must call Batch.release() later to
        free the slot.

        Returns
        -------
        bool:
            True if the slot was acquired, False if not.
        """

        if self._slots <= 0:
            return False
        self._slots -= 1
        return True

    def release(self):
        """
        Frees a batch slot previously taken.
        """

        self._slots += 1


#############################
#     MODULE CONSTANTS      #
#############################
VERBOSE = False
T_SAFETY_FACTOR = 1.1
POLL_TIME = 1  # second
EARLY_FINISH_TOL = 0.1  # *100%

#############################
#     MODULE PUBLICS        #
#############################
controller = None  # a link to a NorthC9 object, must be set externally for now TODO: link these in higher level class
reschedule_on_early_finish = True
reschedule_on_late_finish  = True

#############################
#     MODULE PRIVATES       #
#############################


def _make_schedule_container():
    return SortedList(key=lambda T: T.resume_t)  # T is type TaskInstance


_schedule = _make_schedule_container()
_bg_q = deque()  # background tasks to run in round-robin as they fit
_registry = {}  # dict of func : Task

_cur_task = None  # the currently executing task, None if none
_running = False  # bool

_next_id = -1
_start_t = 0  # time at which the scheduler was started


def reset_scheduler():
    """
    Clears internal Scheduler data, but does not reset the registry - no need to re-register tasks.
    """
    global _schedule, _bg_q, _cur_task, _running
    _schedule = _make_schedule_container()
    _bg_q = deque()
    _cur_task = None
    _running = False


def sched_print(*args, **kwargs):
    """
    Prints to stdout if Scheduler.VERBOSE = True.

    Parameters
    ----------
    args: Any
        *args passed to builtin print fcn
    kwargs: Any
        **kwargs passed to builtin print fcn
    """
    if VERBOSE:
        print(f'Scheduler ({get_task()}):', end='')
        print(*args, **kwargs)


def _get_time():
    return controller.current_time


def _delay(secs: float):
    """
    :param float secs: Delay for this many seconds
    """
    if secs < 0:
        return

    sched_print(f'Delaying: {secs:.2f}')
    controller.delay(secs)


def _get_next_id(func_name=None):
    global _next_id
    _next_id += 1
    return _next_id


def create_task(func: Callable, *, max_t: Any = 'auto', priority: int = 1, cond: Callable = None):
    """
    Create a Task object and add it to the Scheduler registry.

    Parameters
    ----------
    func: Callable
        The function which performs the task behavior
    max_t: Any
        The maximum time the function will take to execute in seconds (float), or 'auto' to find via sim
    priority: int
        The task priority relative to other tasks, larger int = higher priority
    cond: Callable
        The function which must return True in order for the task to run
    """

    assert isinstance(func, Callable)
    if cond is not None:
        assert isinstance(cond, Callable)

    task_id = _get_next_id()

    if max_t == 'auto':
        max_t = controller._dry_run_func_est_time(func) * T_SAFETY_FACTOR
        print(f"Assigned task {task_id}: {func.__name__} a max_t of {max_t}s")

    _registry[func] = Task(task_id, func, max_t=max_t, priority=priority, cond=cond)
    sched_print(f'Creating task {_registry[func]}')


def get_task():
    """
    Returns
    -------
    int
        The id of the currently exectuting task. -1 if no task is currently running.
    """
    return _cur_task.task_id if _cur_task is not None else -1


# task decorator
# todo: is this the right place for argument defaults?
# todo: should task_decorator and/or create_task be able to add 'default' arguments to a task that can be overwritten
#       when invoking an instance?
def task(*args, max_t: Any = 'auto', priority=1, cond=None):
    """
    A decorator for registering a function as a task with the scheduler. Use as follows:

    @s.task(...)
    def my_task_func(...):
        ...
        return

    Parameters
    ----------
    args: Any
        Used to allow @task syntax (no parens) - ignore. Use KW args only
    max_t: Any
        The maximum time the function will take to execute in seconds (float), or 'auto' to find via sim
    priority: int
        The task priority relative to other tasks, larger int = higher priority
    cond: Callable
        The function which must return True in order for the task to run
    """

    def task_decorator(func):
        create_task(func=func,
                    max_t=max_t,
                    priority=priority,
                    cond=cond)
        return func

    # if @task syntax is used (all default arguments), call decorator and return the func itself
    if args:
        if isinstance(args[0], Callable):
            return task_decorator(args[0])

    # if args are given, return the decorator object
    return task_decorator


def _enqueue_task(T: Task, args_list=None, kwargs_dict=None):
    """
    Converts a Task to a TaskInstance and adds it to the background queue
    :param Task T: the Task to be enqueued
    """

    task_inst = TaskInstance(T, args_list, kwargs_dict)
    _bg_q.append(task_inst)
    sched_print(f'Added {task_inst} to the BG queue')


def _requeue_task(T: TaskInstance):
    """
    Places a TaskInstance at the end of the background queue
    :param TaskInstance T: the task to be requeued
    """
    _bg_q.append(T)
    sched_print(f'Put {T} in the BG queue')


def run():
    """
    Do all the Tasks in the tasklist, including any subtasks they instantiate.
    """

    global _start_t, _running, _cur_task

    from .north_c9 import NorthC9  # for NorthC9 type
    assert isinstance(controller, NorthC9)

    _running = True

    # for i, arg in enumerate(args):
    #     task_bundle = [None, None, None]  # [function, args_list, kwargs_dict]
    #     if not isinstance(arg, Iterable):
    #         task_bundle[0] = arg
    #     else:
    #         for j, e in enumerate(arg):
    #             task_bundle[j] = e
    #     if not isinstance(task_bundle[0], Callable):
    #         raise TypeError(f'Task function in position {i} is not callable')
    #     try:
    #         _enqueue_task(_registry[task_bundle[0]], task_bundle[1], task_bundle[2])
    #     except KeyError:
    #         print(f'Function {i} is not in Task registry - make sure it is decorated with @s.task')

    _start_t = _get_time()
    while _running:
        cur_t = _get_time()

        # try running a scheduled task, or get time of next runnable scheduled task
        if _schedule:
            next_resume_t = _schedule[0].desired_resume_t  # the latest time we can advance to if nothing can run
            idx_to_run = None
            for i, T in enumerate(_schedule):  # iterate over the schedule to find a task that can run (by time/cond)
                if cur_t >= T.desired_resume_t:
                    if T.check_condition():
                        idx_to_run = i
                        break
                else:  # look no further than tasks which want to run at or before current time
                    break

            if idx_to_run is not None:
                T = _schedule[idx_to_run]
                _schedule.remove(T)
                _do(T)
                continue
        else:
            next_resume_t = float('inf')

            ### TODO: if resume_t is None, it makes the calculations below difficult, but can't set to inf?
            ### TODO: need to think through how these changes affect overall scheduling behavior, how/when conditions are rechecked, etc.

        # try running a bg task
        if _bg_q:
            # see if any tasks can be run before the next scheduled task
            idx_to_run = None
            cond_fail = False
            for i, T in enumerate(_bg_q):
                if cur_t + T.max_t < next_resume_t:
                    if T.check_condition():
                        idx_to_run = i
                        break  # found a bg task short enough to finish before next scheduled task with cond==True
                    else:
                        cond_fail = True
            if idx_to_run is not None:
                T = _bg_q[idx_to_run]
                sched_print(f'running {T}')
                _bg_q.remove(T)
                _do(T)
                continue
            else:
                if cond_fail:
                    _delay(POLL_TIME)  # a task could run, but its condition failed. poll again in POLL_TIME
                else:                  # no BG task could fit
                    delay_time = next_resume_t - cur_t
                    if delay_time < 0:  # all due scheduled tasks failed their conditions
                        _delay(POLL_TIME)
                    else:
                        _delay(next_resume_t - cur_t)  # skip ahead to next scheduled task
                continue
        else:  # bg deque is empty
            if not _schedule:  # if no scheduled tasks either, end run
                break
            else:
                delay_time = next_resume_t - cur_t
                if delay_time < 0:  # all due scheduled tasks failed their conditions
                    _delay(POLL_TIME)
                else:
                    _delay(next_resume_t - cur_t)  # skip ahead to next scheduled task

    sched_print(f'No more tasks - schedule finished at time {_get_time() - _start_t}')
    _cur_task = None
    _running = False


def _do(T: TaskInstance):
    """
    Execute a particular task and handle its return/yield logic

    Parameters
    ----------
    T: TaskInstance
        the task to do
    """
    st = _get_time()

    global _cur_task
    _cur_task = T
    pre_max_t = T.max_t

    try:
        result = next(T)
        _cur_task = None
    except StopIteration:
        _cur_task = None
        return

    elapsed = _get_time() - st
    sched_print(f'Executed {T} at {"%.3f" % st} for {"%.3f" % elapsed}s')
    
    if T.desired_resume_t and T.resume_t and (T.resume_t - T.desired_resume_t) > 0.1:
        sched_print(f'{T} was delayed by {T.resume_t - T.desired_resume_t:.1f}s')

    if T.resume_t is None:
        _requeue_task(T)

    if reschedule_on_early_finish and (elapsed * (1 + EARLY_FINISH_TOL)) < pre_max_t:
        _schedule_tasks()
    elif reschedule_on_late_finish and elapsed > pre_max_t:
        _schedule_tasks()


def _schedule_tasks():
    """
    Sort tasks by resume_t, resolving any scheduling conflicts by priority
    """
    fcn_start_t = perf_counter()

    global _schedule

    for T in _schedule:
        T.resume_t = max(T.desired_resume_t, _get_time())  # if desired schedule time has already passed, set it to now

    # must be remade every time since priorities can be mutated at any point
    priority_list = SortedList(key=lambda T: -T.priority, iterable=_schedule)
    new_schedule = _make_schedule_container()

    for T in priority_list:
        for i, placed_task in enumerate(new_schedule):
            if T.resume_t < placed_task.resume_t:  # two cases: resume_t conflicts or not. If not, does end_t conflict?
                if i > 0:
                    if T.resume_t < new_schedule[i - 1].end_t:  # if resume_t conflicts, push back the resume_t til higher priority task is done
                        T.resume_t = new_schedule[i - 1].end_t
                if T.end_t > placed_task.resume_t:  # if end_t conflicts, push the resume_t further back and check next placed task
                    T.resume_t = placed_task.end_t
                else:
                    break

        new_schedule.add(T)

    _schedule = new_schedule

    sched_print(f'Finished scheduling in {perf_counter()-fcn_start_t:.5f}s')


#############################
#     CONTROL FUNCTIONS     #
#############################

def add_task(func: Callable, *, start_in: float = None, args_list: Optional[List[Any]] = None,
             kwargs_dict: Optional[Dict[str, Any]] = None, **kwargs):
    """
    Creates an instance of a Task from the registry and adds it to the scheduler. Any tasks added to the scheduler
    before or during Scheduler.run() will be executed before the Scheduler terminates.

    Parameters
    ----------
    func: Callable
        The function object that corresponds to the task. Should already have been registered with the @task decorator
        or with create_task(...)
    start_in: float
        The number of seconds in which to start the task (ideally, could be delay by a higher priority task)
    args_list: Optional[List[Any]]
        A list of positional arguments to pass to the task [arg0, arg1, ...]
    kwargs_dict: Optional[Dict[str, Any]]
        A dictionary of keyword arguments to pass to the task {'arg_name': val, ...}
    kwargs: Any
         Other keyword arguments for mutating TaskInstance metadata (max_t, priority, etc..), not passed to the task
    """

    # todo: validate arg types (maybe make some module fcns)

    T = TaskInstance(_registry[func], args_list, kwargs_dict)
    T.desired_resume_t = start_in + _get_time() if start_in is not None else None
    _mutate_task_instance(T, **kwargs)

    if T.desired_resume_t is None:
        _requeue_task(T)
        sched_print(f'Added {T} to the background queue')
    else:
        _schedule.add(T)
        _schedule_tasks()
        sched_print(f'Scheduled {T} to resume at: desired {T.desired_resume_t:.2f}, actual {T.resume_t:.2f}')


def edit_task(**kwargs):
    """
    Mutate the currently executing TaskInstance metadata - for TaskInstances that use the yield keyword and will thus
    be automatically readded to the Background Queue.

    Parameters
    ----------
    kwargs: Any
        Keyword arguments for mutating TaskInstance metadata (max_t, priority, etc..)
    """
    _mutate_task_instance(_cur_task, **kwargs)
    _schedule_tasks()  # called after potentially mutating max_times, priorities, etc.


def _mutate_task_instance(T, **kwargs):
    for kw, val in kwargs.items():
        try:
            T.__dict__[kw] = val
        except KeyError:
            raise KeyError(f'"{kw}" is not a property of of task {T}')