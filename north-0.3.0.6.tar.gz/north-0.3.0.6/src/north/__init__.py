"""
The package which contains the public-facing API. The primary tool for users is the `NorthC9` class, which allows for
communication to and from the N9 robot, through the C9 controller.
"""
import logging
from enum import Enum

# ?: bool
# i: int
# B: unsigned byte
# f: float
STEP_HEADER_FMT = 'i??iBiii'  # full format includes: + 'f' * N_AXES  when N_AXES is defined by project
from enum import Enum

SimMateSignal = Enum('SimMateSignal', ['NONE', 'OUTPUT_LOW', 'OUTPUT_HIGH', 'UNCAP', 'CAP'])


def dist(p, q):
    import math
    return math.sqrt(sum((px - qx) ** 2.0 for px, qx in zip(p, q)))


# imports last to avoid cyclical importing (some of the below files depend on the constants above)
import north.n9_kinematics
import north.north_sched as Scheduler
from north.north_c9 import NorthC9, ADS1115
from north.n9_cam import NorthCamera
from north.n9_data import NorthData
from north.SparseList import SparseList
from north.simulator import Simulator