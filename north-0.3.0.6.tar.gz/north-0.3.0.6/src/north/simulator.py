"""
Defines the `Simulator` class, which can handle C9 commands and track their result on a set of simulated modules.
"""

import struct
import os
import logging
from pathlib import Path
from collections import defaultdict
from dataclasses import dataclass
from typing import Callable

from random import randint

import math  # for use in sim_inputs expressions
import random  # for use in sim_inputs expressions

import north
import north.n9_kinematics as n9
import north.n9_server as broker
from north.north_c9 import AxisState, NorthC9
from north.north_project import Project, Controller
from north.north_util import clamp
from north import SimMateSignal, SparseList

# TODO: how to handle specific configurations, different home positions, etc. For now, generic..
# TODO: improve error handling of parser
# TODO: convert all args to int after reading

ZERO_STEPS = 0  # readable way for some commands to return 0 steps

pump_speed_codes = [6000, 5600, 5000, 4400, 3800, 3200, 2600, 2200, 2000, 1800, 1600, 1400, 1200, 1000, 800, 600, 400,
                    200, 190, 180, 170, 160, 150, 140, 130, 120, 110, 100, 90, 80, 70, 60, 50, 40, 30, 20, 18, 16, 14,
                    12, 10]


class Simulator:
    CMD_TIME = 0.03

    JS_SLOWDOWN = 20.0  # slow-down factor for joystick control
    JS_INVERT_Z = False

    HOME_VEL = 2000
    HOME_ACCEL = 50000

    MAX_CTS = [None, 42500, 67333, 26200]

    def __init__(self, time_per_step, init_pos=None, sim_inputs=None, proj=None):
        """

        Parameters
        ----------
        time_per_step: float
            Time in seconds per simulated timestep.
        init_pos: list, optional
            Initial position of each axis.
        sim_inputs: list, optional
        proj: Project, optional
        """
        self._time_per_step = float(time_per_step)

        # timeseries is incrementally written to .nsim file, which can be loaded by IDE on-the-fly
        parent_path = Path(os.getcwd())
        self._nsim_path = parent_path.joinpath(f'{parent_path.name}.nsim')

        self._proj = proj if proj is not None else Project(parent_path)
        self._proj.refresh_axis_lookup()
        self._axis_lookup = self._proj.axis_lookup
        self.n_axes = self._proj.num_axes

        if self.n_axes == 0:
            raise RuntimeError(
                "Project has no mapped axes. Don't forget to configure module channels in Project Settings!")
        self.controllers = {c.address: VirtualController(project_controller=c, simulator=self)
                            for c in self._proj.controllers}

        self._last_sent_step = -1

        init_pos = [0 for _ in range(self.n_axes)] if init_pos is None else init_pos
        assert isinstance(init_pos, list)
        assert len(init_pos) == self.n_axes

        # TODO: rethink sim inputs for multi-controller, for now each controller has the same sim_inputs table
        self.sim_inputs = {} if sim_inputs is None else sim_inputs

        # Multiple timeseries are accessible through self._timeseries, depending on sim state #
        # see: _timeseries, start_dryrun, end_dryrun #
        # self.current_step operates similarly #
        ############################################
        # simulated timeseries
        self._sim_ts = [SparseList(init_pos[i]) for i in range(self.n_axes)]
        self._sim_step = 0

        self.mate_signal = MateSignalData()

        # 'dry run' timeseries used for time estimates:
        # TODO: can we get away with holding just the last timestep for this?
        self._dryrun = False
        self._dry_ts = None
        self._dry_step = 0

        # TODO: joystick in multi-controller

    #####################
    # Public properties #
    @property
    def last_plotted_timestep(self):
        """
        Returns
        -------
        int
            The index of the furthest individually plotted timestep thus far
        """
        return max([len(axis) for axis in self._timeseries]) - 1

    @property
    def last_padded_timestep(self):
        """
        Returns
        -------
        int
            The index of the furthest universally plotted timestep thus far
        """
        return min([len(axis) for axis in self._timeseries]) - 1

    @property
    def current_time(self):
        return self.current_step * self._time_per_step

    @property
    def has_simulation(self):
        return self.last_plotted_timestep > 1

    @property
    def _timeseries(self):
        """ If 'dry run' flag is set, will return the 'dry', temporary timeseries instead of the real timeseries """
        if self._dryrun:
            assert isinstance(self._dry_ts, list)
            return self._dry_ts
        else:
            return self._sim_ts

    @property
    def current_step(self):
        if self._dryrun:
            return self._dry_step
        else:
            return self._sim_step

    ##################
    # Public methods #
    def handle_cmd(self, cmd_bytes, line=0, task=-1, wait=True, kf_only=False):
        """

        Parameters
        ----------
        cmd_bytes: bytes
            Full command line.
        line: int
            The line number in the user script that the command was called from for debug highlighting
        task: int
            The current scheduler task id, if any
        wait: bool
        kf_only: bool

        Returns
        -------
        response: bytes
            Simulated response
        time_diff: float
            Time difference
        """
        assert isinstance(cmd_bytes, bytes)
        start_time = self.current_time

        # decompose & decode cmd_bytes into strings #
        cmd_terms = cmd_bytes.split(b' ')
        addr = ord(cmd_terms[0].decode('ascii'))
        cmd = cmd_terms[1].decode('ascii')
        args = [int(arg.decode()) for arg in cmd_terms[2:-1]]

        response, steps_added, kf = self.controllers[addr].execute_cmd(cmd, args)

        if wait and steps_added > 0:
            self.jump_steps(steps_added)
        else:
            self.jump_time(self.CMD_TIME)

        for controller in self.controllers.values():
            controller._refresh_statuses()

        # add timeseries updates to NSIM file
        if not self._dryrun:
            if self.last_padded_timestep > self._last_sent_step:
                with open(self._nsim_path, 'ab') as nsim_file:
                    for timestep in range(self._last_sent_step + 1, self.last_padded_timestep + 1):
                        step = [axis.at(timestep) for axis in self._sim_ts]
                        # we want to include the last timestep as a mock kf when in kf_only mode
                        if kf_only and (not kf) and timestep < self.last_padded_timestep:
                            continue
                        assert len(step) == self.n_axes
                        STEP_FMT = north.STEP_HEADER_FMT + 'f' * self.n_axes
                        # if self.mate_signal.signal != SimMateSignal.NONE:
                        # print(f'got mate signal {self.mate_signal.signal}, {self.mate_signal.to_int()}, {self.mate_signal.controller}, {self.mate_signal.channel}')
                        step_data = struct.pack(STEP_FMT, timestep, kf, kf_only, task, self.mate_signal.to_int(),
                                                self.mate_signal.controller, self.mate_signal.channel, line, *step)
                        nsim_file.write(step_data)
                        # clean up what should only be sent once?
                        kf = False
                        self.mate_signal.clear()
                self._last_sent_step = self.last_padded_timestep

        time_diff = self.current_time - start_time

        # return the response and the time added to TS
        return response, time_diff

    # dry running #
    def start_dryrun(self):
        """ Sets 'dry run' flag and initializes a dry-run timeseries """
        assert not self._dryrun
        self._dryrun = True
        self._dry_step = 0
        self._dry_ts = [SparseList(0) for _ in range(self.n_axes)]

    def end_dryrun(self):
        """ Unsets 'dry run' flag and deletes the dry-run timeseries """
        assert self._dryrun
        self._dryrun = False
        del self._dry_ts

    def jump_steps(self, steps):
        """
        Jump ahead some number of timesteps (advance current step and pad behind it).

        Parameters
        ----------
        steps: int
            Time (seconds) to skip forwards.
        Returns
        -------
        int
            Number of timesteps jumped forwards.
        """
        assert isinstance(steps, int)  # TODO why? why not float?
        assert steps > 0
        if self._dryrun:
            self._dry_step += steps
        else:
            self._sim_step += steps
        self.pad_all_axes(pad_to=self.current_step)
        return steps

    def jump_time(self, seconds):
        """
        Jump ahead some number of seconds (advance current step and pad behind it).

        Parameters
        ----------
        seconds: float
            Time (seconds) to skip forwards
        Returns
        -------
        int
            Number of timesteps jumped forwards.
        """
        assert seconds > 0.0
        steps = int(math.ceil(seconds / self._time_per_step))  # steps = time / (time per step)
        return self.jump_steps(steps)

    ###################
    # Padding methods #
    ###################
    # TODO: can improve these with the pad fcnality of SparseList

    def pad_all_axes(self, pad_to=None):
        """
        If pad_to is not specified, will pad to the last plotted timestep.

        Parameters
        ----------
        pad_to: int, optional
        """
        for i in range(self.n_axes):
            self.pad_axis(i, pad_to=pad_to)

    def pad_axis(self, global_axis, pad_to=None):
        """
        If pad_to is not specified, will pad to the last plotted timestep.

        Parameters
        ----------
        global_axis: int
        pad_to: int, optional
        """
        assert isinstance(global_axis, int)
        series = self._timeseries[global_axis]
        pad_to = self.last_plotted_timestep if pad_to is None else pad_to
        assert type(pad_to) is int
        diff = pad_to + 1 - len(series)  # +1 converts pad_to -> max_len. we want diff. btw. lengths
        if diff > 0:
            self._timeseries[global_axis].append(series.last_value, diff)
        assert len(self._timeseries[global_axis]) - 1 >= pad_to

    def pad_selected(self, global_axes, pad_to=None):
        """
        If pad_to is not specified, will pad to the last plotted timestep in selection.

        Parameters
        ----------
        global_axes: list
        pad_to: int, optional
        """
        assert isinstance(global_axes, list)
        assert all(isinstance(global_axis, int) for global_axis in global_axes)
        max_len = self.last_plotted_timestep + 1
        pad_to = max_len - 1 if pad_to is None else pad_to
        assert type(pad_to) is int

        # ensure all axes involved in the robot move are padded out to be same len
        for global_axis in global_axes:
            self.pad_axis(global_axis, pad_to=max_len - 1)
        assert all([len(self._timeseries[global_axis]) - 1 >= pad_to for global_axis in global_axes])

    def axis_kinematics(self, global_axis, k_max, x, v_0, a):
        """
        Calculates the movement of an axis and writes it to the timeseries

        Parameters
        ----------
        global_axis: int
            Which axis is doing the movement
        k_max: int
            Number of timesteps to calculate
        x: float
        v_0: float
        a: float

        Returns
        -------
        int
            Number of timesteps added on axis.
        """
        assert isinstance(global_axis, int)
        assert isinstance(k_max, int)
        len_pre = len(self._timeseries[global_axis])

        x_0 = self._timeseries[global_axis].last_value
        self._timeseries[global_axis].append_list(
            [x_0 + v_0 * (k * self._time_per_step) + 0.5 * a * (k * self._time_per_step) ** 2
             for k in range(1, k_max)])
        self._timeseries[global_axis].append(x_0 + x)

        diff = len(self._timeseries[global_axis]) - len_pre
        assert diff >= 0
        return diff

    def get_axis_position(self, global_axis):
        return int(self._timeseries[global_axis].last_value)

    def set_axis_position(self, global_axis, position):
        self._timeseries[global_axis].append(position)
        return 1  # number of timesteps added

    def prune_axis(self, global_axis, step):
        self._timeseries[global_axis].prune(step)


class VirtualController:
    # virtual controllers write to the main timeline. they choose which axis to write to based on the project controller's
    # stored axis map, generated when the project loads

    # many methods, members, and variables in this class are named as either axis "local" or "global"
    # this refers to whether the axis number the variable holds is local (e.g. axis 0 on a controller)
    # or global (maybe axis 91 across all axes in the sim)

    ROBOT_AXES_LOCAL = [n9.GRIPPER, n9.ELBOW, n9.SHOULDER, n9.Z_AXIS]

    # setting a digital output high moves that axis to position 300 with v=6k, accel = 35k (low to 0)
    DIGITAL_OUT_POS = 300
    DIGITAL_OUT_VEL = 6000
    DIGITAL_OUT_ACCEL = 35000

    def __init__(self, project_controller, simulator):
        self._controller_data: Controller = project_controller
        self._sim: Simulator = simulator

        self._init_command_table()
        self._init_status_table()

        # todo: should check if controller has N9, not if axes 0-4 are used
        self.robot_axes_global = []
        for local_axis in self.ROBOT_AXES_LOCAL:
            if local_axis not in self.axis_map:
                self.robot_axes_global = None
                break
            self.robot_axes_global.append(self.axis_map[local_axis])

        self.pump_speeds = defaultdict(lambda: 1400)  # speed code deafult: 11 => 1400

    @property
    def id(self):
        return self._controller_data.id

    @property
    def address(self):
        return self._controller_data.address

    # axis_map returns the global sim axis number for a controller's particular channel, if that channel is connected
    @property
    def axis_map(self):
        return self._controller_data.axis_map

    def get_axis_position(self, local_axis):
        return self._sim.get_axis_position(self.axis_map[local_axis])

    ########################
    # Private initializers #

    # TODO: does this need to be done for every virtual controller? can we find a way to abstract this?
    def _init_command_table(self):
        """
        Commands initialize.
        """
        self._commands = {
            # homing commands
            "HORO": {
                "callback": self._horo,
                "argnames": [],
                "role": 'home'
            },
            "HOAX": {
                "callback": self._hoax,
                "argnames": ['axis'],
                "role": 'home'
            },
            "HOPM": {
                "callback": self._hopm,
                "argnames": ['pump'],
                "role": 'home'
            },
            # movement commands
            "MORO": {
                "callback": self._moro,
                "argnames": ['a', 'b', 'c', 'd', 'velocity', 'accel'],
                "role": 'move'
            },
            "MOAX": {
                "callback": self._moax,
                "argnames": ['axis', 'count', 'velocity', 'accel'],
                "role": 'move'
            },
            "MOPM": {
                "callback": self._mopm,
                "argnames": ['pump', 'count'],
                "role": 'move'
            },
            "SYNC": {
                "callback": self._sync,
                "argnames": ['axis_1', 'axis_2', 'count_1', 'count_2', 'velocity', 'accel'],
                "role": 'move'
            },
            "RDCA": {
                "callback": self._rdca,
                "argnames": ['axis', 'cts_per_rev'],
                "role": 'move'
            },
            # gripper movements
            "CLMP": {
                "callback": self._clmp,
                "argnames": ['clamp', 'closed'],
                "role": 'output'
            },
            "GRPR": {
                "callback": self._grpr,
                "argnames": ['closed'],
                "role": 'output'
            },
            "SETO": {
                "callback": self._seto,
                "argnames": ['output_num', "value"],
                "role": 'output'
            },
            "VACU": {
                "callback": self._vacu,
                "argnames": ['on'],
                "role": 'output'
            },
            "BRNL": {
                "callback": self._brnl,
                "argnames": ['on'],
                "role": 'output'
            },
            "CAPV": {
                "callback": self._capv,
                "argnames": ['grip_ct', 'pitch_ct', 'torque_thr', 'velocity', 'accel'],
                "role": 'sequence'
            },
            "UCAP": {
                "callback": self._ucap,
                "argnames": ['grip_ct', 'pitch_ct', 'velocity', 'accel'],
                "role": 'sequence'
            },
            # joystick commands
            "JSBG": {
                "callback": self._jsbg,
                "argnames": [],
                "role": 'joystick'
            },
            "JSUP": {
                "callback": self._jsup,
                "argnames": ['grip_ct', 'elbw_ct', 'shld_ct', 'z_ax_ct'],
                "role": 'joystick'
            },
            "JSSP": {
                "callback": self._jssp,
                "argnames": [],
                "role": 'joystick'
            },
            # other commands
            "DLAY": {
                "callback": self._dlay,
                "argnames": ['time'],
                "role": 'other'
            },
            "SPMV": {
                "callback": self._spmv,
                "argnames": ['pump', 'pos'],
                "role": 'pump'
            },
            "SPMS": {
                "callback": self._spms,
                "argnames": ['pump', 'speed_code'],
                "role": 'pump'
            },
            # sensor requests
            "AXPS": {
                "callback": self._axps,
                "argnames": ['axis'],
                "role": 'request'
            },
            "INFO": {
                "callback": self._info,
                "argnames": [],
                "role": 'request'
            },
            "GHOO": {
                "callback": self._ghoo,
                "argnames": ['axis'],
                "role": 'request'
            },
            "GETI": {
                "callback": self._geti,
                "argnames": ['channel'],
                "role": 'request'
            },
            "GETA": {
                "callback": self._geta,
                "argnames": ['channel'],
                "role": 'request'
            },
            "GTBC": {
                "callback": self._gtbc,
                "argnames": [],
                "role": 'request'
            },
            "RDSC": {
                "callback": self._rdsc,
                "argnames": [],
                "role": 'request'
            },
            "GADR": {
                "callback": self._gadr,
                "argnames": [],
                "role": 'request'
            },
            # status requests
            "ROST": {
                "callback": self._rost,
                "argnames": [],
                "role": 'status'
            },
            "SQST": {
                "callback": self._sqst,
                "argnames": [],
                "role": 'status'
            },
            "AXST": {
                "callback": self._axst,
                "argnames": ['axis'],
                "role": 'status'
            },
            "PMST": {
                "callback": self._pmst,
                "argnames": ['pump'],
                "role": 'status'
            }
        }

    def _init_status_table(self, init_pos=None):
        """
        Status initialize.

        :param list init_pos: TODO
        """
        self._statuses = {
            # simulated register dict holding robot+module statuses
            "robot": NorthC9.FREE,
            "sequence": NorthC9.FREE
        }
        self._statuses.update({f'axis_{i}': AxisState.OFF for i in range(self._controller_data.N_MOTORS + \
                                                                         self._controller_data.N_OUTPUTS)})
        self._statuses.update({f'pump_{i}': NorthC9.FREE for i in range(self._controller_data.N_PUMPS)})
        """
        self._statuses now looks like {
            'robot': 0,
            'sequence': 0,
            'axis_0' 0,
            ...,
            'pump_0': 0,
            ...
        }
        """

    def execute_cmd(self, cmd, args):

        # handle invalid commands #
        if cmd not in self._commands:
            logging.info(f'Simulator: unrecognized cmd {cmd}')
            return self._default_response(cmd), ZERO_STEPS, True
        elif self._is_missing_cmd_args(cmd, args):
            logging.error(f'cmd {cmd} missing args')  # better error message printed in _is_missing_cmd_args method
            return self._default_response(cmd), 0, False

        # if command is not recognized by the controller, just return the default response (its what fw does)
        try:
            callback: Callable = self._commands[cmd]['callback']
            role: str = self._commands[cmd]['role']
        except KeyError:
            return self._default_response(cmd), ZERO_STEPS, True

        # TODO: seperate status handling for each controller in multi_controller_paradigm
        if role == 'status' or role == 'request':
            kf = False  # status updates and requests are not keyframes
            response = callback(args)
            steps_added = ZERO_STEPS
        else:
            kf = True
            response = self._default_response(cmd)
            steps_added = callback(args)

        # jump steps?

        # see -> jump steps: self._sim.pad_all_axes()
        # refresh statuses ?

        # keyframes?

        return response, steps_added, kf

    ###################
    # Private methods #

    def _default_response(self, cmd):
        return f'{chr(self.address)} {cmd} '.encode('ascii')

    def _is_missing_cmd_args(self, cmd, args):
        """
        :param str cmd:
        :param list args:
        :return: whether cmd line is missing arguments
        """
        assert cmd in self._commands
        argnames = self._commands[cmd]['argnames']
        if len(args) < len(argnames):
            logging.error(
                f'Simulator: missing {len(argnames) - len(args)} arguments from {cmd} command: {argnames[len(args) - 1:]}.')
            return True
        return False

    ################################
    # Commonly used move functions #
    ################################
    # TODO handle saturations
    def _move_axis(self, args, pump_move=False):
        """
        Simulate movement on axis.

        :param list args: [axis, end_pos, vel, acc]
        :param pump_move: Boolean - if pump_move, no minimum velocity
        :return: number of steps the movement takes
        """
        local_axis = int(args[0])  # local axis is the axis number on the controller (i.e. move axis 0, the gripper)
        if local_axis not in self.axis_map:
            return ZERO_STEPS
        global_axis = self.axis_map[
            local_axis]  # global is the timeseries axis, local axis 0 might be axis 75 in the whole experiment

        end_pos = int(args[1])
        vel_arg = int(args[2])
        if not pump_move:
            vel_arg = max(int(args[2]), 100)  # floor vel at 100
        acc_arg = max(int(args[3]), 100)  # floor acc at 100

        # prune movement to current step
        # Note !! we can only get away with this because all roads lead back to kinematics,
        # and they all get to kinematics through move_axis.
        self._sim.prune_axis(global_axis, self._sim.current_step)

        pos = self.get_axis_position(local_axis)
        x = end_pos - pos
        top_vel = math.copysign(vel_arg, x)  # velocity saturation in motion controller
        accel = math.copysign(acc_arg, x)  # accel saturation in motion controller
        accel_dist = (top_vel ** 2) / (2 * accel)  # the distance required to accelerate to desired vel

        # TODO: known issue, trajectories are slightly discontinuous because of rounding errors..
        #  i.e. arriving at corners between samples
        n_steps = 0
        if abs(accel_dist) >= abs(x / 2):  # triangular profile
            t_accel = (math.sqrt(x / accel))  # time in seconds it takes to get halfway to position target
            k_accel = math.floor(
                t_accel / self._sim._time_per_step)  # number of timesteps it takes to get halfway to position target
            n_steps += self._sim.axis_kinematics(global_axis, k_accel, x / 2, 0, accel)
            n_steps += self._sim.axis_kinematics(global_axis, k_accel, x / 2, accel * t_accel, -accel)
        else:  # trapezoidal profile
            t_accel = (math.sqrt(2 * accel_dist / accel))  # time in seconds it takes to accelerate to top vel
            k_accel = math.floor(
                t_accel / self._sim._time_per_step)  # number of timesteps it takes to accelerate to top vel
            n_steps += self._sim.axis_kinematics(global_axis, k_accel, accel_dist, 0, accel)
            cnst_vel_dist = x - 2 * accel_dist  # cruising at steady state between accel and decel
            n_steps += self._sim.axis_kinematics(global_axis,
                                                 math.floor(cnst_vel_dist / (top_vel * self._sim._time_per_step)),
                                                 cnst_vel_dist, top_vel,
                                                 0)
            n_steps += self._sim.axis_kinematics(global_axis, k_accel, accel_dist, top_vel, -accel)
        return n_steps

    def _move_sync(self, args):
        """
        Simulate synchronized movement across two axes.

        :param list args: [axis1, axis2, end1, end2, vel, acc]
        :return: number of steps the movement takes
        """
        assert len(args) >= 6

        local_axes = [int(args[0]), int(args[1])]
        global_axes = []
        for local_axis in local_axes:
            if local_axis not in self.axis_map:
                return ZERO_STEPS
            global_axes.append(self.axis_map[local_axis])

        end_pos = [int(args[2]), int(args[3])]
        top_vel = int(args[4])
        accel = int(args[5])

        x = []
        max_x = 0
        for i, local_axis in enumerate(local_axes):
            x.append(abs(end_pos[i] - self.get_axis_position(local_axis)))
            if x[i] > max_x:
                max_x = x[i]

        if max_x == 0:
            return ZERO_STEPS

        step_nums = set()
        for i, local_axis in enumerate(local_axes):
            if x[i] == 0:
                continue
            a = (x[i] * accel) / max_x
            v = (x[i] * top_vel) / max_x
            step_nums.add(self._move_axis([local_axis, end_pos[i], v, a]))

        return max(step_nums)

    def _move_robot(self, args):
        """
        Simulate full-robot movement (4 axes)

        :param list args: [end1, end2, end3, end4, vel, acc]
        :return: number of steps the movement takes
        """

        if self.robot_axes_global is None:
            return ZERO_STEPS

        end_pos = [int(args[0]), int(args[1]), int(args[2]), int(args[3])]
        top_vel = int(args[4])
        accel = int(args[5])

        x = [abs(end_pos[i] - self.get_axis_position(local_axis))
             for i, local_axis in enumerate(self.ROBOT_AXES_LOCAL)]
        max_x = max(x)

        if max_x == 0:
            return ZERO_STEPS

        step_nums = set()
        for i, local_axis in enumerate(self.ROBOT_AXES_LOCAL):
            if x[i] == 0:
                continue
            a = (x[i] * accel) / max_x
            v = (x[i] * top_vel) / max_x
            step_nums.add(self._move_axis([local_axis, end_pos[i], v, a]))
        return max(step_nums)

    #####################
    # Status management #
    #####################
    def _get_status(self, register):
        """
        Get status from register.

        :param str register: The name of a status register to access. Must be one of: 'robot', 'sequence', 'axes', 'pumps'.
        :return: The current status of the register.
        """
        assert register in self._statuses
        status = self._statuses[register]

        if type(status) == tuple:  # planned update
            assert len(status) == 3
            assert all([isinstance(v, int) for v in status])
            current = status[0]
            return current
        else:  # resting value
            assert isinstance(status, int)
            return status

    def _set_status(self, register, status):
        """
        Immediate status change.

        :param str register:
        :param int status:
        """
        assert isinstance(register, str)
        assert isinstance(status, int)
        self._statuses[register] = status

    def _plan_status(self, register, current, wait, future):
        """
        Planned status change (after some wait).

        :param str register: name of register to plan status change for
        :param int current: current status
        :param int wait: time to hold current status, before switching to future status
        :param int future: future status
        :return:
        """
        assert isinstance(register, str)
        assert isinstance(current, int)
        assert isinstance(wait, int)
        assert isinstance(future, int)
        end_step = self._sim.current_step + wait
        self._statuses[register] = (current, end_step, future)

    def _refresh_statuses(self):
        """
        Applies any pending, plotted status changes (where status is a tuple).

        """
        for register, status in self._statuses.items():  # ex: 'robot', (0, 100, 1)
            if isinstance(status, tuple):
                assert len(status) == 3
                assert all([isinstance(i, int) for i in status])
                end_step = status[1]
                if self._sim.current_step >= end_step:
                    future = status[2]
                    self._set_status(register, future)
            else:
                assert isinstance(status, int)

    ####################
    # Command handlers #
    ####################

    # homing commands #
    def _horo(self, args):
        """
        Home entire robot.

        :param list args: []
        :return: Number of timesteps added by homing motion.
        """
        if self.robot_axes_global is None:
            return ZERO_STEPS
        z_steps = self._move_axis([n9.Z_AXIS, 0, Simulator.HOME_VEL, Simulator.HOME_ACCEL])
        step_nums = set()
        for i in range(3):
            step_nums.add(self._move_axis([i, 0, Simulator.HOME_VEL, Simulator.HOME_ACCEL]))
        # self.pad_selected(self.ROBOT_AXES)
        steps = z_steps + max(step_nums)
        self._plan_status('robot', wait=steps,
                          current=NorthC9.BUSY,
                          future=NorthC9.FREE)
        return steps

    def _hoax(self, args):
        """
        Home a particular axis.

        :param list args: [axis]
        :return: Number of timesteps added by homing motion.
        """
        local_axis = int(args[0])
        steps = self._move_axis([local_axis, 0, Simulator.HOME_VEL, Simulator.HOME_ACCEL])
        self._plan_status(f'axis_{local_axis}', wait=steps,
                          current=AxisState.HOMING,
                          future=AxisState.HOME_COMPLETE)
        return steps

    def _hopm(self, args):
        """
        Home a particular pump.

        :param list args: [pump]
        :return: Number of timesteps added by homing motion.
        """
        pump_vel = 6000
        pump_accel = 20000
        pump = int(args[0])
        if pump < 0 or pump >= self._controller_data.N_PUMPS:
            logging.error(f'_hopm: pump == {pump}, out of bounds')
            return ZERO_STEPS
        steps = self._move_axis([self._controller_data.PUMPS + (2 * pump), 0, pump_vel, pump_accel])
        self._plan_status(f'pump_{pump}', wait=steps,
                          current=NorthC9.BUSY,
                          future=NorthC9.FREE)
        return steps

    # moving commands #
    def _moro(self, args):
        """
        Move entire robot.

        :param list args: [a, b, c, d, velocity, accel]
        :return: Number of timesteps added by the motion.
        """
        steps = self._move_robot(args)
        self._plan_status('robot', wait=steps,
                          current=NorthC9.BUSY,
                          future=NorthC9.FREE)
        return steps

    def _moax(self, args):
        """
        Move a particular axis.

        :param list args: [axis, count, velocity, accel]
        :return: Number of timesteps added by the motion.
        """
        steps = self._move_axis(args)
        self._plan_status(f'axis_{int(args[0])}', wait=steps,
                          current=AxisState.MOVE_ABS,
                          future=AxisState.MOVE_COMPLETE)
        return steps

    def _mopm(self, args):
        """
        Move a particular pump.

        :param list args: [pump, count]
        :return: Number of timesteps added by the motion.
        """

        pump = int(args[0])
        if pump < 0 or pump >= self._controller_data.N_PUMPS:
            logging.error(f'_mopm: pump == {pump}, out of bounds')
            return ZERO_STEPS
        pump_vel = self.pump_speeds[pump]
        pump_accel = 20000
        count = clamp(int(args[1]), 0, 24000)  # clamp to [0, 24000]
        steps = self._move_axis([self._controller_data.PUMPS + (2 * pump), count, pump_vel, pump_accel], pump_move=True)
        self._plan_status(f'pump_{pump}', wait=steps,
                          current=NorthC9.BUSY,
                          future=NorthC9.FREE)
        return steps

    def _sync(self, args):
        """
        Synchronized movement across 2 axes.

        :param list args: ['axis_1', 'axis_2', 'count_1', 'count_2', 'velocity', 'accel']
        :return: Number of timesteps added by movement.
        """
        steps = self._move_sync(args)
        self._plan_status(f'axis_{int(args[0])}', wait=steps,
                          current=AxisState.MOVE_ABS,
                          future=AxisState.MOVE_COMPLETE)
        self._plan_status(f'axis_{int(args[1])}', wait=steps,
                          current=AxisState.MOVE_ABS,
                          future=AxisState.MOVE_COMPLETE)
        return steps

    def _rdca(self, args):
        """
        Reduce axis command, set the position of an infinitely rotating axis back within +/- a single revolution
        e.g. If the gripper (4000 cts/rev) has rotated ten full turns in one direction, i.e. capping its position is
        40k cts. If the next move is to 1000 cts, it would have to spin back 9 3/4 turns. Instead, it can just spin a
        fraction of a turn by taking 40k%4k. reduced position = current position % cts_per_rev

        :param list args: [axis, cts_per_rev]
        :return: Number of timesteps added - typically 1
        """

        local_axis = int(args[0])  # local axis is the axis number on the controller (i.e. move axis 0, the gripper)
        if local_axis not in self.axis_map:
            return ZERO_STEPS
        global_axis = self.axis_map[local_axis]

        return self._sim.set_axis_position(global_axis, self._sim.get_axis_position(global_axis) % int(args[1]))


    # should move to wrap this at North Package level
    def _clmp(self, args):
        """
        Clamp motion.

        :param list args: [clamp, closed]
        :return: Number of timesteps added by clamp motion.
        """
        # clamp = int(args[0])
        # set_open = int(args[1])
        # clamp_num = clamp + self._controller_data.CLAMP_HVO
        # if set_open:
        #     steps = self._move_axis([clamp_num, self.DIGITAL_OUT_POS, self.DIGITAL_OUT_VEL, self.DIGITAL_OUT_ACCEL])
        # else:
        #     steps = self._move_axis([clamp_num, 0, self.DIGITAL_OUT_VEL, self.DIGITAL_OUT_ACCEL])
        #
        # self._plan_status(f'axis_{clamp_num}', wait=steps,
        #                   current=AxisState.MOVE_ABS, future=AxisState.MOVE_COMPLETE)
        # return steps
        output_channel = (self._controller_data.CLAMP_HVO - self._controller_data.HVO_CHANNELS) + int(args[0])
        return self._seto([output_channel, args[1]])

    # gripper commands #
    # should move to wrap this at North Package level
    def _grpr(self, args):
        """
        Gripper action.

        :param list args: [closed]
        :return: Number of timesteps added by gripper action.
        """
        # gripper_vel = 6000
        # gripper_accel = 35000
        # if int(args[0]) == 0:
        #     self._mv_event = MoveableEvent.DETACH
        #     steps = self._move_axis([c9.GRIPPER_FINGERS_HVO, 0, gripper_vel, gripper_accel])
        # else:
        #     self._mv_event = MoveableEvent.ATTACH
        #     steps = self._move_axis([c9.GRIPPER_FINGERS_HVO, 300, gripper_vel, gripper_accel])
        # # status = AxisState.MOVE_COMPLETE if int(args[0]) else AxisState.OFF
        # self._plan_status(f'axis_{c9.GRIPPER}', wait=steps,
        #                   current=AxisState.MOVE_ABS,
        #                   future=AxisState.MOVE_COMPLETE)
        output_channel = (self._controller_data.GRIPPER_FINGERS_HVO - self._controller_data.HVO_CHANNELS)
        return self._seto([output_channel, args[
            0]])  # _grpr just wraps _seto, seto starts counting output channels at gripper fingers so send channel 0

    def _seto(self, args):
        """
        Set/clear digital output

        :param args: [output_num, value]
        :return: Number of timesteps added by set/clear.
        """
        channel = int(args[0])
        value = int(args[1])
        local_axis = self._controller_data.HVO_CHANNELS + channel
        if value == 0:
            self._sim.mate_signal.set(SimMateSignal.OUTPUT_LOW, self.id, local_axis)
            steps = self._move_axis([local_axis, 0, self.DIGITAL_OUT_VEL, self.DIGITAL_OUT_ACCEL])
        else:
            self._sim.mate_signal.set(SimMateSignal.OUTPUT_HIGH, self.id, local_axis)
            steps = self._move_axis([local_axis, self.DIGITAL_OUT_POS, self.DIGITAL_OUT_VEL, self.DIGITAL_OUT_ACCEL])

        # I don't think statuses make sense with regard to HVO channels ?
        # status = AxisState.MOVE_COMPLETE if value else AxisState.OFF
        # self._plan_status(f'axis_{axis}', wait=0, #TODO why not steps??
        #                   current=status,
        #                   future=status)

        return ZERO_STEPS

    # ### these are not FW commands - should be wrapped at the north package level
    def _vacu(self, args):
        return 0

    #     """
    #     Vacuum gripper action.
    #
    #     :param list args: [on]
    #     :return: 0
    #     """
    #     self._mv_tool = north_location.Location.VACUUM
    #     self._mv_event = MoveableEvent.DETACH if int(args[0]) == 0 else MoveableEvent.ATTACH
    #     return ZERO_STEPS
    #
    def _brnl(self, args):
        return 0

    #     """
    #     Bernoulli gripper action.
    #
    #     :param list args: [on]
    #     :return: 0
    #     """
    #     self._mv_tool = north_location.Location.BERNOULLI
    #     self._mv_event = MoveableEvent.DETACH if int(args[0]) == 0 else MoveableEvent.ATTACH
    #     return ZERO_STEPS

    def _capv(self, args):
        """
        Vial capping motion.

        :param list args: [grip_ct, pitch_ct, ?, velocity, accel]
        :return: Number of timesteps added by capping motion.
        """
        gripper_cts = int(args[0])
        pitch_cts = int(args[1])
        vel = int(args[3])
        accel = int(args[4])
        self._sim.mate_signal.set(SimMateSignal.CAP, self.id, -1)
        # ^^^ yes should be the mate channel corresponding to the N9 of the addressed controller, if it exists. otherwise need a None value here
        steps = self._move_sync([n9.GRIPPER, n9.Z_AXIS,
                                 self.get_axis_position(n9.GRIPPER) + gripper_cts,
                                 self.get_axis_position(n9.Z_AXIS) + int(gripper_cts / pitch_cts),
                                 vel, accel])
        steps += self._rdca([n9.GRIPPER, n9.GRIPPER_COUNTS_PER_REV])
        self._plan_status('sequence', wait=steps,
                          current=NorthC9.BUSY,
                          future=NorthC9.FREE)
        return steps

    def _ucap(self, args):
        """
        Vial uncapping motion.

        :param list args: [grip_ct, pitch_ct, velocity, accel]
        :return: Number of timesteps added by uncapping motion.
        """
        gripper_cts = int(args[0])
        pitch_cts = int(args[1])
        vel = int(args[2])
        accel = int(args[3])
        self._sim.mate_signal.set(SimMateSignal.UNCAP, self.id, -1)
        steps = self._move_sync([n9.GRIPPER, n9.Z_AXIS,
                                 self.get_axis_position(n9.GRIPPER) + gripper_cts,
                                 self.get_axis_position(n9.Z_AXIS) + int(gripper_cts / pitch_cts),
                                 vel, accel])
        steps += self._rdca([n9.GRIPPER, n9.GRIPPER_COUNTS_PER_REV])
        self._plan_status('robot', wait=steps,
                          current=NorthC9.BUSY,
                          future=NorthC9.FREE)
        return steps

    #####################
    # joystick commands #
    def _jsbg(self, args):
        """
        Joystick control begin.

        :param list args: []
        :return: 0
        """
        self._js_pos = [self.get_axis_position(local_axis) for local_axis in self.ROBOT_AXES_LOCAL] \
            if self.has_simulation else [0 for _ in self.ROBOT_AXES_LOCAL]
        broker.send_cmd(b'JBEG')
        return ZERO_STEPS

    def _jsup(self, args):
        """
        Joystick control action.

        :param list args: [grip_ct, elbw_ct, shld_ct, z_ax_ct]
        :return: Number of timesteps added by motion.
        """
        assert isinstance(self._js_pos, list)
        assert len(self._js_pos) == len(self.ROBOT_AXES_LOCAL)

        # calculate new js_pos
        for i, raw_delta in enumerate(args):
            # get delta (flip [opt] for Z-axis), and find new js_pos
            delta = int(float(raw_delta) / self.JS_SLOWDOWN)
            if i == n9.Z_AXIS:
                delta = delta if self.JS_INVERT_Z else -delta
            new_pos = self._js_pos[i] - delta

            # grippers have inf counts; every other axis has clamped counts
            if i != n9.GRIPPER:
                clamped_pos = max(0, min(self._sim.MAX_CTS[i], new_pos))
                new_pos = clamped_pos
            self._js_pos[i] = new_pos

        # move to new js_pos
        data = struct.pack(f'{len(self._js_pos)}i', *self._js_pos)
        broker.send_cmd(cmd=b'JMOV', data=data)
        return ZERO_STEPS

    def _jssp(self, args):
        """
        Joystick control stop.

        :param list args: []
        :return: 0
        """
        self._js_pos = None
        broker.send_cmd(b'JEND')
        return ZERO_STEPS

    ##################
    # other commands #
    def _dlay(self, args):
        """
        Simulated delay.
        Pads all simulated axes until end of delay.

        :param list args: [time (ms)]
        :return: 0
        """
        seconds = float(args[0]) / 1000.0
        assert type(seconds) in [int, float]
        self._sim.jump_time(seconds)
        return ZERO_STEPS

    def _spmv(self, args):
        """
        Set pump valve.

        :param list args: [pump, pos]
        :return: Timesteps added by the motion
        """
        valve_vel = 10000
        valve_accel = 100000
        pump = int(args[0])
        if pump < 0 or pump >= self._controller_data.N_PUMPS:
            logging.error(f'_spmv: n == {pump}, out of bounds')
            return ZERO_STEPS
        pos = int(args[1])

        # 2000 counts per rotation of pump arrow - arbitrary
        if pos == NorthC9.PUMP_VALVE_RIGHT:
            return self._move_axis([self._controller_data.PUMPS + (2 * pump) + 1, 0, valve_vel, valve_accel])
        elif pos == NorthC9.PUMP_VALVE_LEFT:
            return self._move_axis([self._controller_data.PUMPS + (2 * pump) + 1, 1000, valve_vel, valve_accel])
        elif pos == NorthC9.PUMP_VALVE_CENTER:
            return self._move_axis([self._controller_data.PUMPS + (2 * pump) + 1, 500, valve_vel, valve_accel])
        else:
            logging.error(f'_spmv: invalid pos value {pos}')
            return ZERO_STEPS

    def _spms(self, args):
        """
        Set pump speed.

        :param list args: [pump, speed_code]
        :return: ZERO_STEPS
        """
        if not 0 <= int(args[1]) <= len(pump_speed_codes):
            logging.error(f'Invalid speed code, should be in the range [0, 40]')
        self.pump_speeds[int(args[0])] = pump_speed_codes[int(args[1])]

        return ZERO_STEPS

    ###################
    # sensor and status requests #
    def _axps(self, args):
        """

        :param list args: ['axis']
        :return: [addr] AXPS [pos]
        """
        return bytes(f'{chr(self.address)} AXPS {self.get_axis_position(int(args[0]))} ', 'ascii')

    def _info(self, args):
        """

        :param list args: []
        :return: [addr] INFO [fw]
        """
        return bytes(f'{chr(self.address)} INFO 12345678 ', 'ascii')

    def _ghoo(self, args):
        """

        :param list args: ['axis']
        :return: [addr] GHOO [offset]
        """
        return bytes(f'{chr(self.address)} GHOO 0 ', 'ascii')  # home offsets are always 0 in sim

    def _geti(self, args):
        """

        :param list args: ['channel']
        :return: [addr] GETI [val]
        """
        return bytes(f'{chr(self.address)} GETI {self._next_sensor_val("GETI", str(args[0]))} ', 'ascii')

    def _geta(self, args):
        """

        :param list args: ['channel']
        :return: [addr] GETA [val]
        """
        return bytes(f'{chr(self.address)} GETA {self._next_sensor_val("GETA", str(args[0]))} ', 'ascii')

    def _gtbc(self, args):
        """

        :param list args: []
        :return: [addr] BUFF [val]
        """
        return bytes(f'{chr(self.address)} BUFF {self._next_sensor_val("GTBC")} ', 'ascii')

    def _rdsc(self, args):
        """

        :param list args: []
        :return: [addr] RDSC [val]
        """
        try:
            result = self._next_sensor_val("RDSC")
        except TypeError:
            result = ['0 0']
        result = [float(i) for i in result.split(' ')]
        scale_args = [0 for i in range(6)]
        if result[0] != 0:
            scale_args[0] = 1
        if result[1] < 0:
            scale_args[1] = 1
        scale_args[2] = abs(int(result[1]))
        post_dec_str = str(result[1]).split('.')[1]
        scale_args[3] = int(post_dec_str)
        scale_args[4] = len(post_dec_str)
        scale_args[5] = 0
        # print(scale_args)
        scale_args = ' '.join([str(i) for i in scale_args])

        return bytes(f'{chr(self.address)} RDSC {scale_args} ', 'ascii')

    def _gadr(self, args):
        """

        :param list args: ['channel']
        :return: [addr] GADR [val]
        """
        return bytes(f'{chr(self.address)} GADR {self.address} ', 'ascii')

    def _rost(self, args):
        """
        Robot status.

        :param list args: []
        :return: [addr] ROST [status]
        """
        return bytes(f'{chr(self.address)} ROST {self._get_status("robot")} ', 'ascii')

    def _sqst(self, args):
        """
        Sequence status.

        :param list args: []
        :return: [addr] SQST [status]
        """
        return bytes(f'{chr(self.address)} SQST {self._get_status("sequence")} ', 'ascii')

    def _axst(self, args):
        """
        Axis status.

        :param list args: ['axis']
        :return: [addr] AXST [status]
        """
        return bytes(f'{chr(self.address)} AXST {self._get_status(f"axis_{args[0]}")} ', 'ascii')

    def _pmst(self, args):
        """
        Pump status.

        :param list args: ['pump']
        :return: [addr] PMST [status]
        """
        return bytes(f'{chr(self.address)} PMST {self._get_status(f"pump_{args[0]}")} ', 'ascii')

    def _next_sensor_val(self, cmd, channel='0'):
        try:
            channel_dict = self._sim.sim_inputs[cmd]['channels'][channel]
        except KeyError:
            return []

        response_data = 0

        if channel_dict['mode'] == 'Random':
            response_data = randint(channel_dict['rand_min'], channel_dict['rand_max'])
        elif channel_dict['mode'] == 'Expression':
            channel_dict['list'] = eval(channel_dict['expr_str'])
            channel_dict['mode'] = 'List'
        if channel_dict['mode'] == 'List':
            try:
                next_i = channel_dict['next']
            except KeyError:
                next_i = channel_dict['next'] = 0
            channel_dict['next'] += 1

            # loop over the list
            try:
                response_data = channel_dict['list'][next_i]
            except IndexError:
                next_i = 0
                channel_dict['next'] = 1
                try:
                    response_data = channel_dict['list'][next_i]
                except IndexError:
                    response_data = 0

        if not isinstance(response_data, list):
            response_data = [response_data]
        return ' '.join([str(arg) for arg in response_data])


@dataclass
class MateSignalData:
    _mate_signal: SimMateSignal = SimMateSignal.NONE
    _controller: int = None
    _channel: int = None

    def set(self, signal: SimMateSignal, controller: int, channel: int):
        self.__init__(signal, controller, channel)

    def clear(self):
        self.__init__()

    @property
    def signal(self):
        return self._mate_signal

    @property
    def controller(self):
        return int(self._controller) if self._controller is not None else -1

    @property
    def channel(self):
        return int(self._channel) if self._channel is not None else -1

    def to_int(self):
        return int(self._mate_signal.value)
