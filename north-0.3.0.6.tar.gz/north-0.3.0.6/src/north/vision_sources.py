""" Defines various vision sources, to be used by n9_cam as well as in the NorthIDE vision toolkit """

from north.north_util import VideoUtils, clamp, get_current_timestamp

import glm
import cv2
import logging
import struct
import mmap
import math
import numpy as np
from pathlib import Path
from typing import Callable, Optional, Tuple, Union
from queue import Queue


class _VisionSource:
    def __init__(self):
        """ The base vision source class. """
        super().__init__()
        self._visible = False
        self._shape_raw = (0, 0, 3)
        self._crop = None

    @property
    def src_id(self) -> str:
        """ An identifying string for this source """
        raise NotImplementedError()

    @property
    def name(self) -> str:
        """ The name of this source"""
        raise NotImplementedError()

    @property
    def active(self) -> bool:
        """ True if get_frame() can be called on the source without issue """
        raise NotImplementedError()

    @property
    def visible(self) -> bool:
        """ True if the source is visible in the NorthIDE """
        return self._visible

    @property
    def cropped(self) -> bool:
        """ True if this source is applying some crop """
        return isinstance(self._crop, tuple)

    @property
    def shape_raw(self) -> Tuple[int, int, int]:
        """ The shape of the frames from this source before any resize or cropping is performed """
        return self._shape_raw

    @property
    def shape(self) -> Tuple[int, int, int]:
        """ The shape of the frames from this source after (optional) cropping """
        if self.cropped:
            x1, y1, x2, y2 = self.crop_rect
            return (y2 - y1, x2 - x1, *self.shape_raw[2:])
        else:
            return self.shape_raw

    @property
    def valid_raw(self):
        """ True if `shape_raw` has no zero-values """
        return np.prod(self.shape_raw) > 0

    @property
    def valid_shape(self):
        """ True if `shape` has no zero-values """
        return np.prod(self.shape) > 0

    @property
    def crop_pcts(self):
        """
        Crop percentages (of image width).

        Returns
        -------
        Tuple[float, float, float, float]
            (%x1, %y1, %x2, %y2) each in range [0.0, 1.0].
        """
        assert self.cropped
        assert len(self._crop) == 4
        return self._crop

    @property
    def crop_rect(self):
        """
        Crop rectangle, in pixel indices.

        Returns
        -------
        Tuple[int, int, int, int]
            (x1, y1, x2, y2)
        """
        return (int(self.crop_pcts[0] * self.shape_raw[1]),
                int(self.crop_pcts[1] * self.shape_raw[0]),
                int(self.crop_pcts[2] * self.shape_raw[1]),
                int(self.crop_pcts[3] * self.shape_raw[0]))

    def set(self, **kw):
        for key in kw:
            p_key = f'_{key}'
            if hasattr(self, p_key):
                setattr(self, p_key, kw[key])
            else:
                raise KeyError(f'{self.__class__.__name__} has no private attribute "{p_key}".')

    def crop(self, frame):
        """
        Applies the source's crop to the given frame, and returns the cropped frame.

        Parameters
        ----------
        frame: np.ndarray
            Frame to be cropped.

        Returns
        -------
        np.ndarray
            Cropped section of frame.
        """
        assert isinstance(frame, np.ndarray)
        assert frame.shape == self.shape_raw
        x1, y1, x2, y2 = self.crop_rect
        if x1 == x2 and y1 == y2:
            logging.warning(f'crop(): Could not apply crop on source {self.src_id}; empty (zero) crop.')
            return frame
        return frame[y1:y2, x1:x2]

    def as_dict(self) -> dict:
        """ Dictionary to be saved to .nproj file """
        return {
            "id": self.src_id,
            "name": self.name,
            "visible": self.visible,
            "crop": self._crop
        }

    def check_shape(self) -> bool:
        """ Attempt to retrieve frame shape and set it. Returns True if successful. """
        raise NotImplementedError()

    def get_frame(self, apply_crop=True):
        """
        Get a frame from this source.

        Parameters
        ----------
        apply_crop: bool
            If True, will return frame cropped with `crop()`, else will return the raw frame.

        Returns
        -------
        np.ndarray
            The most recent frame on this vision source.
        """
        raise NotImplementedError()

    def register(self) -> bool:
        """ Perform any necessary registration for this source (ex. CameraSource) """
        raise NotImplementedError()

    def unregister(self) -> bool:
        """ Perform any necessary un-registration for this source (ex. CameraSource) """
        raise NotImplementedError()


class CameraSource(_VisionSource):
    def __init__(self, cam_id):
        """
        A camera source is a vision source which retrieves images from a camera loop.
        Camera sources also have blackbox functionality, which allows for last-N-seconds retention and dumping to file.

        Parameters
        ----------
        cam_id: int
            Camera number this source should draw from.
        """
        super().__init__()

        assert isinstance(cam_id, int)
        self._cam = cam_id
        self._reg_count = 0
        self._blackbox_time = 0
        self._blackbox_frames: Optional[Queue] = None

    @property
    def src_id(self):
        return f'cam_{self.cam}'

    @property
    def name(self):
        return f'Camera {self.cam}'

    @property
    def cam(self):
        """ The camera number this source is drawing from """
        return self._cam

    @property
    def active(self):
        return self._reg_count > 0

    @property
    def using_black_box(self):
        """ True if blackbox time > 0 """
        return self.black_box_time > 0

    @property
    def black_box_time(self):
        """ Amount of time backwards that the blackbox should retain """
        return self._blackbox_time

    @black_box_time.setter
    def black_box_time(self, value: int):
        assert isinstance(value, int)
        self._blackbox_time = value
        self._blackbox_frames = Queue(value * VideoUtils.STREAM_FPS) if self.using_black_box else None

    def as_dict(self) -> dict:
        src_dict = super().as_dict()
        src_dict['cam'] = self.cam
        return src_dict

    def check_shape(self):
        assert self.active
        # get header information about this camera from mmap
        headsize = struct.calcsize('ii')
        head = mmap.mmap(-1, headsize, f"CAMERAFEED-{self.cam}")
        head.seek(0)
        w, h = struct.unpack('ii', head.read(headsize))
        head.close()
        # check dimensions to see if camera is activated
        self._shape_raw = (h, w, 3)
        return self.valid_raw

    def get_frame(self, apply_crop=True) -> np.ndarray:
        assert self.active
        if not self.check_shape():
            return None
        # get the current image from mmap
        headsize = struct.calcsize('ii')
        imgsize = np.prod(self._shape_raw)
        mm = mmap.mmap(-1, headsize + imgsize, f"CAMERAFEED-{self.cam}")
        mm.seek(headsize)
        buf = mm.read(imgsize)
        src_frame = np.frombuffer(buf, dtype=np.uint8).reshape(self._shape_raw)
        mm.close()
        if self.using_black_box:
            # if queue is full, empty up a spot at the "start" (oldest frame)
            if self._blackbox_frames.full():
                self._blackbox_frames.get()
            self._blackbox_frames.put(src_frame)
        return self.crop(src_frame) if apply_crop and self.cropped else src_frame

    def register(self):
        from north.n9_cam import register_cam
        _, regs = register_cam(self.cam, verbose=True)
        if isinstance(regs, int):
            self._reg_count = regs
        return self.active

    def unregister(self):
        from north.n9_cam import unregister_cam
        _, regs = unregister_cam(self.cam, verbose=True)
        if isinstance(regs, int):
            self._reg_count = regs
        return not self.active

    def dump_blackbox(self, proj_path):
        """
        Saves all blackbox data to an .avi file in the /captures/ sub-directory of the given project directory.

        Parameters
        ----------
        proj_path: Path
            The project directory.
        """
        if self._blackbox_frames.empty():
            logging.error(f'Cannot dump empty black-box feed.')
            return

        blackbox = list(self._blackbox_frames.queue)  # create a "frozen" copy for us to dump
        shape = tuple(reversed(blackbox[0].shape[:2]))
        blackbox_file = str(Path(proj_path).joinpath(f'captures\\blackbox_{get_current_timestamp()}.avi'))
        blackbox_output = cv2.VideoWriter(blackbox_file, VideoUtils.fourcc(), float(VideoUtils.STREAM_FPS), shape)

        for frame in blackbox:
            blackbox_output.write(frame)
        blackbox_output.release()


class VirtualCameraSource(_VisionSource):
    _last_id = 0

    @staticmethod
    def _get_id():
        VirtualCameraSource._last_id = VirtualCameraSource._last_id + 1
        return VirtualCameraSource._last_id

    def __init__(self, name: str = None,
                 position=(0.0, -0.6, 0.6),
                 rotation=(math.pi/4, -math.pi, 0.0),
                 fov=75, follow_end=False):
        """
        Virtual cameras are a way to view the simulator through the Vision View of the NorthIDE. They are useful for
        'mirroring' real-world cameras to ensure that the robot moves as simulated and to prepare computer vision trials
        without having to run the robot. They also include an 'end-effector' option, which will crop the source
        dynamically to the end-effector of the robot.

        Parameters
        ----------
        name: str, optional
            A name for the camera. If None is given, the `name` will be like 'virtual camera 0' etc.
        position: Tuple[float, float, float]
            The [x,y,z] position of the camera.
        rotation: Tuple[float, float, float]
            The [x,y,z] rotation of the camera.
        fov: int
            Field-of-view of the virtual camera.
        follow_end: bool
            If True, will enable 'end-effector' tracking.
        """
        super().__init__()
        assert name is None or isinstance(name, str)
        assert isinstance(position, tuple)
        assert len(position) == 3
        assert isinstance(fov, int) or isinstance(fov, float)

        self._id = self._get_id()
        self._name = name

        self._position = position
        self._rotation = rotation
        self._fov = fov

        self._follow_end = follow_end

    @property
    def src_id(self) -> str:
        return f'vcam_{self._id}'

    @property
    def shape_raw(self):
        return tuple((self._display.height, self._display.width, 3))

    @property
    def name(self):
        if self._name is None:
            return f'virtual camera {self._id}'
        else:
            return self._name

    @property
    def position(self):
        return self._position

    @property
    def rotation(self):
        return self._rotation

    @property
    def fov(self) -> Union[int, float]:
        """ Field-of-view """
        return self._fov

    @fov.setter
    def fov(self, value: float):
        assert isinstance(value, float) or isinstance(value, int)
        assert 0.0 < value < 360.0
        self._fov = float(value)

    @property
    def followend(self):
        """ True if dynamically following end-effector """
        return self._follow_end

    @followend.setter
    def followend(self, value: bool):
        assert isinstance(value, bool)
        self._follow_end = value
        # self._crop = self.get_wrist_bbox()

    @property
    def active(self):
        return self.valid_raw

    @property
    def _display(self):
        try:
            from northIDE import MVC
            return MVC.sim()._display
        except ImportError as e:
            logging.exception(e)

    def get_view_proj(self):
        """
        Get view, projection matrices for this virtual camera using the sim display dimensions (through MVC).

        Returns
        -------
        view: glm.mat4
            The view matrix.
        proj: glm.mat4
            The projection matrix.
        """
        assert self._display.width > 0
        assert self._display.height > 0
        pos = self.position
        view = glm.mat4()
        for i, rot in enumerate(self.rotation):
            axis = glm.vec3()
            axis[i] = 1.0
            view = glm.rotate(view, rot, axis)
        view = glm.translate(view, glm.vec3(pos))
        fov = np.deg2rad(self.fov)
        proj = glm.perspective(fov, (1.0 * self._display.width) / self._display.height, 0.1, 20)
        return view, proj

    def as_dict(self) -> dict:
        src_dict = super().as_dict()
        if self.followend:
            src_dict['crop'] = None
        src_dict['position'] = self.position
        src_dict['rotation'] = self.rotation
        src_dict['FOV'] = self.fov
        src_dict['follow_end'] = self.followend
        return src_dict

    def check_shape(self) -> bool:
        return self.valid_raw

    def update_follow(self):
        """
        Refreshes the end-effector crop

        Returns
        -------
        Tuple[float, float, float, float]
            The new crop, as percentages [0.0 - 1.0]
        """
        assert self.followend
        if not self._display.initialized or self._display.width == 0 or self._display.height == 0:
            return None  # may set a None crop
        w, h, minx, miny, maxx, maxy = self.get_wrist_rect()
        min_x_pct = clamp(minx, 0, w) / w
        min_y_pct = clamp(miny, 0, h) / h
        max_x_pct = clamp(maxx, 0, w) / w
        max_y_pct = clamp(maxy, 0, h) / h
        crop_pcts = (min_x_pct, min_y_pct, max_x_pct, max_y_pct)
        self.set(crop=crop_pcts)
        return crop_pcts

    def get_frame(self, apply_crop=True) -> np.ndarray:
        assert self.active
        if not self.check_shape():
            logging.error(f'{self.__class__.__name__}: Invalid shape')
            return None
        if not self._display.initialized:
            return None
        width, height = self._display.width, self._display.height
        src_frame = np.fliplr(self._display.renderer.get_virtual_cam_frame(width, height, self).reshape(self.shape_raw))
        return self.crop(src_frame) if apply_crop and self.cropped else src_frame

    def get_wrist_rect(self):  # for end-effector view
        """
        Get a rectangle of screen coordinates around the current position of the robot's wrist in the frame.

        Returns
        -------
        displayw: int
            Width of the display.
        displayh: int
            Height of the display.
        crop: Tuple[int, int, int, int]
            The rectangle points for the wrist rect. [x1, y1, x2, y2]
        """
        from northIDE import MVC
        project = MVC.project().current_proj
        if len(project.n9s) > 1:
            raise NotImplementedError('Getting wrist for one of multiple robots (implement a selector!)')
        elif len(project.n9s) == 1:
            n9 = project.n9s[0]
            model = self._display.scene.get_model(f'm_{n9.id}')
            end_effector = model.links[4]  # 4 == "wrist", disc that rotates gripper fingers

            tform = end_effector.transform
            bbox = end_effector.obj.get_bbox()
            pad_top = 0.0
            pad_bot = 0.1
            # pad minz rows ("bottom" of bbox)
            for point in bbox[0:4]:
                # z-coord in base == y-coord in world, so pad z-coord
                point[2] -= pad_bot
            # pad maxz rows ("top" of bbox)
            for point in bbox[4:]:
                point[2] += pad_top

            if self._display.width == 0 or self._display.height == 0:
                raise AttributeError("Tried getting wrist rect on a zero-area display.")
            view, proj = self.get_view_proj()
            xcoords = []
            ycoords = []
            for point in bbox:
                x, y, _ = self._display.renderer.projectTo2D(point, model=tform, view=view, proj=proj)
                try:  # we can bundle them up like this because x,y,z are always NaN at the same time
                    xcoords.append(int(x))
                    ycoords.append(int(y))
                except ValueError:
                    logging.warning(f'NaN from project, returning made up wrist crop')
                    return 0, 0, 100, 100
            displayw = self._display.winfo_width()
            displayh = self._display.winfo_height()
            # we have to invert OGL y-coords to get the correct screen-space coords for a tk.Canvas.
            # hence miny = displayh-max(ycoords) and vice versa.
            return displayw, displayh, min(xcoords), displayh-max(ycoords), max(xcoords), displayh-min(ycoords)
        else:  # no n9s in project
            raise NotImplementedError('Getting wrist for no robot (deactivate the button!)')

    def rename(self, new_name: str):
        """ Set a new name for the virtual camera """
        assert isinstance(new_name, str)
        self._name = new_name

    def reposition(self, new_pos: tuple):
        """ Set a new position for the virtual camera """
        assert isinstance(new_pos, tuple) or isinstance(new_pos, list)
        assert len(new_pos) == 3
        self._position = tuple(new_pos)

    def set_rotation(self, new_rot: tuple):
        """ Set a new rotation for the virtual camera """
        assert isinstance(new_rot, tuple) or isinstance(new_rot, list)
        assert len(new_rot) == 3
        self._rotation = tuple(new_rot)

    def register(self):
        if not self._display.initialized:
            from thonny import get_workbench
            get_workbench().show_view("SimulatorView")
        return self._display.renderer.add_virtual_camera(self)

    def unregister(self):
        return self._display.renderer.remove_virtual_camera(self)


class ImageSource(_VisionSource):
    def __init__(self, path):
        """
        A simple image source. `get_frame()` always returns the image.

        Parameters
        ----------
        path: Path
            Path to the image this source draws from.
        """
        super().__init__()
        assert isinstance(path, Path)
        self._path = path
        self._img = cv2.imread(str(self._path), cv2.IMREAD_COLOR)
        self._shape_raw = np.shape(self._img)
        self._visible = True

    @property
    def src_id(self):
        return f'img_{hash(self._path)}'

    @property
    def active(self):
        return True

    @property
    def name(self):
        return self._path.name

    @property
    def path(self):
        """ The filepath to the image """
        assert isinstance(self._path, Path)
        return self._path

    def as_dict(self):
        src_dict = super().as_dict()
        src_dict['path'] = str(self.path)
        return src_dict

    # these should always return the same value after init
    def check_shape(self) -> bool:
        return self.valid_raw

    def get_frame(self, apply_crop=True):
        return self.crop(self._img) if apply_crop and self.cropped else self._img

    def register(self):
        return True

    def unregister(self):
        return True


class FilterSource(_VisionSource):
    _last_id = 0

    @staticmethod
    def _get_id():
        FilterSource._last_id = FilterSource._last_id + 1
        return FilterSource._last_id

    def __init__(self, cfg=None):
        """
        A filter source is a unique source that cannot stand alone - it must have another vision source configured as
        its 'parent', from which it can `get_frame()` and then apply some filter and produce a result.

        Since a `FilterSource` may have another `FilterSource` as a parent, it is important for us to recursively check
        ancestry sometimes to ensure that if a `CameraSource` is an ancestor, it is registered and unregistered properly

        Parameters
        ----------
        cfg: dict, optional
            Configuration for the filter.
        """
        super().__init__()
        self._flt_id = self._get_id()
        self._flt_cfg = cfg if isinstance(cfg, dict) else dict()

        self._name = 'New Filter'
        self._filter = 'None'
        self._input: Optional[_VisionSource] = None

    @property
    def src_id(self):
        return f'flt_{self._flt_id}'

    @property
    def active(self):
        return self._input.active

    @property
    def has_input(self):
        """ True if an input has been configured """
        return self._input is not None

    @property
    def name(self):
        return self._name

    @property
    def filter(self):
        """ The name of the filter in use (ex. 'Edges') """
        return self._filter

    @property
    def flt_cfg(self):
        """ The configuration for the filter """
        return self._flt_cfg

    @property
    def input_id(self):
        """ `src_id` of the input vision source """
        assert self.has_input
        return self._input.src_id

    @property
    def ancestor_ids(self) -> list:
        """ Recursively generates a list of ancestor `src_id`s """
        if not self.has_input:
            return []
        else:
            return [self._input.src_id] + self._input.ancestor_ids if isinstance(self._input, FilterSource) else []

    def as_dict(self):
        src_dict = super().as_dict()
        src_dict['filter'] = self.filter
        src_dict['input'] = self.input_id if self.has_input else None
        src_dict['cfg'] = self.flt_cfg
        return src_dict

    def check_shape(self):
        assert self.has_input
        self._input.check_shape()
        self._shape_raw = self._input.shape
        return self.valid_raw

    def get_frame(self, apply_crop=True) -> np.ndarray:
        assert self.has_input
        assert self.check_shape()
        if isinstance(self._input, VirtualCameraSource) and self._input.followend:
            self._input.update_follow()
            assert self.check_shape()
        frame = self._input.get_frame()
        assert frame.shape == self._input.shape
        if apply_crop and self.cropped:
            frame = self.crop(frame)
        cfg = dict({'filter': self._filter, **self._flt_cfg})
        return VideoUtils.get_output_frame(cfg, frame)

    def register(self):
        assert self.has_input
        return self._input.register()

    def unregister(self):
        assert self.has_input
        return self._input.unregister()


def vision_src_from_dict(src_dict: dict):
    """
    Intialize and return a new vision source from a given dictionary.

    Parameters
    ----------
    src_dict: dict
        A dictionary (likely read from an .nproj file) specifying a vision source.

    Returns
    -------
    _VisionSource
        The initialized source.

    Raises
    ------
    ValueError
        If the source id string does not begin with a recognized type (ex. 'cam_', 'img_', etc.).
    """
    src_id = src_dict['id']
    visible = src_dict['visible']
    if src_id.startswith('cam_'):  # base camera
        src = CameraSource(int(src_dict['cam']))
    elif src_id.startswith('vcam_'):
        src = VirtualCameraSource(
            position=tuple(src_dict['position']),
            rotation=tuple(src_dict['rotation']),
            fov=int(src_dict['FOV']),
            follow_end=bool(src_dict['follow_end'])
        )
        src.set(id=int(src_id[5:]))
    elif src_id.startswith('img_'):
        src = ImageSource(Path(src_dict['path']))
    elif src_id.startswith('flt_'):
        src = FilterSource(cfg=src_dict['cfg'])
        src.set(name=src_dict['name'], filter=src_dict['filter'], flt_id=int(src_id[4:]))
    else:
        raise ValueError(f'Unrecognized source id: {src_id} ({type(src_id)})')
    src.set(visible=visible)
    return src
