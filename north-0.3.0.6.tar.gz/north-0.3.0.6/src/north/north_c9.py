"""
Defines NorthC9, used to interface with North Robotics controllers (C9, T8, etc). All commands for moving the robot
arm and other modules, querying sensor values, and more are in this class.
"""
import logging
import math
import threading
import sys
import os
import keyboard
import queue  # network queue

from dataclasses import dataclass, field # make objects that goes on the network queue
from sys import platform
from abc import ABC, abstractmethod, abstractproperty
from pathlib import Path
from typing import Any, Callable, Dict, Optional, List, Tuple, Union
from time import sleep, time, perf_counter
from inputs import get_gamepad, UnpluggedError  # the keyboard interface from 'inputs' module interferes with Thonny
from inspect import getframeinfo, stack, isgeneratorfunction

HAS_SERIAL = False
if platform == "win32":
    try:
        import ftdi_serial
        from ftdi_serial import Serial, SerialReadTimeoutException
        HAS_SERIAL = True
    except Exception as e:
        logging.warning('north: Could not initialize FTDI Serial package. Robot integration may be affected.')
        #logging.warning(e)
import serial

from north.north_project import Project, Controller  # this is here to avoid import loops from other modules that reference the API
import north.n9_kinematics as n9
from north import Scheduler

class AxisState:
    OFF = 0
    HOMING = 1
    HOME_COMPLETE = 2
    VELOCITY = 3
    VELOCITY_TARGET_REACHED = 4
    MOVE_ABS = 5
    MOVE_REL = 6
    MOVE_COMPLETE = 7
    STEP_DIR = 8
    ERROR = 9


class CmdToken:

    def __init__(self, status_func: Callable, value: any, axis: int = None, delay: float = 0.0, sim: bool = False):
        """
        A token for following up on the status of a non-blocking command, returned by commands with a "wait" keyword
        argument

        Parameters
        ----------
        status_func: Callable
            The function to call to check the status of the command
        value: any
            The value, returned by status_func, that represents a completed command
        axis: int
            The axis to pass as argument to the status_func [0, 7]
        delay: float
            Polling delay, in seconds, between calls to status_func
        sim: bool
            Is the CmdToken operating in the context of a simulation (i.e. c9.sim = True)
        """
        self.wait_func = status_func
        self.wait_value = value
        self.wait_axis = axis
        self.return_value = None
        self.delay = delay
        self.sim = sim

    def is_done(self) -> bool:
        """
        Query if the command is done

        Returns
        -------
        bool
            True if the command is done, False otherwise
        """
        if self.wait_axis is not None:
            result = self.wait_func(self.wait_axis)
        else:
            result = self.wait_func()

        if type(result) == tuple:  # this only handles the case for 2. todo: generalize
            self.return_value = result[1:]
            return result[0] == self.wait_value  # result[0]

        return result == self.wait_value

    def wait(self):
        """
        Block until the command is done.
        """
        sleep(self.delay)
        while not self.is_done():
            sleep(self.delay)
        sleep(self.delay)

class ADS1115:  # todo: refactor so as not to have to include this in main script
    # Values from ADS115 datasheet here: http://www.ti.com/lit/ds/symlink/ads1115.pdf

    # start/stop
    STOP_READ = 0
    START_READ = 1

    # mux
    AIN0_AIN1 = 0
    AIN0_AIN3 = 1
    AIN1_AIN3 = 2
    AIN2_AIN3 = 3
    AIN0_GND = 4
    AIN1_GND = 5
    AIN2_GND = 6
    AIN3_GND = 7

    # range
    V6_144 = 0
    V4_096 = 1
    V2_048 = 2
    V1_024 = 3
    V0_512 = 4
    V0_256 = 5

    # mode
    CONTINUOUS = 0
    ONE_SHOT = 1

    # data rates
    SPS8 = 0
    SPS16 = 1
    SPS32 = 2
    SPS64 = 3
    SPS128 = 4
    SPS250 = 5
    SPS475 = 6
    SPS860 = 7


class NorthC9:
    # TODO: Right now, this assumes all C9's are on the same network. Should be made more flexible
    # TODO: Change how serial is set up.. i.e. more configurable, from constructor, etc

    FREE = 0
    BUSY = 1

    GRIPPER = 0
    ELBOW = 1
    SHOULDER = 2
    Z_AXIS = 3
    CAROUSEL_ROT = 4
    CAROUSEL_Z = 5

    X = 0
    Y = 1
    Z = 2

    GRIPPER_DELAY = 0.2  # time it takes to open/close grippers
    CLAMP_DELAY = 0.3  # time it takes to open/close clamp

    DEFAULT_VEL = 5000
    DEFAULT_ACCEL = 50000
    MAX_VEL = 100000
    MAX_ACCEL = 500000

    # should these reference something external?
    GRIPPER_COUNTS_PER_REV = n9.GRIPPER_COUNTS_PER_REV
    ELBOW_COUNTS_PER_REV = n9.ELBOW_COUNTS_PER_REV
    SHOULDER_COUNTS_PER_REV = n9.SHOULDER_COUNTS_PER_REV
    Z_AXIS_COUNTS_PER_MM = n9.Z_AXIS_COUNTS_PER_MM

    ELBOW_OFFSET = n9.ELBOW_OFFSET
    SHOULDER_OFFSET = n9.SHOULDER_OFFSET
    Z_AXIS_OFFSET = n9.Z_AXIS_OFFSET  # test grippers - TODO: MAKE THIS GENERIC, TOOL IK ETC.

    ELBOW_MAX_COUNTS = n9.ELBOW_MAX_COUNTS
    SHOULDER_MAX_COUNTS = n9.SHOULDER_MAX_COUNTS
    Z_AXIS_MAX_COUNTS = n9.Z_AXIS_MAX_COUNTS

    SHOULDER_CENTER = n9.SHOULDER_CENTER
    SHOULDER_OUT = n9.SHOULDER_OUT

    POS_X = 0
    POS_Y = math.pi / 2
    NEG_X = math.pi
    NEG_Y = -math.pi / 2

    DEFAULT_TOOL_ORIENTATION = POS_X

    PUMP_VALVE_LEFT = 0
    PUMP_VALVE_RIGHT = 1
    PUMP_VALVE_CENTER = 2

    TEMP_HEAT = 0
    TEMP_COOL = 1
    TEMP_HEAT_COOL = 2
    TEMP_COOL_HEAT = 3

    SERIAL_PUMP_DELAY = 0.03  # small delay between requests to pumps because they operate at 9600 baud
    N_PUMP_RETRIES = 3  # how many times to retry a failed pump transmission
    ERROR_DELAY = 0.5  # how long to delay after a packet encounters an error before retrying, if enabled
    maximum_pos = [63000, 63000, 63000, 63000]  # TODO: set these accurately and intelligently

    def __init__(self, addr, network=None, network_serial=None, kf_only=False, experiment_log=False, verbose=False,
                 project=True, proj_path=None):

        """
        Represents a connection to a North Robotics controller: C9, T8, etc.

        Parameters
        ----------
        addr: str
            The address of the controller on the network, typically a capital character ('A', 'B', etc.). Use 'A' if
            unsure. Can also provide an integer 1-255 (0 reserved for broadcast).
        network: BaseControllerNetwork, optional
            A network object representing a connection to a controller network already instantiated by another NorthC9
            object. Use this if instantiating additional NorthC9 objects, passing network=prev_controller.network,
            where prev_controller is the first NorthC9 object declared in the script.
        network_serial: str, optional
            The unique address (serial number) of the FTDI USB to RS485 converter, i.e. the specific USB cable the
            commands should be sent on. This is roughly equivalent to a COM port number (e.g. 'COM3'). If this parameter
             is not passed, the driver will pick the first D2xx device in the list. Depending on what peripherals are
             attached to the PC and in what order they were attached, this may or may not be the controller network.
             To find the network_serial address of the cable used, use Tools -> List Device Serials in the NorthIDE.
        kf_only: bool, optional
            Simulations of commands sent to this controller will store only keyframe information, i.e. start and end
            position of each axis, rather than the entire animation. Useful for saving memory during longer simulations.
        experiment_log: bool, optional
            Deprecated. Writes a log of every message sent and received from the controller if True.
        verbose: bool, optional
            Will print additional messages to the shell.
        project: bool, optional
            Set to false if the controller should not try to load a corresponding North Project (*.nproj file) during
            initialization. If false, simulation, locations, and some pump functionality may not work as expected.
        proj_path: str, optional
            The path to a North Project to be loaded (for simulation, locations, pump functionality, etc.) that is not
            in the same directory as the script in which the NorthC9 object is instantiated.
        """
        parent_path = Path(proj_path) if proj_path is not None else Path(os.getcwd())
        self.verbose = verbose
        self.kf_only = kf_only

        self.proj = None
        if project:
            try:
                # try to load first project file from project directory of calling script
                self.proj = Project(parent_path)
            except (FileNotFoundError, IndexError):
                self.v_print("Warning: Failed to load project settings, project specific commands may "
                         "not function as expected")

        self._sim = bool((type(addr) == str and addr.lower() == 'sim')
                         or '-c9_sim' in sys.argv)
        self._is_highlight_disabled = '-no_highlight' in sys.argv

        self._simulate_all_packets = '-all_packets' in sys.argv

        if self._sim and not self.has_project:
            raise RuntimeError('Project required for simulation')

        try:
            self.c9_addr = int(addr)
        except ValueError:
            try:
                self.c9_addr = ord(addr)
            except TypeError:  # addr = 'sim'
                if addr.lower() != 'sim':  # we expect this error in this case
                    logging.error(f'north: c9_addr could not be set to {addr} ({type(addr)})')
                self.c9_addr = ord('A')

        self.c_id = None
        if self.has_project:
            for ctrl in self.proj.controllers:
                if ctrl.address == self.c9_addr:
                    self.c_id = ctrl.id
                    break

        # config pump settings from project data
        self.peri_pumps = {}
        if self.has_project:
            self.pumps = {p.address: {'pos': 0, 'volume': p.volume} for p in self.proj.pumps
                          if p.channels[0].controller_id == self.c_id}
        else:
            self.pumps = {i: {'pos': 0, 'volume': 1.0} for i in range(15)}

        # config sim inputs from project data
        self.sim_inputs = {}
        if self.has_project and self.sim:
            try:
                self.sim_inputs = self.proj.sim_inputs
            except KeyError:
                pass

        # todo: dateime, configurable naming
        exp_log_path = parent_path.joinpath('experiment_log.txt') if self.has_project and experiment_log else None

        # if not self.exp_log_file:
        #     pass
        #     # logging.warning('NorthC9: Did not initialize self.ledger')
        #     # logging.warning(F'self.proj: {self.proj} self.sim: {self.sim} self.exp_log: {self.exp_logging} parent_path: {parent_path}')

        if self.sim:
            if not isinstance(network, VirtualControllerNetwork):
                network = VirtualControllerNetwork(self, exp_log_path=exp_log_path)
            self._simulator = network.simulator
        elif platform == "win32":  # NOT self.sim
            if HAS_SERIAL and isinstance(network, Serial):
                network = FTDISerialControllerNetwork(network=network, exp_log_path=exp_log_path)
            elif network is None:
                network = FTDISerialControllerNetwork(network_serial=network_serial, exp_log_path=exp_log_path)
            assert isinstance(network, FTDISerialControllerNetwork)
            self._simulator = None
        else:  # not sim, not windows:
            if isinstance(network, serial.Serial):
                network = GenericSerialControllerNetwork(network=network, exp_log_path=exp_log_path)
            elif network is None:
                network = GenericSerialControllerNetwork(network_serial=network_serial, exp_log_path=exp_log_path)
            assert isinstance(network, GenericSerialControllerNetwork)
            self._simulator = None
        self.network = network
        assert isinstance(self.network, BaseControllerNetwork)  # interface enforcement

        if not self.sim:
            if 'quickstop_enabled' not in self.network.__dict__:
                self.network.__dict__['quickstop_enabled'] = True
                keyboard.add_hotkey('ctrl+alt+=', self.quick_stop)

        self._sending = False
        self._stop_requested = False

        self.default_vel = self.DEFAULT_VEL
        self.default_accel = self.DEFAULT_ACCEL
        self.safe_height = 292

        self.prev_cmd_token = None

        self.js_vel = [0, 0, 0, 0]
        self.key_speed = 1000  # counts/sec when key depressed

        self.err_cnt = 0

        self.version = 0.3  # apr_17_2023

        # benchmarking stuff #
        self._benchmarks = {
            "num_send": 0,
            "first_send": -1.0,
            "last_send": -1.0,
            # time aggregates
            "agg_time": 0.0,
            "agg_c9": 0.0,
            "agg_comm": 0.0,
            "agg_calc": 0.0,
            "agg_stat": 0.0
        }

        from north.n9_server import launch_north_server
        launch_north_server()

    def __del__(self):
        # # TODO this never really executes except at IDE shutdown
        pass
        # if self.sim and self.exp_log_file: # todo: remove 'and self.ledger'
        #     self.exp_log_file.close()

    @property
    def current_time(self) -> float:
        """
        The current time in seconds.

        Returns
        -------
        time: float
            The current time in seconds. If simulating, this is the number of seconds in 'sim time', what time it is in
            the simulation. If running, this is the number of seconds since epoch as returned by time.time().
        """
        if isinstance(self.network, BaseControllerNetwork):
            return self.network.time
        else:
            logging.error(f'NorthC9: current_time accessed before network initialization.')
            return 0.0

    @property
    def sim(self) -> bool:
        """
        Is the current controller object simulating or running on physical hardware?

        Returns
        -------
        is_sim: bool
            Returns true if simulating (commands are sent to a virtual network object), false if running (commands sent
            to a serial port).
        """
        return self._sim

    @property
    def has_project(self) -> bool:
        """
        Does the current controller object have a project?

        Returns
        -------
        has_project: bool
            Returns True if successfully loaded a project, False otherwise.
        """
        return isinstance(self.proj, Project)

    @property
    def has_simulator(self) -> bool:
        """
        Does the current controller object have a simulator?

        Returns
        -------
        has_simulator: bool
            Returns True if successfully instantiated a simulator object, False otherwise.
        """
        return self._simulator is not None

    @property
    def simulator(self):
        """
        The controller's Simulator object

        Returns
        -------
        simulator: The controller's Simulator object
        """
        return self._simulator

    @property
    def simulate_all_packets(self):
        """
        The simulate all packets command line argument option

        Returns
        -------
        simulate_all_packets: bool
        """
        return self._simulate_all_packets

    def is_highlight_disabled(self):
        """
        Line highlighting status accessor

        Returns
        -------
        is_highlight_disabled: bool
            If True, information is sent from the script being simulated to the IDE in order to highlight the relevant
            line in the Editor.
        """
        return self._is_highlight_disabled

    def _validate_vel_accel(self, vel, accel):
        # TODO: optional joint= parameter for specific validation
        if vel is None:
            vel = self.default_vel
        vel = int(vel)
        if vel < 0:
            vel = 0
        elif 0 <= vel <= 100:  # interpret as percentage:
            vel = int(vel / 100 * self.MAX_VEL)
        if vel > self.MAX_VEL:  # enforce max value
            vel = self.MAX_VEL

        if accel is None:
            accel = 10*vel
        accel = int(accel)
        if accel < 0:
            accel = 0
        elif 0 <= accel <= 100:  # interpret as percentage:
            accel = int(accel / 100 * self.MAX_ACCEL)
        if accel > self.MAX_ACCEL:
            accel = self.MAX_ACCEL
            
        return vel, accel

    def delay(self, sec: float, is_threaded=False):
        """
        Do nothing for sec seconds. Will call time.sleep(sec) if running, but will only simulate the delay if
        simulating. Thus, NorthC9.delay() is preferred to time.sleep to avoid unnecessarily long simulation calc time.
        Parameters
        ----------
        sec: float
            The number of seconds for which to delay.
        """
        if self.sim:
            if is_threaded:  # self.is_threaded
                target_time = self.current_time + sec
                # TODO: should we make some sort of call to DLAY her anyway to allow for line highlighting?
                while self.current_time < target_time:
                    self.network.heartbeat_event.wait()
                return
            self.send_packet('DLAY', [int(sec*1000)])
        else:
            sleep(sec)

    def v_print(self, *args):
        """
        Prints to shell if NorthC9.verbose is True. Mostly used internally.

        Parameters
        ----------
        args:
            The args to pass to print(*args)

        """
        if self.verbose:
            print(*args)


    def send_packet(self, command, args_list =[], broadcast=False, stop_request=False, wait=True, retries=0) -> [int]:
        """
        Private - internal use only
        """
        request_buffer = [command]
        for arg in args_list:
            request_buffer += [str(int(arg))]
            
        if broadcast:
            addr = b'\x00'
        else:
            addr = bytes([self.c9_addr])
        expect_response = addr != b'\x00'  # expect a response if not a broadcast packet
        request_bytes = addr \
                        + b'\x20' \
                        + ' '.join(request_buffer).encode(encoding='charmap')
        request_bytes += b'\x20'
        if self.sim: # insert wait bool at head of request iff simulating
            request_bytes = (b'1' if wait else b'0') + request_bytes

        if self._stop_requested and not stop_request:
            sleep(1.0)
            sys.exit()

        response_args = []
        try_cnt = 0
        error = Exception()  # dummy exception to get into while loop
        while error is not None and try_cnt <= retries:
            error = None
            try_cnt += 1
            response_bytes = None
            self._sending = True
            self.log("Sent", request_bytes)
            try:
                response_bytes = self.network.send(request_bytes, expect_response=expect_response)
            except Exception as e:
                self._sending = False
                #logging.exception(e)
                self.log(e)
                error = e  # TimeoutError("Communication with the controller timed out...")
                sleep(self.ERROR_DELAY)
            self._sending = False

            if response_bytes is None:  # ran into an error
                continue

            self.log("Received", response_bytes)

            response_args = None
            if expect_response:
                response_terms = response_bytes.split(b' ')
                response_cmd = response_terms[1]
                response_args = response_terms[2:-1]
                if response_cmd == b'BUFF':
                    response_data = response_bytes[6:-1]
                    response_args = [response_data]
                else:
                    response_args = [int(arg.decode()) for arg in response_args]

                if response_cmd == b'ERR!':
                    print("Received", response_bytes)
                    error = RuntimeError(C9Errors(response_args[0], response_args[1]))
                    self.log(error)
                    sleep(self.ERROR_DELAY)

        if error is not None:
            raise error

        return response_args

    # todo: obsolete - decide what to do here
    # def tag(self, *args):
    #     """
    #     Add a tag to the experiment log to help with parsing
    #
    #     Parameters
    #     ----------
    #     args:
    #         List of arguments added to the log as such: "Z TAG arg1 arg2 arg3 ..."
    #     """
    #     self._exp_log('Z TAG ' + ' '.join([str(i) for i in args]))

    def log(self, *args, **kwargs):
        if self.verbose:
            print(*args, **kwargs)

    def get_info(self):
        """
        Used as a ping command to check connection with the controller. Logs the FW version, prints if verbose.
        """
        # TODO: handle floating point FW version
        args = self.send_packet('INFO')
        print("Connected to C9 at address", self.c9_addr)
        self.v_print("Firmware Version:", args[0])

    def get_axis_status(self, axis: int) -> int:
        """
        Get the state of a controller axis

        Parameters
        ----------
        axis: int
            The number of the axis to query in the range [0, 7]

        Returns
        -------
        int
            The state of the axis, int corresponding to the enumeration in the AxisState class
        """
        bench = perf_counter()
        args = self.send_packet('AXST', [axis])
        self._benchmarks["agg_stat"] += perf_counter() - bench
        return args[0]

    def get_sequence_status(self):
        """
        Get the status of the command executing on the FW as a sequence, i.e. NorthC9.home_robot()

        Returns
        -------
        int
            NorthC9.FREE if the command is complete or NorthC9.BUSY otherwise

        """
        bench = perf_counter()
        args = self.send_packet('SQST')
        self._benchmarks["agg_stat"] += perf_counter() - bench
        return args[0]

    def get_robot_status(self):
        """
        Get the status of a multi-axis move (applies to all axes, not just N9 robot arm axes)
        Returns
        -------
            NorthC9.FREE if the move is complete or NorthC9.BUSY otherwise

        """
        bench = perf_counter()
        args = self.send_packet('ROST')
        self._benchmarks["agg_stat"] += perf_counter() - bench
        return args[0]

    def _dry_run_func_est_time(self, func, args_list=None, kwargs_dict=None):
        """
        :param func: Function which (presumably) has axis simulation calls.
        :return: Floating-pt time estimate.
        """
        assert isinstance(func, Callable)
        assert self.has_simulator

        if args_list is None:
            args_list = []
        if kwargs_dict is None:
            kwargs_dict = {}

        self.simulator.start_dryrun()
        time_pre = self.current_time
        try:
            if isgeneratorfunction(func):
                next(func(*args_list, **kwargs_dict))
            else:
                func(*args_list, **kwargs_dict)
        except Exception as e:
            logging.error('NorthC9: exception while estimating function time (below):')
            logging.exception(e)
        time_post = self.current_time
        self.simulator.end_dryrun()
        return time_post - time_pre

    def get_time_est(self, task: Callable, args_list: Optional[List[Any]] = None,
                     kwargs_dict: Optional[Dict[str, Any]] = None) -> float:
        """
        Get a simulator estimate of the amount of time it will take to execute a task

        Parameters
        ----------
        task: Callable
            The function, generator, or task whose time to estimate
        args_list: Optional[List[Any]]
            List of positional arguments to pass to the task
        kwargs_dict: Optional[Dict[str, Any]]
            Dict of keyword arguments to pass to the task, keys are the keywords, values are the arguments themselves

        Returns
        -------
        float:
            Estimated time in seconds

        """

        from north.north_sched import Task
        assert isinstance(task, Task) or isinstance(task, Callable)
        name = task.name if isinstance(task, Task) else task.__name__
        func = task.func if isinstance(task, Task) else task
        estimate = self._dry_run_func_est_time(func, args_list, kwargs_dict)
        print(f"Estimated time for '{name}' is {estimate}s")
        return estimate

    def quick_stop(self):
        """
        Stop the N9 robot arm immediately. Note, this is not a replacement for the EStop button.

        """
        self._stop_requested = True
        print('waiting to send stop request')
        while self._sending:
            pass
        print('sending stop request')
        self.send_packet('QSTP', broadcast=True, stop_request=True)
        print('Quick stop active, home robot before continuing, exiting...')
        self._stop_requested = False

    ######################################
    ##                                  ##
    ##             HOMING               ##
    ##                                  ##
    ######################################

    def home_axis(self, axis: int, wait: bool =True) -> CmdToken:
        """
        Start the homing procedure for a given axis. The specifics of the homing method depend on the axis'
        configuration file on the controller. Axes must be homed before moving after power on, but should not need to be
        re-homed until the next power cycle.

        Parameters
        ----------
        axis: int
            The axis number [0, 7] to home
        wait: bool, optional
            If true, this command blocks until the axis is homed.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the command or wait for it
            to finish if wait=False.
        """
        self.v_print("Homing axis", axis)
        self.send_packet('HOAX', [axis], wait=wait)
        return self.new_cmd_token(self.get_axis_status, AxisState.HOME_COMPLETE, axis, wait)

    def home_robot(self, wait: bool = True) -> CmdToken:
        """
        Start the homing procedure for the N9 robot arm. Homes the Z-Axis first to lift the rest of the arm to a safe
        height, then homes the remaining 3 axes concurrently. Also disables air channels 0 and 1, typically configured
        as the gripper teeth and vial clamp, respectively. Axes must be homed before moving after power on, but should
        not need to be re-homed until the next power cycle.

        Parameters
        ----------
        wait: bool, optional
            If true, this command blocks until the robot is homed.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the command or wait for it
            to finish if wait=False.
        """
        self.v_print("Homing robot")
        self.send_packet('HORO', wait=wait)
        return self.new_cmd_token(self.get_sequence_status, self.FREE, wait=wait)

    def get_home_offset(self, axis: int) -> int:
        """
        Return the home offset parameter stored in FW on the controller for the given axis. Home offset is an int value
        in units of counts assigned to an axis after homing. It is used to calibrate the robot, aligning the joint-space
        coordinate system of counts with the cartesian coordinate system of mm.

        Parameters
        ----------
        axis: int
            The axis number [0, 7] to query

        Returns
        -------
        int
            The home offset value, in units of counts.
        """
        args = self.send_packet('GHOO', [axis])
        self.v_print("Home offset for axis", axis, "is", args[0])
        return args[0]

    def set_home_offset(self, axis: int, offset: int):
        """
        Assign the home offset parameter stored in FW on the controller for the given axis. Home offset is an int value
        in units of counts assigned to an axis after homing. It is used to calibrate the robot, aligning the joint-space
        coordinate system of counts with the cartesian coordinate system of mm.

        Parameters
        ----------
        axis: int
            The axis number [0, 7] to write to
        offset: int
            The value of the home offset, in units of counts
        """
        self.send_packet('SHOO', [axis, offset])
        self.v_print("Set home offset for axis", axis, "to", offset)

    def home_OL_stepper(self, axis: int, home_length: int, vel: int = 1000, accel: int = 50000):
        """
        Start the homing procedure for an open-loop stepper motor. Since open-loop steppers do not have any sensor
        feedback, they home by travelling backwards their maximum axis length in units of counts to ensure they start
        from a known position. This often results in the axis running against the hardstop of the home position for some
        portion of the home procedure, causing a buzz. This is intentional and safe.

        Parameters
        ----------
        axis: int
            The axis of the open-loop stepper to home [0, 7]
        home_length: int
            The maximum length of travel of the axis in units of counts, i.e. the number of counts of backwards travel
            to move in the worst-case scenario to ensure the axis reaches the home position.
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).

        """
        # TODO: support wait=False
        pos = self.get_axis_position(axis)
        self.move_axis(axis, pos - home_length, vel=vel, accel=accel)
        self.home_axis(axis)
        self.delay(1)

    def home_CL_stepper(self, axis: int, vel: int = 1000, accel: int = 50000):
        """
        Start the homing procedure for a closed-loop stepper motor. The stepper first moves a small amount in the
        positive direction (away from home) to ensure it is not touching the home stop. This procedure has a 3-second
        timeout if it happens to hit the positive stop. Finally, the true axis home procedure is called.

        Parameters
        ----------
        axis: int
            The axis of the closed-loop stepper to home [0, 7]
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).

        """
        # TODO: support wait=False
        timeout = 3
        pos = self.get_axis_position(axis)
        time_start = time()
        move = self.move_axis(axis, pos + 1100, vel=vel, accel=accel, wait=False)
        while time() - time_start < timeout:
            if move.is_done():
                break
        self.home_axis(axis)

    def home_carousel(self):
        """
        Homes the carousel module. First the Z-Axis is homed to prevent rotary-axis collisions. Next, the rotary axis
        is homed. Carousel axes are set with the CAROUSEL_Z and CAROUSEL_ROT class variables.

        """
        # TODO: wait logic
        self.v_print("Homing carousel")
        self.home_axis(self.CAROUSEL_Z)
        self.home_axis(self.CAROUSEL_ROT)

    ######################################
    ##                                  ##
    ##             MOVING               ##
    ##                                  ##
    ######################################

    def move_axis(self, axis: int, cts: int, vel: Optional[int] = None, accel: Optional[int] = None,
                  wait: bool = True) -> CmdToken:
        """
        Move an axis to the given position in units of counts.

        Parameters
        ----------
        axis: int
            The axis to move [0, 7]
        cts: int
            The position to which to move the axis, in units of counts
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).
        wait: bool, optional
            If true, this command blocks until the move is finished.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the move or wait for it
            to finish if wait=False.
        """
        pos = int(cts)
        vel, accel = self._validate_vel_accel(vel, accel)
        # if 0 <= axis <= 3 and pos > self.maximum_pos[axis]:
        # pos = self.maximum_pos[axis]
        self.v_print("Moving axis", axis, "to", pos)
        self.send_packet('MOAX', [axis, pos, vel, accel], wait=wait)
        return self.new_cmd_token(self.get_axis_status, AxisState.MOVE_COMPLETE, axis, wait)

    def move_robot_cts(self, gripper_cts: int, elbow_cts: int, shoulder_cts: int, z_cts: int, vel: Optional[int] = None,
                       accel: Optional[int] = None, wait: bool = True) -> CmdToken:
        """
        Move the N9 robot arm to the given pose in units of counts. During the move, velocities of each axis are scaled
        such that all joints start and stop moving together. The velocity value for the move represents the maximum
        velocity of the axis that is moving the largest number of counts, the maximum velocities of all other moving
        axes are correspondingly scaled down.

        Parameters
        ----------
        gripper_cts: int
            Target gripper position in units of counts
        elbow_cts: int
            Target elbow position in units of counts
        shoulder_cts: int
            Target shoulder position in units of counts
        z_cts: int
            Target z-axis position in units of counts
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s. Note velocity scaling that may occur as explained in
            function description.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).
        wait: bool, optional
            If true, this command blocks until the move is finished.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the move or wait for it
            to finish if wait=False.
        """
        gripper_cts = int(gripper_cts)
        elbow_cts = int(elbow_cts)
        shoulder_cts = int(shoulder_cts)
        z_cts = int(z_cts)
        vel, accel = self._validate_vel_accel(vel, accel)
        pos = [gripper_cts, elbow_cts, shoulder_cts, z_cts]
        for axis in range(4):
            if axis > 0 and pos[axis] > self.maximum_pos[axis]:
                pos[axis] = self.maximum_pos[axis]
        self.v_print("Moving robot to", pos)
        self.send_packet('MORO', [gripper_cts, elbow_cts, shoulder_cts, z_cts, vel, accel], wait=wait)
        return self.new_cmd_token(self.get_robot_status, self.FREE, wait=wait)

    def move_sync(self, axis0: int, axis1: int, cts0: int, cts1: int, vel: Optional[int] = None,
                  accel: Optional[int] = None, wait: bool = True) -> CmdToken:
        """
        Move any two axes simultaneously. During the move, velocities of each axis are scaled
        such that all joints start and stop moving together. The velocity value for the move represents the maximum
        velocity of the axis that is moving the largest number of counts, the maximum velocities of all other moving
        axes are correspondingly scaled down.

        Parameters
        ----------
        axis0: int
            The number of the first axis to move [0, 7]
        axis1: int
            The number of the second axis to move [0, 7]
        cts0: int
            The position, in units of counts, to which to move the first axis
        cts1: int
            The position, in units of counts, to which to move the second axis
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s. Note velocity scaling that may occur as explained in
            function description.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).
        wait: bool, optional
            If true, this command blocks until the move is finished.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the move or wait for it
            to finish if wait=False.
        """
        vel, accel = self._validate_vel_accel(vel, accel)
        self.v_print("Synchronous move started")
        self.send_packet('SYNC', [axis0, axis1, cts0, cts1, vel, accel], wait=wait)
        return self.new_cmd_token(self.get_robot_status, self.FREE, wait=wait)

    def move_axis_mm(self, axis: int, mm: float, vel: Optional[int] = None, accel: Optional[int] = None,
                     wait: bool = True) -> CmdToken:
        """
        Move an axis to a given position in units of mm. Only applies to axes that move linearly, not rotationally.

        Parameters
        ----------
        axis: int
            The number of the axis to move [0, 7]. Must be an axis that moves linearly, not rotationally.
        mm: float
            The position to which to move in units of mm
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).
        wait: bool, optional
            If true, this command blocks until the move is finished.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the move or wait for it
            to finish if wait=False.
        """
        return self.move_axis(axis, self.mm_to_counts(axis, mm), vel=vel, accel=accel, wait=wait)

    def move_z(self, mm: float, vel: Optional[int] = None, accel: Optional[int] = None, wait: bool = True):
        """
        Move the z-axis to a given position in units of mm.

        Parameters
        ----------
        mm: float
            The target position for the z-axis in units of mm [30, 292]
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).
        wait: bool, optional
            If true, this command blocks until the move is finished.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the move or wait for it
            to finish if wait=False.

        """
        return self.move_axis_mm(self.Z_AXIS, mm, vel=vel, accel=accel, wait=wait)

    def move_xy(self, x: float, y: float, pipette_tip_offset: bool = False,
                shoulder_preference: int = n9.SHOULDER_CENTER, vel: Optional[int] = None, accel: Optional[int] = None,
                wait: bool = True) -> CmdToken:
        """
        Move the elbow and shoulder joints such that the end-effector (EE) is at a given (x, y) position in units of mm.
        The target position must be in the robot's work envelope, i.e. must have a valid inverse-kinematic solution. The
        EE may be either the gripper or pipette tip probe. During the move, velocities of each axis are scaled
        such that all joints start and stop moving together. The velocity value for the move represents the maximum
        velocity of the axis that is moving the largest number of counts, the maximum velocities of all other moving
        axes are correspondingly scaled down.

        Parameters
        ----------
        x: int
            The target x-position of the EE in units of mm [-340, 340]
        y: int
            The target y-position of the EE in units of mm [-340, 340]
        pipette_tip_offset: bool
            If True, the EE is considered to be the pipette tip probe, otherwise it is the center of the N9 gripper.
        shoulder_preference: {NorthC9.SHOULDER_CENTER, NorthC9.SHOULDER_OUT}
            Determines the kinematic solution to achieve the target position. If SHOULDER_CENTER, the N9 will achieve
            the target position such that the shoulder joint is closer to the cartesian Y axis. If SHOULDER_OUT, the
            target position will be achieved with the opposite pose.
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s. Note velocity scaling that may occur as explained in
            function description.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).
        wait: bool, optional
            If true, this command blocks until the move is finished.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the move or wait for it
            to finish if wait=False.
        """
        # TODO: need move_sync_n in fw to move n axes synchronously (have to add gripper w/out z to this axis for tool
        #       support)
        _, theta_elbow, theta_shoulder = self.n9_ik(x=x,
                                                    y=y,
                                                    tool_length=0,
                                                    tool_orientation=None,
                                                    pipette_tip_offset=pipette_tip_offset,
                                                    shoulder_preference=shoulder_preference)
        elbow_cts = self.rad_to_counts(self.ELBOW, theta_elbow)
        shoulder_cts = self.rad_to_counts(self.SHOULDER, theta_shoulder)
        self.v_print(elbow_cts, shoulder_cts)
        return self.move_sync(self.ELBOW, self.SHOULDER, elbow_cts, shoulder_cts, vel, accel, wait)

    def move_xyz(self, x: float, y: float, z: float, tool_offset: Optional[List[float]] = None,
                 tool_orientation: Optional[float] = None, pipette_tip_offset: bool = False,
                 shoulder_preference: int = n9.SHOULDER_CENTER, vel: Optional[int] = None, accel: Optional[int] = None,
                 wait: bool = True) -> CmdToken:
        """
        Move the N9 robot arm such that the end-effector (EE) is located at the target (x, y, z) position in units of
        mm.The target position must be in the robot's work envelope, i.e. must have a valid inverse-kinematic solution.
        The EE may be the gripper, pipette tip probe, or may be selected arbitrarily using the tool_offset parameter.
        The tool_orientation parameter may be used to set the angle of the gripper joint. During the move, velocities of
        each axis are scaled such that all joints start and stop moving together. The velocity value for the move
        represents the maximum velocity of the axis that is moving the largest number of counts, the maximum velocities
        of all other moving axes are correspondingly scaled down.

        Parameters
        ----------
        x: int
            The target x-position of the EE in units of mm
        y: int
            The target y-position of the EE in units of mm
        z: int
            The target z-position of the EE in units of mm
        tool_offset: List[float], optional
            A list of 3 floats corresponding the length of the tool in the x, y, and z axes respectively
        tool_orientation: float, optional
            The rotation of the gripper with respect to the global cartesian x-axis in units of degrees
        pipette_tip_offset: bool
            If True, the EE is considered to be the pipette tip probe, otherwise it is the center of the N9 gripper.
        shoulder_preference: {NorthC9.SHOULDER_CENTER, NorthC9.SHOULDER_OUT}
            Determines the kinematic solution to achieve the target position. If SHOULDER_CENTER, the N9 will achieve
            the target position such that the shoulder joint is closer to the cartesian Y axis. If SHOULDER_OUT, the
            target position will be achieved with the opposite pose.
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s. Note velocity scaling that may occur as explained in
            function description.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).
        wait: bool, optional
            If true, this command blocks until the move is finished.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the move or wait for it
            to finish if wait=False.
        """
        if tool_offset is None: tool_offset = [0, 0, 0]
        if pipette_tip_offset: tool_offset[self.Z] = -28

        if tool_orientation is not None:
            tool_orientation = math.radians(tool_orientation)

        theta_gripper, theta_elbow, theta_shoulder = self.n9_ik(x=x,
                                                                y=y,
                                                                tool_length=tool_offset[self.X],
                                                                tool_orientation=tool_orientation,
                                                                pipette_tip_offset=pipette_tip_offset,
                                                                shoulder_preference=shoulder_preference)
        gripper_cts = self.rad_to_counts(self.GRIPPER, theta_gripper)
        elbow_cts = self.rad_to_counts(self.ELBOW, theta_elbow)
        shoulder_cts = self.rad_to_counts(self.SHOULDER, theta_shoulder)
        z_axis_cts = self.mm_to_counts(self.Z_AXIS, z+tool_offset[self.Z])
        self.v_print(elbow_cts, shoulder_cts, z_axis_cts)
        return self.move_robot_cts(gripper_cts, elbow_cts, shoulder_cts, z_axis_cts, vel=vel, accel=accel, wait=wait)

    def move_axis_rad(self, axis: int, rad: float, vel: Optional[int] = None, accel: Optional[int] = None,
                      wait: bool = True) -> CmdToken:
        """
        Move the given axis to a target angle specified in units of radians. Must be an axis that moves rotationally,
        not linearly.

        Parameters
        ----------
        axis: int
            The number of the axis to move [0, 7]. Must be an axis that moves rotationally, not linearly.
        rad: float
            The target angle in radians to which to move the axis.
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).
        wait: bool, optional
            If true, this command blocks until the move is finished.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the move or wait for it
            to finish if wait=False.
        """
        return self.move_axis(axis, self.rad_to_counts(axis, rad), vel=vel, accel=accel, wait=wait)

    def move_robot(self, gripper_rad: float, elbow_rad: float, shoulder_rad: float, z_mm: float,
                   vel: Optional[int] = None, accel: Optional[int] = None, wait: bool = True) -> CmdToken:
        """
        Move the N9 robot arm to the given pose in units of rads (for rotational axes) and mm (for the z-axis). During
        the move, velocities of each axis are scaled such that all joints start and stop moving together. The velocity
        value for the move represents the maximum velocity of the axis that is moving the largest number of counts, the
        maximum velocities of all other moving axes are correspondingly scaled down.

        Parameters
        ----------
        gripper_rad: float
            Target gripper angle in units of radians
        elbow_rad: float
            Target elbow angle in units of radians [-(5/6)*pi, (5/6)*pi]
        shoulder_rad
            Target elbow angle in units of radians [-(2/3)*pi, (2/3)*pi]
        z_mm
            Target z-axis position in units of mm [30, 292]
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s. Note velocity scaling that may occur as explained in
            function description.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).
        wait: bool, optional
            If true, this command blocks until the move is finished.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the move or wait for it
            to finish if wait=False.
        """

        gripper_cts = self.rad_to_counts(self.GRIPPER, gripper_rad)
        elbow_cts = self.rad_to_counts(self.ELBOW, elbow_rad)
        shoulder_cts = self.rad_to_counts(self.SHOULDER, shoulder_rad)
        z_cts = self.mm_to_counts(self.Z_AXIS, z_mm)
        vel, accel = self._validate_vel_accel(vel, accel)
        pos = [gripper_cts, elbow_cts, shoulder_cts, z_cts]
        for axis in range(4):
            if axis > 0 and pos[axis] > self.maximum_pos[axis]:
                pos[axis] = self.maximum_pos[axis]
        self.v_print("Moving robot to", pos)
        self.send_packet('MORO', [gripper_cts, elbow_cts, shoulder_cts, z_cts, vel, accel], wait=wait)
        return self.new_cmd_token(self.get_robot_status, self.FREE, wait=wait)

    def goto(self, loc_list: List[int], vel: Optional[int] = None, accel: Optional[int] = None,
             wait: bool = True) -> CmdToken:
        """
        Move the N9 robot arm such that the end-effector (EE) is at the target Location. A Location is a joint space
        pose in units of counts, given as a list of four integers. These can be created conveniently in the NorthIDE
        GUI, though this is not necessary. During the move, velocities of each axis are scaled such that all joints
        start and stop moving together. The velocity value for the move represents the maximum velocity of the axis that
        is moving the largest number of counts, the maximum velocities of all other moving axes are correspondingly
        scaled down.

        Parameters
        ----------
        loc_list: List[int] (Location)
            The target pose, in units of counts, given as [gripper, elbow, shoulder, z-axis]
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s. Note velocity scaling that may occur as explained in
            function description.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).
        wait: bool, optional
            If true, this command blocks until the move is finished.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the move or wait for it
            to finish if wait=False.
        """
        return self.move_robot_cts(loc_list[0], loc_list[1], loc_list[2], loc_list[3], vel, accel, wait=wait)

    def goto_xy_safe(self, loc_list: List[int], safe_height: Optional[int] = None, vel: Optional[int] = None,
                     accel: Optional[int] = None):
        """
        Move the N9 robot arm such that the end-effector (EE) is at the (x, y) position of the target Location, but
        first move the Z-Axis to the safe_height to avoid a collision. The final position of the end effector is thus
        at (x, y, safe_height). A Location is a joint space pose in units of counts, given as a list of four integers.
        These can be created conveniently in the NorthIDE GUI, though this is not necessary. During the move, velocities
        of each axis are scaled such that all joints start and stop moving together. The velocity value for the move
        represents the maximum velocity of the axis that is moving the largest number of counts, the maximum velocities
        of all other moving axes are correspondingly scaled down.

        Parameters
        ----------
        loc_list: List[int] (Location)
            The target pose, in units of counts, given as [gripper, elbow, shoulder, z-axis]
        safe_height: int, optional
            The height, in units of cnts, to which to move the z-axis before moving the elbow and shoulder joints to
            achieve the target (x, y). If not given, the z-axis will move to its maximum height.
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s. Note velocity scaling that may occur as explained in
            function description.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).
        """
        safe_height = self.safe_height if safe_height is None else safe_height
        self.move_axis(self.Z_AXIS, n9.mm_to_counts(n9.Z_AXIS, safe_height), vel=vel, accel=accel, wait=True)
        self.move_robot_cts(loc_list[self.GRIPPER], loc_list[self.ELBOW], loc_list[self.SHOULDER],
                            n9.mm_to_counts(n9.Z_AXIS, safe_height), vel=vel, accel=accel, wait=True)

    def goto_z(self, loc_list: List[int], vel: Optional[int] = None, accel: Optional[int] = None,
               wait: bool = True) -> CmdToken:
        """
        Move the Z-Axis to the target z-location of the given Location. A Location is a joint space pose in units of counts, given as a list of four integers.
        These can be created conveniently in the NorthIDE GUI, though this is not necessary.

        Parameters
        ----------
        loc_list: List[int] (Location)
            The target pose, in units of counts, given as [gripper, elbow, shoulder, z-axis]
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s. Note velocity scaling that may occur as explained in
            function description.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).
        wait: bool, optional
            If true, this command blocks until the move is finished.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the move or wait for it
            to finish if wait=False.
        """
        return self.move_axis(self.Z_AXIS, loc_list[self.Z_AXIS], vel=vel, accel=accel, wait=wait)

    # TODO: add wait fcnality here - software sequence?
    def goto_safe(self, loc_list: List[int], safe_height: Optional[int] = None, vel: Optional[int] = None,
                  accel: Optional[int] = None):
        """
        Move the N9 robot arm such that the end-effector (EE) is at the (x, y, z, theta) position of the target
        Location. The arm moves up to the safe_height, "over" to the (x, y, theta) position, then down to the final z
        height. A Location is a joint space pose in units of counts, given as a list of four integers. These can be
        created conveniently in the NorthIDE GUI, though this is not necessary. During the move, velocities of each axis
        are scaled such that all joints start and stop moving together. The velocity value for the move represents the
        maximum velocity of the axis that is moving the largest number of counts, the maximum velocities of all other
        moving axes are correspondingly scaled down.

        Parameters
        ----------
        loc_list: List[int] (Location)
            The target pose, in units of counts, given as [gripper, elbow, shoulder, z-axis]
        safe_height: int, optional
            The height, in units of counts, to which to move the z-axis before moving the elbow and shoulder joints to
            achieve the target (x, y). If not given, the z-axis will move to its maximum height.
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s. Note velocity scaling that may occur as explained in
            function description.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).
        """
        self.goto_xy_safe(loc_list, safe_height=safe_height, vel=vel, accel=accel)
        self.goto_z(loc_list, vel=vel, accel=accel)

    def move_carousel(self, rot_deg: float, z_mm: float, safe_height: int = 0, vel: Optional[int] = None,
                      accel: Optional[int] = None):
        """
        Move the carousel module to the specified degrees of rotation and height. First moves the carousel z-axis to
        safe_height, then rotates the plate to the desired angle, then moves the z-axis down to the target height. A
        position of (0*, 0mm) corresponds to the home position.

        Parameters
        ----------
        rot_deg: float
            The angle to which to rotate the carousel, in degrees relative to the home position.
        z_mm: float
            The amount to lower the carousel z-axis, in mm relative to the top position.
        safe_height: int, optional
            The height to which to raise the carousel before rotating the plate, in units of counts.
        vel: int, optional
            Max velocity of the move in units of counts per second [0, 100000]. Values [0, 100] are interpreted as a
            percentage of the maximum velocity (100000 cts/s). If the accel parameter is not given, the acceleration
            will be set to 10x the velocity in units of cts/s/s.
        accel: int, optional
            Constant acceleration of the axis to reach the given velocity, in units of counts per second^2 [0, 500000].
            Values [0, 100] are interpreted as a percentage of the maximum acceleration (500000 cts/s).
        """
        if rot_deg < 0:
            rot_deg = 0
        elif rot_deg > 330:
            rot_deg = 330
        if z_mm < 0:
            z_mm = 0
        elif z_mm > 100:
            z_mm = 100

        self.move_axis(self.CAROUSEL_Z, safe_height, vel=vel, accel=accel)
        self.move_axis(self.CAROUSEL_ROT, int(rot_deg * (51000 / 360)), vel=vel, accel=accel)
        self.move_axis(self.CAROUSEL_Z, int(z_mm * (40000 / 100)), vel=vel, accel=accel)

    def spin_axis(self, axis: int, vel: int, accel: Optional[int] = None, wait: bool = True) -> CmdToken:
        """
        Rotate an axis indefinitely at the given velocity. Note this cannot be used on axes that are not infinitely
        rotating. Pass vel=0 to stop a spinning axis.

        Parameters
        ----------
        axis: int
            The axis to rotate [0, 7]
        vel: int
            The velocity at which to spin in units of cts/s [0, 100000]
        accel: int, optional
            The acceleration at which to reach the target velocity. If None, the default accel is used.
        wait: bool, optional
            If true, this command blocks until the target velocity is achieved.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the spin or wait for it
            to finish if wait=False.
        """
        self.v_print("Spinning axis", axis, "at", vel)
        _, accel = self._validate_vel_accel(0, accel)
        self.send_packet('SPAX', [axis, vel, accel], wait=wait)
        return self.new_cmd_token(self.get_axis_status, AxisState.VELOCITY_TARGET_REACHED, axis, wait)

    def axis_servo(self, axis: int, servo: bool):
        """
        Enable or disable the servo action of an axis. Disabled servo action allows some axes to be positioned by hand.
        Note: axis must be re-homed before moving after turning servo action off.

        Parameters
        ----------
        axis: int
            The axis for which the servo status should be changed [0,7]
        servo: bool
            Servo action is enable if True, disabled if False.
        """
        self.send_packet('SRVO', [axis, int(servo)])
        self.v_print("Axis", axis, "servo", servo)

    def amc_pwm(self, f, ms, amp, wait=True):
        self.send_packet('APWM', [f, ms, amp])
        return self.new_cmd_token(self.get_sequence_status, self.FREE, wait=wait)

    def get_axis_position(self, axis: int, print_result: bool = False) -> int:
        """
        Get the current position of the axis in units of counts.

        Parameters
        ----------
        axis: int
            The axis for which to get the current position [0, 7]
        print_result: bool
            Print the results to STDOUT, for example if used in the shell

        Returns
        -------
        int
            The current position of the axis in units of counts
        """
        args = self.send_packet('AXPS', [axis])
        msg = f'Axis {axis} at position {args[0]}'
        if print_result:
            print(msg)
        else:
            self.v_print(msg)
        return args[0]

    def get_axis_target(self, axis: int) -> int:
        """
        Get the target position of the axis in units of counts.

        Parameters
        ----------
        axis: int
            The axis for which to get the target position [0, 7]

        Returns
        -------
        int
            The current target of the axis in units of counts
        """
        args = self.send_packet('GTGT', [axis])
        self.v_print("Axis", axis, "has position target", args[0])
        return args[0]

    def robot_servo(self, servo: bool):
        """
        Enable or disable the servo action of each of the four robot axes. Disabled servo action allows the robot to be
        positioned by hand. Note: the robot must be re-homed before moving after turning servo action off.

        Parameters
        ----------
        servo: bool
            Turns all robot servos on if True, off if False.
        """
        for i in range(4):
            self.axis_servo(i, servo)

    def get_robot_positions(self) -> List[int]:
        """
        Get the current position of each of the N9 robot axes, in units of counts.
        Returns
        -------
        List[int]
            A list of length 4 representing the current position of the [Gripper, Elbow, Shoulder, Z-Axis] in units of
            counts
        """
        return [self.get_axis_position(i) for i in range(4)]

    ######################################
    ##                                  ##
    ##              IO                  ##
    ##                                  ##
    ######################################

    def set_output(self, output_num: int, val: bool):
        """
        Turn a digital output on or off

        Parameters
        ----------
        output_num: int
            The output channel to turn on or off
        val: bool
            True to turn on the digital output, False to turn it off
        """
        self.send_packet('SETO', [output_num, int(val)])
        self.v_print("Set", output_num, "to state", val)

    def get_input(self, input_num: int) -> bool:
        """
        Query the state of a digital input

        Parameters
        ----------
        input_num: int
            The input channel to get the value of

        Returns
        -------
        bool
            The value of the input channel
        """
        args = self.send_packet('GETI', [input_num])
        self.v_print("Input", input_num, "is in state", args[0])
        return args[0]

    def get_analog(self, analog_num):
        args = self.send_packet('GETA', [analog_num])
        self.v_print("Analog", analog_num, "has value:", args[0])
        return args[0]

    def config_analog(self,
                      analog_num,
                      start=ADS1115.START_READ,
                      pins=ADS1115.AIN0_GND,
                      v_range=ADS1115.V4_096,
                      mode=ADS1115.CONTINUOUS,
                      rate=ADS1115.SPS64):
        self.send_packet('CFGA', [analog_num, start, pins, v_range, mode, rate])
        self.v_print("Configured analog", analog_num)

    ######################################
    ##                                  ##
    ##           PNEUMATICS             ##
    ##                                  ##
    ######################################

    def open_gripper(self):
        """
        Opens the N9 gripper teeth. Note: actually turns on digital output 0, regardless of what is connected, typically
        the N9 gripper.
        """
        self.send_packet('GRPR', [0])
        self.delay(self.GRIPPER_DELAY)
        self.v_print("Grippers open")

    def close_gripper(self):
        """
        Closes the N9 gripper teeth. Note: actually turns off digital output 0, regardless of what is connected,
        typically the N9 gripper.
        """
        self.send_packet("GRPR", [1])
        self.delay(self.GRIPPER_DELAY)
        self.v_print("Grippers closed")

    def open_clamp(self, clamp_num: int = 0):
        """
        Opens the vial clamp. Note: actually turns on clamp_num +1, regardless of what is connected, though this is
        typically a clamp.

        Parameters
        ----------
        clamp_num: int
            The number of the vial clamp to open
        """
        # if self.sim:
        #     self.send_packet('CLMP', [clamp_num, 0])
        # else:
        #     self.send_packet('CLMP', [0])
        self.set_output(clamp_num+1, 0)
        self.delay(self.CLAMP_DELAY)
        self.v_print("Clamp open")

    def close_clamp(self, clamp_num: int = 0):
        """
        Closes the vial clamp. Note: actually turns off clamp_num +1, regardless of what is connected, though this is
        typically a clamp.

        Parameters
        ----------
        clamp_num: int
            The number of the vial clamp to closed
        """
        # if self.sim:
        #     self.send_packet('CLMP', [clamp_num, 1])
        # else:
        #     self.send_packet('CLMP', [1])
        self.set_output(clamp_num+1, 1)
        self.delay(self.CLAMP_DELAY)
        self.v_print("Clamp closed")

    def bernoulli_on(self):
        """
        Enables the tool air. Note: actually turns on digital output 2, regardless of what is connected, typically
        the tool air.
        """
        self.send_packet('BRNL', [1])
        self.v_print("Bernoulli gripper on")

    def bernoulli_off(self):
        """
        Disables the tool air. Note: actually turns off digital output 2, regardless of what is connected, typically
        the tool air.
        """
        self.send_packet('BRNL', [0])
        self.v_print("Bernoulli gripper off")

    def vac_gripper_on(self):
        """
        Enables the tool air. Note: actually turns on digital output 2, regardless of what is connected, typically
        the tool air.
        """
        if self.sim:
            self.send_packet('VACU', [1])
        else:
            self.send_packet('BRNL', [1])
        self.v_print("Vacuum gripper on")

    def vac_gripper_off(self):
        """
        Enables the tool air. Note: actually turns on digital output 2, regardless of what is connected, typically
        the tool air.
        """
        if self.sim:
            self.send_packet('VACU', [0])
        else:
            self.send_packet('BRNL', [0])
        self.v_print("Vacuum gripper off")

    ######################################
    ##                                  ##
    ##       UNITS AND KINEMATICS       ##
    ##                                  ##
    ######################################

    @staticmethod
    def counts_to_rad(axis: int, counts: int) -> float:
        """
        Return the axis position in radians given the axis position in counts. Only valid for rotational axes.

        Parameters
        ----------
        axis: int
            The axis for which to convert units [0, 7]
        counts: int
            The value of counts to convert to radians

        Returns
        -------
        float:
            The value in radians
        """
        return n9.counts_to_rad(axis, counts)

    @staticmethod
    def rad_to_counts(axis: int, rad: float) -> int:
        """
        Return the axis position in counts given the axis position in radians. Only valid for rotational axes.

        Parameters
        ----------
        axis: int
            The axis for which to convert units [0, 7]
        rad: float
            The value of radians to convert to counts

        Returns
        -------
        int:
            The value in counts
        """
        return n9.rad_to_counts(axis, rad)

    @staticmethod
    def counts_to_mm(axis: int, counts: int) -> float:
        """
        Return the axis position in mm given the axis position in counts. Only valid for translational axes.

        Parameters
        ----------
        axis: int
            The axis for which to convert units [0, 7]
        counts: int
            The value of counts to convert to mm

        Returns
        -------
        float:
            The value in mm
        """
        return n9.counts_to_mm(axis, counts)

    @staticmethod
    def mm_to_counts(axis: int, mm: float) -> int:
        """
        Return the axis position in counts given the axis position in mm. Only valid for translational axes.

        Parameters
        ----------
        axis: int
            The axis for which to convert units [0, 7]
        mm: int
            The value of mm to convert to counts

        Returns
        -------
        int:
            The value in counts
        """
        return n9.mm_to_counts(axis, mm)

    # TODO, include gripper, z-axis tool, etc
    @staticmethod
    def n9_fk(gripper_cts: int, elbow_cts: int, shoulder_cts: int, tool_length: float = 0,
              pipette_tip_offset: bool = False) -> Tuple[float]:
        """
        Forward kinematics: gives the end-effector (EE) position in mm given a joint-space pose in units of counts.

        Parameters
        ----------
        gripper_cts: int
            Gripper position in units of counts
        elbow_cts: int
            Elbow position in units of counts
        shoulder_cts: int
            Shoulder position in units of counts
        tool_length: float, optional
            The length of the tool in the gripper, in units of mm.
        pipette_tip_offset: bool
            If True, the EE is considered to be the pipette tip probe, otherwise it is the center of the N9 gripper.
        Returns
        -------
        float
            A 3-tuple (x, y, theta) in units of mm of the EE position given the joint position inputs
        """
        return n9.fk(gripper_cts, elbow_cts, shoulder_cts, tool_length, pipette_tip_offset)

    @staticmethod
    def n9_ik(x: float, y: float, tool_length: float = 0, tool_orientation: float = None,
              pipette_tip_offset: bool = False, shoulder_preference: int = None) -> Tuple[int]:
        """
        Inverse kinematics: gives a joint-space pose in units of counts given a task-space target position of the end-
        effector (EE) in units of mm.

        Parameters
        ----------
        x: float
            The target x position of the EE, units of mm.
        y: float
            The target y position of the EE, units of mm.
        tool_length: float, optional
            The length of the tool in the robot gripper in units of mm.
        tool_orientation: float, optional
            The desired angle of the tool or gripper joint with relation to the global cartesian x-axis in degrees.
        pipette_tip_offset: bool
            If True, the EE is considered to be the pipette tip probe, otherwise it is the center of the N9 gripper.
        shoulder_preference: {NorthC9.SHOULDER_CENTER, NorthC9.SHOULDER_OUT}
            Determines the kinematic solution to achieve the target position. If SHOULDER_CENTER, the N9 will achieve
            the target position such that the shoulder joint is closer to the cartesian Y axis. If SHOULDER_OUT, the
            target position will be achieved with the opposite pose.

        Returns
        -------
        int
            A 3-tuple (gripper, elbow, shoulder) in units of counts of the joint positions to achieve the desired EE
            position.
        """
        return n9.ik(x, y, tool_length, tool_orientation, pipette_tip_offset, shoulder_preference)

    ######################################
    ##                                  ##
    ##           CMD_TOKENS             ##
    ##                                  ##
    ######################################

    # This architecture is in place to allow the class to store the previous cmd token, so c9.wait_for() would
    # obviate the need to manually store the previous cmd

    def new_cmd_token(self, func, value, axis=None, wait=True, delay=0):
        tkn = CmdToken(func, value, axis, delay, self.sim)
        self.prev_cmd_token = tkn
        if wait:
            tkn.wait()
        return tkn

    def wait_for(self, tkn: CmdToken = None):
        if tkn is None:
            tkn = self.prev_cmd_token
        tkn.wait()

    def cmd_done(self, token: CmdToken = None):
        if token is None:
            token = self.prev_cmd_token
        return token.is_done()

    ######################################
    ##                                  ##
    ##              PUMPS               ##
    ##                                  ##
    ######################################
    def _check_pump_num(self, pump_num: int):
        """
        Adds the requested pump to the pump dict if not included in the project. Assumes a syringe volume of 1.

        Parameters
        ----------
        pump_num: The address to check for in the pump dict

        """
        if pump_num not in self.pumps:
            self.pumps[pump_num] = {'pos': 0, 'volume': 1}

    def _get_pump_delay(self):
        """
        :return: Delay in seconds for pump command tokens.
        """
        # enforces that 0.0 won't be sent to a *SerialControllerNetwork
        assert (self.sim and isinstance(self.network, VirtualControllerNetwork)) \
               or (not self.sim and not isinstance(self.network, VirtualControllerNetwork))
        return 0.0 if self.sim else self.SERIAL_PUMP_DELAY

    def is_pump_free(self, pump_num: int) -> bool:
        """
        Check if a pump has finished its previous command

        Parameters
        ----------
        pump_num: int
            The pump address to check [0, 14]

        Returns
        -------
        bool
            True if the pump has finished its previous command and is free, False otherwise
        """

        args = self.send_packet('PMST', [pump_num], retries=self.N_PUMP_RETRIES)
        return args[0] == self.FREE

    def home_pump(self, pump_num: int, wait: bool = True) -> CmdToken:
        """
        Start the homing procedure for a pump. Pumps must be homed after power on before actuating.

        Parameters
        ----------
        pump_num: int
            The pump address to home [0, 14]
        wait: bool, optional
            If true, this command blocks until the home is complete.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the home or wait for it
            to finish if wait=False.
        """
        self._check_pump_num(pump_num)
        self.pumps[pump_num]['pos'] = 0
        self.send_packet('HOPM', [pump_num], wait=wait, retries=self.N_PUMP_RETRIES)
        self.log("Homing pump", pump_num)
        return self.new_cmd_token(self.is_pump_free, True, pump_num, wait, delay=self._get_pump_delay())

    def move_pump(self, pump_num: int, pos: int, wait: bool = True) -> CmdToken:
        """
        Move the pump's plunger up or down

        Parameters
        ----------
        pump_num: int
            The address of the pump to move [0, 14]
        pos: int
            The plunger position to which to move [0, 3000]
        wait: bool, optional
            If true, this command blocks until the move is complete.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the move or wait for it
            to finish if wait=False.
        """
        self._check_pump_num(pump_num)
        self.pumps[pump_num]['pos'] = pos
        self.send_packet('MOPM', [pump_num, pos], wait=wait, retries=self.N_PUMP_RETRIES)
        self.log("Moving pump", pump_num, "to position", pos)
        return self.new_cmd_token(self.is_pump_free, True, pump_num, wait, delay=self._get_pump_delay())

    def aspirate_ml(self, pump_num: int, ml: float, wait: bool = True) -> CmdToken:
        """
        Aspirate a given volume into the syringe. This method requires the volume of the syringe installed in the pump
        to be set correctly in the project file, which is generally done through the NorthIDE. Does not do any valve
        movement, only calculates and effects the required plunger motion to achieve the target aspiration volume.

        Parameters
        ----------
        pump_num: int
            The address of the aspirating pump [0, 14]
        ml: float
            The volume to aspirate, units of mL
        wait: bool, optional
            If true, this command blocks until the move is complete.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the aspiration or wait for it to finish if
            wait=False.
        RuntimeError
            If the requested volume exceeds the available volume of the syringe
        """
        self._check_pump_num(pump_num)
        new_pos = int(self.pumps[pump_num]['pos'] + ml * (n9.PUMP_MAX_COUNTS / self.pumps[pump_num]['volume']))
        if new_pos > n9.PUMP_MAX_COUNTS:
            raise RuntimeError(f'Pump volume too full to aspirate {ml}ml')
        return self.move_pump(pump_num, new_pos, wait)

    def dispense_ml(self, pump_num: int, ml: float, wait: bool = True) -> CmdToken:
        """
        Dispense a given volume into the syringe. This method requires the volume of the syringe installed in the pump
        to be set correctly in the project file, which is generally done through the NorthIDE. Does not do any valve
        movement, only calculates and effects the required plunger motion to achieve the target dispense volume.

        Parameters
        ----------
        pump_num: int
            The address of the dispensing pump [0, 14]
        ml: float
            The volume to dispense, in mL
        wait: bool, optional
            If true, this command blocks until the move is complete.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the dispense or wait for it to finish if
            wait=False.
        RuntimeError
            If the requested dispense volume exceeds the available dispense volume of the syringe
        """
        self._check_pump_num(pump_num)
        new_pos = int(self.pumps[pump_num]['pos'] - ml * (n9.PUMP_MAX_COUNTS / self.pumps[pump_num]['volume']))
        if new_pos < 0:
            raise RuntimeError(f'Cannot move pump to {new_pos}, pump too empty to dispense {ml} mL')
        return self.move_pump(pump_num, new_pos, wait)

    # Todo: sanitize pump inputs (e.g. valve_pos)
    def set_pump_valve(self, pump_num: int, valve_pos: int, wait: bool = True) -> CmdToken:
        """
        Change the valve setting of a pump

        Parameters
        ----------
        pump_num: int
            The address of the pump on which to change valve settings [0, 14]
        valve_pos: {NorthC9.PUMP_VALVE_LEFT, NorthC9.PUMP_VALVE_CENTER, NorthC9.PUMP_VALVE_RIGHT}
            The position to which to move the valve. Some pumps may not support PUMP_VALVE_CENTER.
        wait: bool, optional
            If true, this command blocks until the valve move is complete.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the valve move or wait for it to finish if
            wait=False.
        """
        self._check_pump_num(pump_num)
        self.send_packet('SPMV', [pump_num, valve_pos], wait=wait, retries=self.N_PUMP_RETRIES)
        self.log("Setting pump valve", pump_num, "to position", valve_pos)
        return self.new_cmd_token(self.is_pump_free, True, pump_num, wait, delay=self._get_pump_delay())

    def set_pump_speed(self, pump_num: int, speed: int):
        """
        Change the plunger speed setting of a pump. Plunger speeds are set using "speed codes" where 0 is the fastest
        and 40 is the slowest. The power up default speed code is 11. See page pg67 of the TriContinent C-3000 manual
        for more details and a complete table of speed code values.

        Parameters
        ----------
        pump_num: int
            The address of the pump on which to set the speed [0, 14]
        speed: int
            The speed code to set [0, 40]
        """
        self._check_pump_num(pump_num)
        if not self.sim:
            self.delay(self._get_pump_delay())
        self.send_packet('SPMS', [pump_num, speed], retries=self.N_PUMP_RETRIES)
        self.log("Setting speed of pump", pump_num, "to ", speed)

        if not self.sim:
            self.delay(self._get_pump_delay())

    ######################################
    ##                                  ##
    ##        PERISTALTIC PUMPS         ##
    ##                                  ##
    ######################################
    def _check_peri_name(self, name: str):
        """
        Validate that the peristaltic pump has been initialized

        Parameters
        ----------
        name: str
            The name to check

        Returns
        -------
        KeyError
            Raised if the name has not been initialized
        """
        if name not in self.peri_pumps:
            raise KeyError(f'{name} has not been initialized; make sure to call c9.initialize_peri_pump( ... ) first')

    def initialize_peristaltic(self, name: str, ml_per_cnt: float, axis: int, vel: int = 500, accel: int = 10000):
        """
        Register a peristaltic pump and its physical properties. Must be done before sending any commands to the pump.

        Parameters
        ----------
        name: str
            Set the name used to identify the pump for future commands
        ml_per_cnt: float
            The relationship between the pump's rotation, in units of counts, and the volume it dispenses, in units of
            mL. This quantity is speed dependant and should be determined empirically for each pump by testing at a
            representative speed. Faster speeds result in fewer mL/count being dispensed.
        axis: int
            The axis the pump is connected to [0, 7]
        vel: int, optional
            The default velocity of the pump in units of counts/sec. Can be configured for individual dispenses.
        accel: int, optional
            The default acceleration of the pump in units of counts/sec^2. Can be configured for individual dispenses.
        """
        self.peri_pumps[name] = {'pos': 0, 'ml_per_cnt': ml_per_cnt, 'axis': axis, 'vel': vel, 'accel': accel}
        self.home_peristaltic(name)

    def set_peristaltic_speed(self, name: str, cts_per_sec: Optional[int] = None, ml_per_sec: Optional[float] = None,
                              accel: Optional[int] = None):
        """
        Configure the default speed of a peristaltic pump in units of counts/s or its estimated flow rate in ml/sec.

        Parameters
        ----------
        name: str
            The name of the peristaltic pump to configure
        cts_per_sec: int, optional
            If provided, the value of the speed that will be set. Units of counts/sec.
        ml_per_sec: float, optional
            If provided and cts_per_sec is not given, this is the value of the estimated flow rate that will be set.
            Units of mL/sec. Calculated based on the mL/count value provided during pump initialization.
        accel: int, optional
            A new value for default acceleration. If not provided, the old value will persist.
        """
        self._check_peri_name(name)
        if ml_per_sec is not None:
            self.peri_pumps[name]['vel'] = int(ml_per_sec/self.peri_pumps[name]['ml_per_cnt'])
        elif cts_per_sec is not None:
            self.peri_pumps[name]['vel'] = int(cts_per_sec)

        if accel is not None:
            self.peri_pumps[name]['accel'] = accel

    def home_peristaltic(self, name: str):
        """
        Homes a peristaltic pump. Should be homed before moving after power on.

        Parameters
        ----------
        name: str
            The name of the peristaltic pump to home.
        """
        self._check_peri_name(name)
        self.home_axis(self.peri_pumps[name]['axis'])
        self.move_axis(self.peri_pumps[name]['axis'], 0)  # workaround for NORTHIDE-265

    def peristaltic_dispense(self, name: str, ml: float, reverse: bool = False, vel: Optional[int] = None,
                             accel: Optional[int] = None, wait: bool = True) -> CmdToken:
        """
        Dispense the given volume with a peristaltic pump.

        Parameters
        ----------
        name: str
            The name of the pump from which to dispense
        ml: float
            The volume to dispense in units of mL
        reverse: bool
            Run the pump in the opposite direction
        vel: int, optional
            The velocity of the pump during the dispense, in units of cts/sec. If not given, the velocity will be the
            pump's default velocity set during initialization (or explicitly afterwards with
            NorthC9.set_peristaltic_speed).
        accel: int, optional
            The acceleration of the pump during the dispense, in units of cts/sec^2. If not given, the acceleration will
            be the pump's default acceleration set during initialization (or explicitly afterwards with
            NorthC9.set_peristaltic_speed).
        wait: bool, optional
            If true, this command blocks until the dispense is complete.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the dispense or wait for it to finish if
            wait=False.
        """
        self._check_peri_name(name)
        vel = vel if vel is not None else self.peri_pumps[name]['vel']
        accel = accel if accel is not None else self.peri_pumps[name]['accel']
        reverse_factor = 1 if reverse else -1
        target = self.get_axis_position(self.peri_pumps[name]['axis']) + reverse_factor * int(ml/self.peri_pumps[name]['ml_per_cnt'])
        self.peri_pumps[name]['pos'] = target
        return self.move_axis(self.peri_pumps[name]['axis'], target, vel=vel, accel=accel, wait=wait)

    def backoff_peristaltic(self, name, cts: int=100,  vel=None, accel=None, wait=True):
        self._check_peri_name(name)
        vel = vel if vel is not None else self.peri_pumps[name]['vel']
        accel = accel if accel is not None else self.peri_pumps[name]['accel']
        target = self.get_axis_position(self.peri_pumps[name]['axis']) + int(cts)
        self.peri_pumps[name]['pos'] = target
        return self.move_axis(self.peri_pumps[name]['axis'], target, vel=vel, accel=accel, wait=wait)

    ######################################
    ##                                  ##
    ##              SCALE               ##
    ##                                  ##
    ######################################

    def get_scale_property(self, prop_num: int):
        """
        Return a balance property

        Parameters
        ----------
        prop_num: int
            The property number to print [0, 3]
        """
        args = self.send_packet('SCDP', [int(prop_num)])
        return int(args[0])
    
    def set_scale_property(self, prop_num: int, value: int):
        """
        Configure a balance property.

        Parameters
        ----------
        prop_num: int
            The property number to configure [0, 3]
        value:
            The value to set for that property.
        """
        self.send_packet('SCSP', [int(prop_num), int(value)])

    def clear_scale(self):
        """
        Exit any special weighing mode immediately, clears statistics. Does not tare balance.
        """
        self.send_packet('CLSC')
        self.v_print("Scale cleared")

    def read_scale(self) -> Tuple[bool, float]:
        """
        Get the value from the balance, along with its steady status

        Returns
        -------
        Tuple[bool, float]
            A tuple of length 2: first parameter a bool corresponding to the steady status (True is steady); second
            parameter is the weight measured by the balance. Units determined by balance display.
        """
        args = self.send_packet('RDSC')
        steady = bool(args[0])
        weight = self._weight_from_args(args[1:5])
        try:
            units = args[5]
        except IndexError:
            units = 0

        self.v_print("Scale read:", weight, self._scale_unit_str(units), ", steady:", steady)
        return steady, weight

    def read_steady_scale(self, wait: bool = True) -> Union[float, CmdToken]:
        """
        Wait for the scale to settle then return the steady value

        Parameters
        ----------
        wait: bool, optional
            If true, this command blocks until measurement is complete.

        Returns
        -------
        float:
            If wait=True, this command returns the weight value from the balance's front panel display.
        CmdToken
            A CmdToken object which can be used to follow up on the status of the measurement or wait for it to finish
            if wait=False. Use tkn.return_value[0] to recover the measurement value after the scale has settled (i.e.
            tkn.is_done() == True).
        """

        # Behaviour of steady scale reading is slightly different in current iteration of sim:
        # Since steady scale  reading relies on a cmd token calling its wait fcn (read_scale) to get the
        # actual update and the simulator ignores all cmd tokens (to be imporved with the "line-by-line" sim in the
        # future) the read_steady_scale() cmd simply calls read_scale() itself, outside the cmd_tkn framework.
        if self.sim:
            return self.read_scale()[1]  # return the second element of tuple

        tkn = self.new_cmd_token(self.read_scale, True, wait=wait)
        if wait:
            return tkn.return_value[0]
        return tkn

    def zero_scale(self):
        """
        Tare the balance. Might require some delay after calling to ensure the balance has reached a steady 0.
        """
        self.send_packet('ZRSC')
        self.v_print("Scale zeroed")

    def _weight_from_args(self, args):
        # read_scale returns 6 args from FW:
        # args[0]: steady flag
        # args[1]: negative flag
        # args[2]: pre-dec integer
        # args[3]: post-dec integer
        # args[4]: number of digits post-dec
        # args[5]: units code
        # given args 1:5 or 1:, this function returns the weight as a float]

        neg = bool(args[0])
        pre_dec = int(args[1])
        post_dec = float(args[2])
        post_dec_len = int(args[3])

        for i in range(post_dec_len):
            post_dec /= 10

        weight = pre_dec + post_dec
        if neg:
            weight *= -1
        return weight

    def _scale_unit_str(self, unit_num):
        if unit_num == 1:
            return "g"
        elif unit_num == 2:
            return 'kg'
        elif unit_num == 3:
            return 'mg'
        elif unit_num == 4:
            return 'ct'
        elif unit_num == 5:
            return 'dwt'
        elif unit_num == 6:
            return 'ozt'
        elif unit_num == 7:
            return 'oz'
        elif unit_num == 8:
            return 'lb'
        else:
            return "UNKNOWN"

    # ######################################
    # ##                                  ##
    # ##              BARCODE             ##
    # ##                                  ##
    # ######################################

    # TODO: HANDLE BARCODE FAILURES/TIMEOUTS

    def barcode_status(self) -> Union[bool, Tuple[bool, str]]:
        """
        Check if the barcode reader has read a barcode
        Returns
        -------
        bool
            False if no code read
        Tuple[bool, str]
            Returns (True, barcode_str) if a barcode was successfully measured
        """
        args = self.send_packet('GTBC')
        if len(args) == 0:
            return False
        else:
            return True, args[0]

    def cancel_barcode(self):
        """
        Stops the controller polling for barcodes
        """
        self.send_packet('NOBC')
        self.v_print("Barcode read cancelled")

    # Methods that wait to get a specific value from the controller return a value when wait is True
    # and return a CmdToken object when wait is False.
    def get_barcode(self, wait: bool = True) -> Union[str, CmdToken]:
        """
        Read a barcode, runs as a sequence on the controller until a BC is found or it is cancelled.

        Parameters
        ----------
        wait: bool, optional
            If true, this command blocks until measurement is complete.

        Returns
        -------
        float:
            If wait=True, this command returns the barcode value once one has been successfully read.
        CmdToken
            A CmdToken object which can be used to follow up on the status of the measurement or wait for it to finish
            if wait=False. Use tkn.return_value[0] to recover the measurement value after the barcode has been read
            (i.e. tkn.is_done() == True).
        """
        # Behaviour of barcode reading is slightly different in current iteration of sim:
        # Since barcode reading relies on a cmd token calling its wait fcn (barcode_status) to get the actual
        # update and the simulator ignores all cmd tokens (to be imporved with the "line-by-line" sim in the future)
        # the get_barcode() cmd simply calls barcode_status() itself, outside the cmd_tkn framework.
        if self.sim:
            return self.barcode_status()[1]  # return the second element of tuple

        tkn = self.new_cmd_token(self.barcode_status, True, wait=wait)
        if wait:
            return tkn.return_value[0]
        return tkn

    ######################################
    ##                                  ##
    ##              TEMP                ##
    ##                                  ##
    ######################################

    def get_temp(self, channel: int) -> float:
        """
        Read the process value from a temperature channel

        Parameters
        ----------
        channel: int
            The temperature channel from which to read the value [0, 7]

        Returns
        -------
        float
            The process value as displayed on the front panel (*C or *F)
        """
        args = self.send_packet('GTPV', [int(channel)])
        self.v_print("Channel", channel, "temp is", args[0])
        return args[0] / 10.0

    def set_temp(self, channel: int, temp: float):
        """
        Configure the set point on a temperature channel

        Parameters
        ----------
        channel: int
            The channel on which to configure the set point [0, 7]
        temp: float
            The set point to configure, units as per front panel setting (*C or *F)
        """
        value = int(temp * 10)
        self.send_packet('STSV', [int(channel), value])
        self.v_print("Channel", channel, "temp set to", temp)

    def temp_autotune(self, channel: int, enable: bool):
        """
        Enable/disable temperature autotune. This is used to calibrate the temperature channel once connected to the
        plant it is to heat. Channel must be enabled. The autotune process will heat the plant above the set point, let
        it cool below the set point, then heat it again above the set point before automatically disabling autotune and
        regulating the PV to the SV. The channel automatically saves the autotune configuration after it completes

        Parameters
        ----------
        channel: int
            The channel on which to configure autotune
        enable: bool
            True - enable; False - disable
        """
        self.send_packet('STAT', [int(channel), int(enable)])
        self.v_print("Autotune on channel", channel, "set to", str(enable))

    def temp_heatcool(self, channel: int, val: int):
        """
        Configure the heat/cool parameter.

        Parameters
        ----------
        channel: int
            The channel on which to configure the heat/cool param [0, 7]
        val: int
            The value to set
        """
        self.send_packet('STHC', [int(channel), int(val)])
        self.v_print("Heal/cool IO on channel", channel, "set to", val)

    def temp_offset(self, channel: int, offset: float):
        """
        Set the temp offset parameter for a channel.

        Parameters
        ----------
        channel: int
            The channel on which to configure the temp offset [0, 7]
        offset: float
            The value to set
        """
        value = int(offset * 10)
        self.send_packet('STTR', [int(channel), value])
        self.v_print("Temp offset on channel", channel, "set to", offset)

    def enable_channel(self, channel: int):
        """
        Enable output on a temperature channel

        Parameters
        ----------
        channel: int
            The channel on which to enable output [0, 7]
        """
        self.send_packet('STRS', [int(channel), int(True)])
        self.v_print(f'Temp channel {channel} enabled')

    def disable_channel(self, channel):
        """
        Disable output on a temperature channel

        Parameters
        ----------
        channel: int
            The channel on which to disable output [0, 7]
        """
        self.send_packet('STRS', [int(channel), int(False)])
        self.v_print(f'Temp channel {channel} disabled')

    ######################################
    ##                                  ##
    ##             CONFIG               ##
    ##                                  ##
    ######################################

    # todo: broadcast version to query address for single controller network
    def get_c9_addr(self) -> int:
        """
        Read the C9 address (e.g. ord('A')) from the controller. Note that this method is primarily a test of EEPROM
        - you must know the address to send the packet in the first place.

        Returns
        -------
        int
            The integer value of the controller ASCII address (e.g. 'A' = 65)
        """
        # this method is primarily a test of EEPROM - you must know the addr to send the packet
        args = self.send_packet('GADR')
        self.v_print("Controller's address is", args[0])
        return args[0]

    def set_c9_addr(self, new_addr: Union[int, str], broadcast: bool = False):
        """
        Set the controller network address of the controller

        Parameters
        ----------
        new_addr: Union[int, str]
            The controller's new address. If an int [1, 255] is passed, that is used as the address. If a single ASCII
            character is passed in a str of length 1 (e.g. 'B'), that is converted to an integer and set as the address.
        broadcast: bool, optional
            If true, this command will not be addressed to the address of the controller, but instead broadcast to any
            controller on the network. This is useful to set the address of a controller when its current address is
            unknown. In this case, it should be the only controller physically on the network to avoid assigning the
            same address to multiple controllers.
        """
        try:
            new_addr = int(new_addr)
        except ValueError:
            new_addr = ord(new_addr)
        if new_addr > 255 or new_addr < 1:
            raise ValueError("New address must be in the range [1, 255]")

        self.send_packet('SADR', [new_addr], broadcast=broadcast)
        self.v_print("Controller's address set to", new_addr)
        if not self.verbose:
            print("Controller's address set to", new_addr)
            print("The controller must be restarted for this to take effect")

    # ######################################
    # ##                                  ##
    # ##             CAPPING              ##
    # ##                                  ##
    # ######################################

    def reduce_axis_position(self, axis: int, cts_per_rev: int = 4000):
        """
        For infinitely rotating axes, such as the N9 gripper, this command reduces their current position to within the
        range of 1 revolution. For example, the gripper has 4000cts/rev. If its current position is 15000 (3.75
        complete revolutions away from its home position), calling reduce_axis_position on this axis would change set
        its current position to 3000, 0.75 turns from the home position.

        Parameters
        ----------
        axis: int
            The axis of which to reduce the position.
        cts_per_rev: int
            Number of counts per revolution of the target axis. The divisor in the calculation:
             reduced_pos = current_pos % cts_per_rev
        """
        self.send_packet('RDCA', [axis, cts_per_rev])
        self.log(f"Reduced axis {axis} position")

    # TODO: change default vial properties?
    def uncap(self, pitch: float = 2, revs: float = 2.5, vel: int = 5000, accel: int = 40000,
              wait: bool = True) -> CmdToken:
        """
        Uncap a vial. Assumes that the gripper joint is already closed on the capped vial and the vial is secured in a
        clamping module.

        Parameters
        ----------
        pitch: float
            The distance in mm that the cap travels vertically when unscrewed one revolution.
        revs: float
            The number of revolutions required to completely remove the cap. A safety factor of at least 0.5rev should
            be added by the user.
        vel: int, optional
            The velocity, in counts/second, of the gripper during the uncapping
        accel
            The acceleration, in counts/second^2, of the gripper during the uncapping
        wait: bool, optional
            If true, this command blocks until the uncapping is complete.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the uncapping or wait for it to finish if
            wait=False.
        """
        gripper_counts = int(-revs * self.GRIPPER_COUNTS_PER_REV)
        pitch_cts = int(self.GRIPPER_COUNTS_PER_REV / (pitch * self.Z_AXIS_COUNTS_PER_MM))
        vel, accel = self._validate_vel_accel(vel, accel)
        # z_axis_counts = int(-revs*pitch*self.Z_AXIS_COUNTS_PER_MM)
        self.send_packet('UCAP', [gripper_counts, pitch_cts, vel, accel], wait=wait)
        self.v_print("Uncapping")
        return self.new_cmd_token(self.get_sequence_status, self.FREE, wait=wait)

    # TODO: change default vial properties?
    def cap(self, pitch: float = 2, revs: float = 2.5, torque_thresh: int = 1500, vel: int = 5000, accel: int = 40000,
            wait: bool = True) -> CmdToken:
        """
        Cap a vial. Assumes that the gripper joint is already closed on the vial cap, at the correct position above the
        vial, and the vial is secured in a clamping module. The capping process has two phases - pre-twisting the cap
        for 'revs' number of revolutions; then torque checking, wherein the cap tightness is checked against the
        torque_thresh parameter and tightens 1/8th of a revolution at a time until the threshold is exceed.

        Parameters
        ----------
        pitch: float
            The distance in mm that the cap travels vertically when unscrewed one revolution.
        revs: float
            The number of revolutions completed before starting the torque-checking phase. Often matches the revs value
            from the corresponding NorthC9.uncap(...) call.
        torque_thresh: int
            The torque threshold that must be exceeded before the cap is sufficiently tight. Units of mA.
        vel: int, optional
            The velocity, in counts/second, of the gripper during the capping
        accel
            The acceleration, in counts/second^2, of the gripper during the capping
        wait: bool, optional
            If true, this command blocks until the capping is complete.

        Returns
        -------
        CmdToken
            A CmdToken object which can be used to follow up on the status of the capping or wait for it to finish if
            wait=False.
        """
        gripper_counts = int(revs * self.GRIPPER_COUNTS_PER_REV)
        pitch_cts = int(self.GRIPPER_COUNTS_PER_REV / (pitch * self.Z_AXIS_COUNTS_PER_MM))
        vel, accel = self._validate_vel_accel(vel, accel)
        # z_axis_counts = int(revs*pitch*self.Z_AXIS_COUNTS_PER_MM)
        self.send_packet('CAPV', [gripper_counts, pitch_cts, torque_thresh, vel, accel], wait=wait)
        self.v_print("Capping")
        return self.new_cmd_token(self.get_sequence_status, self.FREE, wait=wait)

    # ######################################
    # ##                                  ##
    # ##            JOYSTICK              ##
    # ##                                  ##
    # ######################################

    def start_joystick(self):
        self.send_packet('JSBG')
        self.v_print("Starting joystick")

    def update_joystick(self, vel):
        vel = [int(v) for v in vel]
        self.send_packet('JSUP', vel)
        # self.v_print("Update joystick to new velocity:", vel)

    def stop_joystick(self):
        self.send_packet('JSSP')
        self.v_print("Stopping joystick")

    def joystick_mode(self):
        self.start_joystick()
        js_thread = threading.Thread(target=self._joystick_reader)
        js_thread.start()

        while js_thread.is_alive():
            self.update_joystick(self.js_vel)

        self.stop_joystick()

    def _joystick_reader(self):
        gamepad = True
        while (1):
            if gamepad:
                try:
                    events = get_gamepad()
                except UnpluggedError:
                    gamepad = False
                    print('No gamepad connected... using keyboard inputs')
                    continue

                for event in events:
                    if event.code == 'BTN_SOUTH':
                        if event.state:
                            return
                    elif event.code == 'ABS_RX':
                        self.js_vel[n9.SHOULDER] = self._joy_analog2speed(event.state)
                    elif event.code == 'ABS_RY':
                        self.js_vel[n9.Z_AXIS] = self._joy_analog2speed(-event.state)
                    elif event.code == 'ABS_X':
                        self.js_vel[n9.ELBOW] = self._joy_analog2speed(-event.state)
                    elif event.code == 'ABS_Y':
                        self.js_vel[n9.GRIPPER] = self._joy_analog2speed(event.state)
            else:
                while (1):
                    if keyboard.is_pressed('left'):
                        self.js_vel[n9.SHOULDER] = -self.key_speed
                    elif keyboard.is_pressed('right'):
                        self.js_vel[n9.SHOULDER] = self.key_speed
                    else:
                        self.js_vel[n9.SHOULDER] = 0

                    if keyboard.is_pressed('up'):
                        self.js_vel[n9.Z_AXIS] = -self.key_speed
                    elif keyboard.is_pressed('down'):
                        self.js_vel[n9.Z_AXIS] = self.key_speed
                    else:
                        self.js_vel[n9.Z_AXIS] = 0

                    if keyboard.is_pressed('w'):
                        self.js_vel[n9.GRIPPER] = self.key_speed
                    elif keyboard.is_pressed('s'):
                        self.js_vel[n9.GRIPPER] = -self.key_speed
                    else:
                        self.js_vel[n9.GRIPPER] = 0

                    if keyboard.is_pressed('a'):
                        self.js_vel[n9.ELBOW] = self.key_speed
                    elif keyboard.is_pressed('d'):
                        self.js_vel[n9.ELBOW] = -self.key_speed
                    else:
                        self.js_vel[n9.ELBOW] = 0

                    sleep(0.01)  # have some poll time in there so its not hogging cpu

    @staticmethod
    def _joy_analog2speed(val):
        MAX_JOY_VAL = 32768
        MAX_JOINT_SPEED = 7500
        MIN_JOINT_SPEED = 100
        DEADZONE_PERCENT = 0.2
        # deadzone
        if abs(val) < MAX_JOY_VAL * DEADZONE_PERCENT:
            return 0

        return int(math.copysign((MAX_JOINT_SPEED - MIN_JOINT_SPEED) / (MAX_JOY_VAL * (1 - DEADZONE_PERCENT)) * \
                                 (abs(val) - MAX_JOY_VAL * DEADZONE_PERCENT) + MIN_JOINT_SPEED, val))


class BaseControllerNetwork(ABC): # interface for network classes

    TIMEOUT = 0.6 # pumps need ~500ms timeout in FW, so this should be larger

    @dataclass
    class BaseControllerPacket:
        req_data: bytes  # the request data to send
        event: threading.Event  # the event to signal when the response is in
        resp_data: bytes = field(default=None, init=False)  # the return data from the response in bytes
        excpt: Exception = field(default=None, init=False)  # a potential exception raised in the worker thread
        # todo: error field?

        def wait(self):
            self.event.wait()

    def __init__(self, exp_log_path: Optional[Path] = None):
        self.exp_logging = exp_log_path is not None
        self.exp_log_file = open(exp_log_path, 'w') if self.exp_logging else None

        self.send_queue = queue.SimpleQueue()

        self.serial_worker_thread = threading.Thread(target=self.serial_worker).start()

    @abstractmethod
    def disconnect(self):
        raise NotImplementedError()
    @abstractmethod
    def time(self): raise NotImplementedError()
    @abstractmethod
    def send(self, data, expect_response=True):
        """
        :param bytes data: Message to controller.
        :param bool expect_response: will listen for a response if true
        :return: Response from controller.
        """
        raise NotImplementedError()

    @abstractmethod
    def serial_worker(self):
        """
        Abstract method representing the code to be executed in a worker thread that pulls outgoing messages from a
        send queue and returns the results to the calling thread.
        """
        raise NotImplementedError()

    def _exp_log(self, msg: str, send: bool):
        if not self.exp_logging:
            return
        send_char = 'S' if send else 'R'
        self.exp_log_file.write(f'{send_char} {str(self.time)} {msg}\n')
        self.exp_log_file.flush()


class FTDISerialControllerNetwork(BaseControllerNetwork):

    @dataclass
    class FTDISerialControllerPacket(BaseControllerNetwork.BaseControllerPacket):
        expect_response: bool  # broadcast packet or not

    MAX_RESP_LEN = 1024

    def __init__(self, network=None, network_serial:str=None, exp_log_path: Optional[Path] = None):
        super().__init__(exp_log_path=exp_log_path)

        if network_serial == '':
            network_serial = None

        self.network = network
        if self.network is None:
            try:
                self.network = Serial(device_serial=network_serial, baudrate=115200)
                self.network.device.ftdi.setLatencyTimer(1)

            except NameError:
                logging.error('NorthC9: Tried to initialize network without FTDI support.')

    def disconnect(self):
        self.network.disconnect()

    @property
    def time(self):
        return time() # real time

    def send(self, data, expect_response=True) -> bytes:
        """
        :param bytes data:
        :param bool expect_response: will listen for a response if true
        :return: response
        """
        data += build_crc(data)
        packet = FTDISerialControllerNetwork.FTDISerialControllerPacket(req_data=data,
                                                                        event=threading.Event(),
                                                                        expect_response=expect_response)
        self.send_queue.put(packet)
        packet.wait()
        if packet.excpt is not None:
            raise packet.excpt
        if not expect_response:
            return b''
        
        response_bytes = packet.resp_data

        resp_crc = response_bytes[-2:]
        calc_crc = build_crc(response_bytes[:-2])  # CRC check excludes only CRC bytes

        if calc_crc != resp_crc:
            print("CRC Error...")
            print(response_bytes)
            raise IOError

        #print(response_bytes[1:-2])

        return response_bytes[1:-2] # response excludes leading packet len byte and trailing CRC

    def serial_worker(self):
        while True:
            packet: FTDISerialControllerNetwork.FTDISerialControllerPacket = self.send_queue.get()
            self.network.flush()
            self.network.write(packet.req_data)
            self._exp_log(packet.req_data[:-2].decode('charmap'), send=True)
            packet.resp_data = b'' # set response to empty bytestr in case it returns early

            if not packet.expect_response:
                packet.event.set()
                continue

            try:
                packet_len = self.network.read(1, self.TIMEOUT)
                response_bytes = packet_len + self.network.read(int.from_bytes(packet_len, 'big') - 1, 0.2)
            except (ftdi_serial.SerialTimeoutException, ftdi_serial.SerialReadTimeoutException) as e:
                packet.excpt = e
                packet.event.set()
                continue

            self._exp_log(response_bytes[:-2].decode('charmap'), send=False)
            packet.resp_data = response_bytes
            packet.event.set()


class GenericSerialControllerNetwork(BaseControllerNetwork):

    @dataclass
    class GenericSerialControllerPacket(BaseControllerNetwork.BaseControllerPacket):
        expect_response: bool  # broadcast packet or not

    MAX_RESP_LEN = 1024

    def __init__(self, network=None, network_serial: str = None, exp_log_path: Optional[Path] = None):
        super().__init__(exp_log_path=exp_log_path)

        if network_serial is None:
            raise RuntimeError ('Network serial parameter required for Generic Serial connections')

        self.network = network
        if self.network is None:
            self.network = serial.Serial(network_serial, 115200, timeout=self.TIMEOUT, parity=serial.PARITY_NONE)

    def disconnect(self):
        pass # TODO?

    @property
    def time(self):
        return time() # real time

    def send(self, data, expect_response=True) -> bytes:
        """
        :param bytes data:
        :return: response
        """
        data += build_crc(data)
        packet = GenericSerialControllerNetwork.GenericSerialControllerPacket(req_data=data,
                                                                              event=threading.Event(),
                                                                              expect_response=expect_response)
        self.send_queue.put(packet)
        packet.wait()
        if packet.excpt is not None:
            raise packet.excpt
        response_bytes = packet.resp_data

        resp_crc = response_bytes[-2:]
        calc_crc = build_crc(response_bytes[:-2])  # CRC check excludes only CRC bytes

        if calc_crc != resp_crc:
            print("CRC Error...")
            print(response_bytes)
            raise IOError

        return response_bytes[1:-2] # response excludes leading packet len byte and trailing CRC

    def serial_worker(self):
        while True:
            packet: GenericSerialControllerNetwork.GenericSerialControllerPacket = self.send_queue.get()
            self.network.reset_input_buffer()
            self.network.write(packet.req_data)
            self._exp_log(packet.req_data[:-2].decode('charmap'), send=True)
            packet.resp_data = b'' # set response to empty bytestr in case it returns early

            if not packet.expect_response:
                packet.event.set()
                continue

            try:
                packet_len = self.network.read(1)
                if packet_len == b'':
                    raise serial.SerialTimeoutException  # didn't get a response
                packet_len = int.from_bytes(packet_len, 'big')
                if packet_len < 2:
                    raise serial.SerialTimeoutException  # didn't get a meaningful packet len, likely x00
                response_bytes = packet_len + self.network.read(packet_len - 1)
            except serial.SerialTimeoutException as e:
                packet.excpt = e
                packet.event.set()
                continue

            self._exp_log(response_bytes[:-2].decode('charmap'), send=False)
            packet.resp_data = response_bytes
            packet.event.set()

class VirtualControllerNetwork(BaseControllerNetwork):

    HEARTBEAT_INTERVAL = 0.1  # seconds - the minimum c9.delay resolution, also affected by sim cmd_time
    @dataclass
    class VirtualControllerPacket(BaseControllerNetwork.BaseControllerPacket):
        line: int  # line number
        task: int  # task id number (-1 if no task)
        cmd_wait: bool  # is the current command blocking (bypasses some status signalling in the sim)
        kf_only: bool  # is the sim in kf only mode

    def __init__(self, c9, exp_log_path: Optional[Path] = None):
        """
        :param NorthC9 c9:
        """
        super().__init__(exp_log_path=exp_log_path)

        assert isinstance(c9, NorthC9)
        self.c9 = c9
        self._sim_time = 0.0
        self.heartbeat_event = threading.Event()  # set and cleared regularly, used by c9.delay in a threaded context
        self.file_lock = threading.Lock()  # protects exp_log file writes, sim_time writes
        from north import Simulator
        self.simulator = Simulator(0.01, sim_inputs=c9.sim_inputs, proj=c9.proj)  # TODO set this programmatically, not by constant (see simview.dt)

    def disconnect(self):
        pass # TODO?

    @property
    def time(self):
        return self._sim_time

    def send(self, data, expect_response=True) -> bytes:
        """
        Send command to virtual controller.

        :param bytes data:
        :return: Response from simulator (through VC).
        """
        assert isinstance(self.c9, NorthC9)

        # get 'wait' bool from data head then rebuild it without that
        decoded = data.decode("charmap")
        with self.file_lock:
            self._exp_log(decoded, send=True)
        wait = decoded[0] == '1'
        data = bytes(decoded[1:], "charmap")
        # get a line number to send sim
        cmd = data.split(b' ')[1].decode('ascii')
        line = 0
        if not self.c9.is_highlight_disabled() and not cmd.endswith('ST'):

            # get current line from frame
            for i in range(1,10):
                f = getframeinfo(sys._getframe(i))
                filename = f[0].split("\\")[-1]
                if filename != 'north_c9.py':
                    line = f[1]
                    break

        # send cmd line to simulator and get response and the time added by cmd

        # todo: consider timeout for event
        packet = self.VirtualControllerPacket(req_data=data,
                                              event=threading.Event(),
                                              line=line,
                                              task=Scheduler.get_task(),
                                              cmd_wait=False if self.c9.simulate_all_packets else wait,
                                              kf_only=self.c9.kf_only)
        self.send_queue.put(packet)
        packet.wait()
        if packet.excpt is not None:
            raise packet.excpt

        response, cmd_time = packet.resp_data
        with self.file_lock:
            self._sim_time += cmd_time
            self._exp_log(response.decode('charmap'), send=False)
        return response

    def serial_worker(self):
        """
        In a separate thread, checks the send_queue for new messages. Sends that message to the sim, returns the
        results to the thread that posted in the queue
        """
        last_heartbeat_t = 0
        while True:
            # Todo: might be uninterruptable (incl ctrl+C) - consider adding a timeout and looping
            packet: VirtualControllerNetwork.VirtualControllerPacket = self.send_queue.get()

            try:
                response, cmd_time = self.simulator.handle_cmd(packet.req_data,
                                                               line=packet.line,
                                                               task=packet.task,
                                                               wait=packet.cmd_wait,
                                                               kf_only=packet.kf_only)
            except Exception as e:
                packet.excpt = e
                packet.event.set()
                continue
                
            packet.resp_data = (response, cmd_time)
            packet.event.set()

            #emit heartbeat from centralized place
            if self._sim_time > last_heartbeat_t + self.HEARTBEAT_INTERVAL:
                last_heartbeat_t = self._sim_time
                self.heartbeat_event.set()
                self.heartbeat_event.clear()

def build_crc16_table():
    result = []
    for byte in range(256):
        crc = 0x0000
        for _ in range(8):
            if (byte ^ crc) & 0x0001:
                crc = (crc >> 1) ^ 0xa001
            else:
                crc >>= 1
            byte >>= 1
        result.append(crc)
    return result


crc16_table = build_crc16_table()


def build_crc(data: bytes) -> bytes:
    crc = 0xffff
    for a in data:
        idx = crc16_table[(crc ^ a) & 0xff]
        crc = ((crc >> 8) & 0xff) ^ idx

    return crc.to_bytes(2, 'little')


class C9Errors:
    # Error sources:
    MAIN_COG = 0
    IO_COG = 1
    AXIS_NETWORK_COG = 2
    C9_NETWORK_COG = 3
    MOTION_COG = 4
    AUX_COM_COG = 5
    SEQUENCE_COG = 6
    DEBUG_COG = 7

    # Error types:
    SUCCESS = 0
    ERROR_AXIS_NO_RESPONSE = 1
    ERROR_AXIS_BUFFER_OVERFLOW = 2
    ERROR_AXIS_BAD_CRC = 3
    ERROR_C9_BUFFER_OVERFLOW = 4
    ERROR_C9_BAD_CRC = 5
    ERROR_C9_BAD_PARSE = 6
    ERROR_NO_COG = 7
    ERROR_HARD_STOP = 8
    ERROR_SOFT_STOP = 9
    ERROR_PUMP_NO_RESPONSE = 10
    ERROR_PUMP_BAD_RESPONSE = 11
    ERROR_PUMP_BUFFER_OVERFLOW = 12
    ERROR_SCALE_NO_RESPONSE = 13
    ERROR_SCALE_BUFFER_OVERFLOW = 14
    ERROR_SCALE_MESSAGE_FAILED = 15
    ERROR_SCALE_BAD_PARSE = 16
    ERROR_SCALE_OVERLOAD = 17
    ERROR_BARCODE_NO_RESPONSE = 18
    ERROR_BARCODE_BUFFER_OVERFLOW = 19
    ERROR_AXIS_TYPE = 20
    ERROR_MOTOR_FAULT = 21
    ERROR_CAPPING_UNDER_TORQUE = 22
    ERROR_HOME_REQUIRED = 23

    def __init__(self, src, e):
        self.source = src
        self.error = e

    def __str__(self):

        if self.source == self.MAIN_COG:
            e_str = "Main: "
        elif self.source == self.IO_COG:
            e_str = "IO: "
        elif self.source == self.AXIS_NETWORK_COG:
            e_str = "Axis Network: "
        elif self.source == self.C9_NETWORK_COG:
            e_str = "C9 Network: "
        elif self.source == self.MOTION_COG:
            e_str = "Motion: "
        elif self.source == self.AUX_COM_COG:
            e_str = "Aux COM: "
        elif self.source == self.SEQUENCE_COG:
            e_str = "Sequence: "
        else:
            e_str = "Unknown Source: "

        if self.error == self.SUCCESS:
            e_str += "Success"
        elif self.error == self.ERROR_AXIS_NO_RESPONSE:
            e_str += "AXIS ERROR: Response timeout"
        elif self.error == self.ERROR_AXIS_BUFFER_OVERFLOW:
            e_str += "AXIS ERROR: Response buffer overflow"
        elif self.error == self.ERROR_AXIS_BAD_CRC:
            e_str += "AXIS ERROR: Bad CRC"
        elif self.error == self.ERROR_C9_BUFFER_OVERFLOW:
            e_str += "C9 ERROR: Request buffer overflow"
        elif self.error == self.ERROR_C9_BAD_CRC:
            e_str += "C9 ERROR: Bad CRC"
        elif self.error == self.ERROR_C9_BAD_PARSE:
            e_str += "C9 ERROR: Failed to parse request"
        elif self.error == self.ERROR_NO_COG:
            e_str += "PROPELLER ERROR: No cog available to start process"
        elif self.error == self.ERROR_HARD_STOP:
            e_str += "SYSTEM ERROR: Hard E-Stop triggered, restart the system when it is safe to do so"
        elif self.error == self.ERROR_SOFT_STOP:
            e_str += "SYSTEM ERROR: Soft E-Stop triggered, clear the fault to resume operation"
        elif self.error == self.ERROR_PUMP_NO_RESPONSE:
            e_str += "PUMP ERROR: Response timeout"
        elif self.error == self.ERROR_PUMP_BAD_RESPONSE:
            e_str += "PUMP ERROR: Failed to parse response"
        elif self.error == self.ERROR_PUMP_BUFFER_OVERFLOW:
            e_str += "PUMP ERROR: Response buffer overflow"
        elif self.error == self.ERROR_SCALE_NO_RESPONSE:
            e_str += "SCALE ERROR: Response timeout"
        elif self.error == self.ERROR_SCALE_BUFFER_OVERFLOW:
            e_str += "SCALE ERROR: Response buffer overflow"
        elif self.error == self.ERROR_SCALE_MESSAGE_FAILED:
            e_str += "SCALE ERROR: Scale received invalid message"
        elif self.error == self.ERROR_SCALE_BAD_PARSE:
            e_str += "SCALE ERROR: Failed to parse response"
        elif self.error == self.ERROR_SCALE_OVERLOAD:
            e_str += "SCALE ERROR: Overload condition"
        elif self.error == self.ERROR_BARCODE_NO_RESPONSE:
            e_str += "BARCODE ERROR: Response timeout"
        elif self.error == self.ERROR_BARCODE_BUFFER_OVERFLOW:
            e_str += "BARCODE ERROR: Response buffer overflow"
        elif self.error == self.ERROR_AXIS_TYPE:
            e_str += "AXIS TYPE ERROR: At least one of the specified axes do not support the requested command"
        elif self.error == self.ERROR_MOTOR_FAULT:
            e_str += "MOTOR FAULT: A critical error has occured on a motor driver, restart the controller"
        elif self.error == self.ERROR_CAPPING_UNDER_TORQUE:
            e_str += "CAPPING FAULT: Torque threshold not reached"
        elif self.error == self.ERROR_HOME_REQUIRED:
            e_str += "HOME REQUIRED: Home the axis before moving"
        else:
            e_str += "UNKNOWN ERROR"

        return e_str