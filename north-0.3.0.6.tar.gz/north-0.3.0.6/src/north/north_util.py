"""
Contains utilities which are used in north and northIDE packages.
Also contains a definition for `VideoUtils` which is heavily used by the NorthIDE vision sources as well as n9_cam.py
"""


from tkinter import ttk

import logging
from datetime import date, datetime
from colorsys import rgb_to_hsv


def clamp(value, floor, ceil):
    """
    Parameters
    ----------
    value: float
        The value to be clamped.
    floor: float
        The minimal allowed value.
    ceil: float
        The maximal allowed value.

    Returns
    -------
    float
        Value clamped to range [floor, ceil]
    """
    return min(max(value, floor), ceil)


def next_pow_2(num):
    """ If num isn't a power of 2, will return the next higher power of two """
    rval = 1
    while rval < num:
        rval <<= 1
    return rval


def parse_range_str(input):
    if input is None:
        return

    if input == 'None' or input == 'null':
        return

    range_list = []
    input = input.replace(' ', '')
    terms = input.split(',')
    for term in terms:
        try:
            range_list.append(int(term))
        except Exception:
            sub_terms = term.split('-')
            range_list += range(int(sub_terms[0]), int(sub_terms[1]) + 1)
    return set(range_list)


def make_file(fp):
    """
    Creates a file at a given path.

    Parameters
    ----------
    fp: Path
        Filepath to be created.
    """
    f = open(fp, 'w')
    f.close()


def shell_print(to_write):
    """
    Prints a message to the Thonny shell at error-level.

    Parameters
    ----------
    to_write: str
        Message to write to Thonny console.
    """
    try:
        from thonny import get_shell
    except ModuleNotFoundError:
        print(to_write)
        return

    try:
        get_shell().print_not_error(str(to_write))
        # move to new shell line after error msg
        get_shell().submit_magic_command("")
    except AttributeError:  # in case get_shell() returns NoneType
        pass


def get_current_timestamp():
    """
    Gets a string representation of current date and time.

    Returns
    -------
    str
        Current datetime, formatted as '{date}_{hour}-{minute}-{second}'
    """
    return '{0}_{1}-{2}-{3}'.format(
        date.today(),
        datetime.now().hour,
        datetime.now().minute,
        datetime.now().second
    )

def space_to_mm(value: float):
    """ Convert a value from OpenGL space to real-world mesaurement (mm) """
    return value * 1000.0

def mm_to_space(value: float):
    """ Convert a value from real-world mesaurement (mm) to OpenGL space """
    return value * 0.001


import cv2 as cv
import numpy as np
from PIL import Image
from PIL import ImageTk


class VideoUtils:
    """
    Video utilities. Helper functions for working with vision sources or OpenCV.
    """

    STREAM_FPS = 12
    FILTERS = {
        'None': {},
        'Edges': {},
        'Binarized': {},
        'Adapt.Thresh': {},
        'Lines': {
            # identifier: (Name, default)
            'threshold': ('Threshold', 'int', 15),
            'minLineLength': ('Min. Line Length', 'int', 10),
            'maxLineGap': ('Max. Line Gap', 'int', 20)
        },
        'Colors': {
            'numColors': ('Number of Colors', 'int', 5)
        },
        'Top Color': {},
        'Color Range': {
            'color_a': ('Color A', 'color', [0, 0, 0]),
            'color_b': ('Color B', 'color', [255, 255, 255]),
            'showMask': ('Show Mask', 'toggle', False)
        },
        'Avg. Color': {}
    }
    """
    Dictionary of name (str): settings {dict} pairs. Settings dicts look like {setting name (str): default value (Any)}
    """

    @staticmethod
    def get_ms_frame_delay(target_fps: int):
        """ Convert an FPS to the millisecond delay between frames necessary to produce that FPS """
        return int((1.0 / target_fps) * 1000)

    @staticmethod
    def fourcc():
        return cv.VideoWriter_fourcc(*'MJPG')  # TODO use a better codec!!!

    @staticmethod
    def list_vid_ports():
        """
        Get list of available cameras.

        See Also: https://stackoverflow.com/questions/57577445/list-available-cameras-opencv-python

        Returns
        -------
        List[int]
            List of camera ports.
        """
        ports = []
        index = 0
        while True:
            cam = cv.VideoCapture(index)
            if not cam.isOpened():  # break the loop on first non-cam port
                break
            else:
                ports.append(index)
            index += 1
        return ports

    @staticmethod
    def get_source_list():
        """ Unused and deprecated """
        return ['None', 'Image'] + [f"Camera {i}" for i in VideoUtils.list_vid_ports()]

    @staticmethod
    def filter_names():
        """ Lists the names of all available filters. """
        return list(VideoUtils.FILTERS.keys())

    @staticmethod
    def filter_settings(filter_name):
        """
        Get a dictionary of all settings of a given filter.

        Parameters
        ----------
        filter_name: str
            Name of the filter to get the settings of.

        Returns
        -------
        dict
            {setting name (str): default value (Any), }
        """
        return VideoUtils.FILTERS[filter_name]

    @staticmethod
    def filter_setting_default(filter_name, setting_name):
        """
        Get default setting value for a given filter setting.

        Parameters
        ----------
        filter_name: str
            Name of the filter which the setting is for.
        setting_name: str
            The setting to get the default value of.

        Returns
        -------
        Any
            Default value for the given setting.
        """
        return VideoUtils.FILTERS[filter_name][setting_name][2]

    @staticmethod
    def get_output_frame(flt, src):
        """
        Runs a source image through a filter specified through a dictionary, and returns the filtered image.

        Parameters
        ----------
        flt: dict
            Should contain a key pair 'filter': filter name (str), as well as any parameters for that filter (see:
            `VideoUtils.FILTERS` for more).
        src: np.ndarray
            Source image.

        Returns
        -------
        np.ndarray
            Filtered image in numpy array format.
        """
        assert isinstance(flt, dict)
        assert isinstance(src, np.ndarray)
        filter_name = flt['filter']
        if filter_name == 'None':
            return src
        else:  # must apply some filter
            try:
                if filter_name == 'Edges':
                    gray = cv.cvtColor(src, cv.COLOR_BGR2GRAY)
                    edged = cv.Canny(gray, 50, 100)
                    return cv.cvtColor(edged, cv.COLOR_GRAY2RGB)
                elif filter_name == 'Binarized':
                    gray = cv.cvtColor(src, cv.COLOR_BGR2GRAY)
                    _, binned = cv.threshold(gray, 127, 255, cv.THRESH_BINARY)
                    return cv.cvtColor(binned, cv.COLOR_GRAY2RGB)
                elif filter_name == 'Adapt.Thresh':
                    gray = cv.cvtColor(src, cv.COLOR_BGR2GRAY)
                    threshed = cv.adaptiveThreshold(gray, 255,
                                                    cv.ADAPTIVE_THRESH_MEAN_C,
                                                    cv.THRESH_BINARY, 11, 2)
                    return cv.cvtColor(threshed, cv.COLOR_GRAY2RGB)
                elif filter_name == 'Lines':
                    gray = cv.cvtColor(src, cv.COLOR_BGR2GRAY)
                    # blurred = cv.GaussianBlur(gray, ksize=(5, 5), sigmaX=0)
                    # _, binned = cv.threshold(gray, 127, 255, cv.THRESH_BINARY)
                    edged = cv.Canny(gray, 50, 200)
                    lines = cv.HoughLinesP(edged, rho=1, theta=np.pi / 180,
                                           threshold=flt["threshold"],
                                           minLineLength=flt["minLineLength"],
                                           maxLineGap=flt["maxLineGap"])
                    if isinstance(lines, np.ndarray):
                        lined = np.copy(src)
                        for line in lines:
                            x1, y1, x2, y2 = line[0]
                            cv.line(lined, (x1, y1), (x2, y2), (0, 0, 255), 1)
                        return lined
                    else:  # lines will be None if none are detected (wish it were just empty array...)
                        return src
                elif filter_name == 'Colors':
                    # determine dominant colors
                    pix = np.float32(src.reshape(-1, 3))  # flatten 2D to 1D array (of triples)
                    n_colors = flt['numColors']
                    criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 200, 0.1)
                    flags = cv.KMEANS_RANDOM_CENTERS
                    _, labels, palette = cv.kmeans(pix, n_colors, None, criteria, 10, flags)
                    _, counts = np.unique(labels, return_counts=True)
                    # construct representation of dominant colors
                    indices = np.argsort(counts)[::-1]
                    freqs = np.cumsum(np.hstack(
                        [[0], counts[indices] / float(counts.sum())]
                    ))
                    rows = np.int_(src.shape[0] * freqs)
                    dominant_img = np.zeros(shape=src.shape, dtype=np.uint8)
                    for i in range(len(rows) - 1):
                        dominant_img[rows[i]:rows[i + 1], :, :] += np.uint8(palette[indices[i]])
                    return dominant_img
                elif filter_name == 'Top Color':
                    pix = np.float32(src.reshape(-1, 3))  # flatten 2D to 1D array (of triples)
                    criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 200, 0.1)
                    flags = cv.KMEANS_RANDOM_CENTERS
                    _, labels, palette = cv.kmeans(pix, 1, None, criteria, 10, flags)
                    _, counts = np.unique(labels, return_counts=True)
                    indices = np.argsort(counts)[::-1]
                    top_color = np.uint8(palette[indices[0]])
                    return np.tile(top_color, reps=(src.shape[0], src.shape[1], 1))  # returns a monochromatic image
                elif filter_name == 'Color Range':
                    for param in ('color_a', 'color_b', 'showMask'):
                        flt.setdefault(param, VideoUtils.filter_setting_default(filter_name, param))
                    alpha = flt['color_a']
                    beta = flt['color_b']
                    assert len(alpha) == 3
                    assert len(beta) == 3
                    min_values = np.asarray(list(map(min, zip(alpha, beta))))
                    max_values = np.asarray(list(map(max, zip(alpha, beta))))
                    assert len(min_values) == 3
                    assert len(max_values) == 3
                    src_hsv = cv.cvtColor(src, cv.COLOR_RGB2HSV)
                    masked = cv.inRange(src_hsv, min_values, max_values)
                    if flt['showMask']:
                        return cv.cvtColor(masked, cv.COLOR_GRAY2RGB)
                    else:
                        return cv.bitwise_and(src, src, mask=masked)
                elif filter_name == 'Avg. Color':
                    avg = np.array(src.mean(axis=0).mean(axis=0), dtype=np.uint8)  # array looks like [B, G, R]
                    return np.tile(avg, reps=(src.shape[0], src.shape[1], 1))  # returns a monochromatic image
                else:
                    raise ValueError(f"Unrecognized filter: {filter_name}")
            except cv.error as e:
                logging.error(f'encountered openCV error:')
                logging.exception(e)

    @staticmethod
    def np_img_to_tk(src):
        """
        Convert Numpy image to Tkinter image.

        Parameters
        ----------
        src: np.ndarray
            Source image (numpy array)

        Returns
        -------
        np.ndarray
            Converted Tkinter image (or None if there was an error).
        """
        try:
            return ImageTk.PhotoImage(Image.fromarray(cv.cvtColor(src, cv.COLOR_BGR2RGB)))
        except cv.error:
            return None

    @staticmethod
    def rgb_to_hsv(values):
        """TODO"""
        return values
