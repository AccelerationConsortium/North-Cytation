from bisect import bisect
from typing import Any
from sys import getsizeof

class SparseList:
    """
    A sparse list is a compact way to store a timeseries that is has many repeating values
    """
    def __init__(self, init_val: Any=None):
        self._vals = [init_val] if init_val is not None else []  # values list
        self._inds = [1] if init_val is not None else []  # indices list

    def __repr__(self):
        return f"SparseList with {len(self)} elements"

    def __sizeof__(self):
        return sum([getsizeof(val) for val in self._vals]) + getsizeof(self._inds)

    def as_list(self):
        # TODO: consider making this return an iterable
        return [self.at(i) for i in range(len(self))]

    @property
    def compressed_len(self):
        return len(self._inds)

    @property
    def last_value(self):
        """
        :return: the last value in the SparseList
        """

        return self._vals[-1][-1] if isinstance(self._vals[-1], list) else self._vals[-1]

    def __len__(self):
        return self._inds[-1] if len(self._inds) > 0 else 0

    def append(self, value: Any, n: int=1):
        """
        append a value to the SparseList (which may repeat n times)
        :param value: the value to append
        :param n: the number of times to insert the value
        """

        assert isinstance(n, int)
        assert n >= 1

        # populate first items in SparseList
        if self.compressed_len == 0:
            self._vals.append(value)
            self._inds.append(n)
            return

        # check if value can be combined with previous entry
        if value == self._vals[-1]:
            self._inds[-1] += n
        else:
            self._vals.append(value)
            self._inds.append(self._inds[-1] + n)

    def append_list(self, l: list):
        """
        add a list of values to the SparseList
        :param l: the list to append
        """
        assert isinstance(l, list)

        self._vals.append(l)

        if self.compressed_len == 0:
            self._inds.append(len(l))
        else:
            self._inds.append(self._inds[-1] + len(l))

    def at(self, i: int):
        """
        access the value at index i of SparseList, if i is larger than the list, return the last value
        TODO: support __getitem__ and slicing
        :param i: the index from which to return the value
        :return: the value at index i
        """

        # commented since we want lookups to be as fast as possible
        # assert isinstance(i, int)

        if i >= len(self):
            return self.last_value

        j = bisect(self._inds, i)  # the value is at this index in self._vals, but might be contained in another sublist

        if not isinstance(self._vals[j], list):
            return self._vals[j]
        prev_ind = self._inds[j-1] if self.compressed_len > 1 else 0
        return self._vals[j][i - prev_ind]

    def prune(self, i):
        """
        delete all entries after i
        :param i: the index after which to delete all entries
        """

        assert isinstance(i, int)
        assert i < len(self)

        j = bisect(self._inds, i)

        self._inds[j] = i+1

        del self._inds[j+1:]
        del self._vals[j+1:]
        if isinstance(self._vals[j], list):
            prev_ind = self._inds[j - 1] if self.compressed_len > 1 else 0
            del self._vals[j][(i - prev_ind + 1):]


    def pad_to_len(self, l: int):
        """
        Extend the current end value to so that the SparseList has len l. Example: Given SparseList(1,2,3), calling
        pad_to_len(5) would yield SparseList(1,2,3,3,3). Cannot be called on a empty SparseList.

        :param l: The length to which to extend the sparselist, must be greater than len(self)
        """

        assert l > len(self)
        assert len(self) > 0
        self.append(self.last_value, l - len(self))

