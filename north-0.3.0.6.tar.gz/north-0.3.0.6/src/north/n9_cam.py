"""
Provides a user-facing interface for camera server updates.
`NorthCamera` provides a wrapper for a given camera and can be used to get periodical captures, filter images from the
feed, display or save a current snapshot, etc.
"""

from north.north_project import Project
from north.n9_server import send_cmd
from north.north_util import VideoUtils, get_current_timestamp
from north.north_UVC import UVCControl
from north.vision_sources import CameraSource, FilterSource, ImageSource, _VisionSource, VirtualCameraSource

import logging
import struct
import mmap
import threading
import os
import numpy as np
import cv2

from typing import Callable, Union, Optional
from PIL import Image, ImageTk
from pathlib import Path
from time import sleep
from queue import Queue


class NorthCamera:
    __RECORDING_FPS = 20.0
    __RECORDING_WAIT = 1.0 / __RECORDING_FPS

    def __init__(self, source=None, cam=None, blackbox=0):
        """
        Wraps a camera feed, specified from project through `source` name, or as a camera number `cam`.

        Parameters
        ----------
        source: str
            Identifier for project vision source. If left as None, 'cam' must be specified.
        cam: int
            Camera number (only used if `source` == None)
        blackbox: int
            Number of seconds to record black-box (if blackbox <= 0, no blackbox is recorded)
        """
        assert isinstance(blackbox, int)
        if not isinstance(source, str) and not isinstance(cam, int):
            raise ValueError("Must specify either source (str) or cam (int) to initialize a NorthCamera.")

        # TODO get project path when not in IDE
        self._proj_path = Path(os.getcwd())
        self._project = Project(self._proj_path)

        self._settings = None
        self._source_id = None
        self._cam_id = None

        if source is not None:
            assert isinstance(source, str)
            self._source_id = source
            self._source = self._project.get_vision_source(source)
            if isinstance(self._source, VirtualCameraSource):
                raise TypeError(f'Cannot use a VirtualCameraSource as a NorthCamera source.')
            self._cam_id = self._source.cam if isinstance(self._source, CameraSource) else None
        else:  # TODO should we just create a camerasource? we could then use that for blackbox...
            assert isinstance(cam, int)
            self._cam_id = cam
            self._source_id = self._source = None

        # blackbox == # seconds to record back
        self._blackbox_frames: Optional[Queue] = Queue(blackbox * int(self.__RECORDING_FPS)) if blackbox > 0 else None
        self._blackbox_thread = threading.Thread(target=self._blackbox, daemon=True)

        self._recording = False
        self._recording_output = None
        self._recording_thread = threading.Thread(target=self._record, daemon=True)

        self._killsignal = False

        if isinstance(self._cam_id, int):
            # register the camera feed with video provider
            from north.n9_server import launch_north_server
            launch_north_server()  # creates data broker iff it doesn't exist
            register_cam(self._cam_id)

        if self.use_blackbox:
            self._blackbox_thread.start()

    def __del__(self):
        self._killsignal = True
        if self.use_blackbox:
            self._blackbox_thread.join()
            del self._blackbox_frames
            self._blackbox_frames = None
        if self._recording:
            self.end_recording()
        # unregister the camera feed
        unregister_cam(self._cam_id)

    @property
    def use_blackbox(self):
        return isinstance(self._blackbox_frames, Queue)

    def capture(self):
        """
        Gets the most recently captured image from the camera.

        Returns
        -------
        np.ndarray
            The most recently captured image on the source camera.
        """
        if isinstance(self._source, _VisionSource):
            if not self._source.active:
                self._source.register()
            src_frame = self._source.get_frame(apply_crop=True)
        else:
            assert isinstance(self._cam_id, int)
            try:
                headsize = struct.calcsize('ii')
                imgsize = 0
                shape = (0, 0, 3)
                # while camera is booting up the image size will be zero
                while imgsize == 0:
                    head = mmap.mmap(-1, headsize, f"CAMERAFEED-{self._cam_id}")
                    head.seek(0)
                    w, h = struct.unpack('ii', head.read(headsize))
                    head.close()
                    shape = (h, w, 3)
                    imgsize = np.prod(shape)
                    if imgsize == 0:  # don't poll too often..
                        sleep(0.01)
                # we have ensured camera is up, now..
                # get the current image from mmap
                mm = mmap.mmap(-1, headsize + imgsize, f"CAMERAFEED-{self._cam_id}")
                mm.seek(headsize)
                buf = mm.read(imgsize)
                src_frame = np.frombuffer(buf, dtype=np.uint8).reshape(shape)
                mm.close()
                if isinstance(self._project, Project):
                    pass  # TODO switch to source-based crop...
                    # if self._config_id is not None:
                    #     settings = Project(self._proj_path).get_visioncfg(self._config_id)['settings']
                    #     if settings is not None and settings['crop']['enabled']:
                    #         crop_set = settings['crop']
                    #         # numpy arrays are height-first and width-second
                    #         cropped = src_frame[
                    #                   crop_set['start_y']:crop_set['end_y'],
                    #                   crop_set['start_x']:crop_set['end_x']
                    #                   ]
                    #         if cropped.shape[0] < 1 or cropped.shape[1] < 1:  # empty crop
                    #             logging.warning("Cropping settings resulted in empty crop. Capturing full image.")
                    #             return src_frame
                    #         else:
                    #             return cropped
                    # if no config or no crop, just return now
            except Exception as e:
                logging.error("Error in NorthCamera.capture():")
                logging.exception(e)
                return None
        return src_frame

    def filter(self, image=None, func=None, **kwargs):
        """
        Perform a filtering operation.
        If no image is supplied, gets the most recent image from capture().
        If no func is supplied, will attempt to use pane which is outdated! TODO

        Parameters
        ----------
        image: np.ndarray, optional
            The image to filter. If None, will get most recent image from `capture()`.
        func: Callable, optional
            A filtering function which takes an image as input and returns an image as output.

        Returns
        -------
        np.ndarray
            The filtered image.
        """
        if not isinstance(image, np.ndarray):
            image = self.capture()
        if isinstance(func, Callable):
            output = func(image, **kwargs)
            if isinstance(output, np.ndarray):
                return output
            else:
                logging.error(f'filter(): Supplied function must return numpy ndarray')
                logging.error('filter(): Returning unprocessed image...')
                return image
        else:  # TODO the code below is all broken!!
            if not isinstance(pane, int):
                if self._pane_id is not None:
                    pane = self._pane_id
                else:
                    logging.error(f'filter(): Cannot filter without supplied func, cfg_id parameter, or a preset pane.')
                    logging.error('filter(): Returning unprocessed image...')
                    return image
            proj = Project(self._proj_path)
            cfg = proj.get_visioncfg(pane)
            settings = cfg['settings']
            settings['filter'] = cfg['filter']  # TODO this is a hack
            try:
                return VideoUtils.get_output_frame(settings, image)
            except Exception as e:
                logging.error('filter(): Encountered exception during filtering:')
                logging.exception(e)
                logging.error('filter(): Returning unprocessed image...')
                return image

    def save(self, image, filename=None):
        """
        Saves a given image (a numpy array) to project captures directory.
        If filename is not set, will be named according to the time it was captured.

        Parameters
        ----------
        image: np.ndarray
            The image to save.
        filename: str, optional
            Custom name for saved file. Will be named as 'capture_[current time]' otherwise.
        Returns
        -------
        Path
            Filepath of the saved image.
        """
        if not filename:
            filename = f'capture_{get_current_timestamp()}'
        return save_capture(image, filename, proj_path=self._proj_path)

    def display(self):
        """ Displays the most recent captured image using `capture()` and `show_image()` """
        show_image(self.capture())

    def start_recording(self, capture_name='output'):
        """
        Begin recording an .avi file to project captures directory

        Parameters
        ----------
        capture_name: str
            File will be saved as `capture_name`.avi
        """
        fourcc = cv2.VideoWriter_fourcc(*'MJPG')  # TODO! better codec!
        initialcapture = self.capture()
        shape = tuple(reversed(initialcapture.shape[:2]))
        print(f'Shape: {shape}')
        self._recording_output = cv2.VideoWriter(f'captures\\{capture_name}.avi', fourcc, self.__RECORDING_FPS, shape)
        self._recording_output.write(initialcapture)
        self._recording = True
        self._recording_thread.start()

    def _record(self):
        while self._recording:
            self._recording_output.write(self.capture())   # should be BGR I think??
            sleep(self.__RECORDING_WAIT)

    def end_recording(self):
        """ Ends a recording which was started with `start_recording()` """
        self._recording = False
        self._recording_thread.join()
        self._recording_output.release()

    def _blackbox(self):
        while not self._killsignal:
            assert self.use_blackbox
            # if queue is full, empty up a spot at the "start" (oldest frame)
            if self._blackbox_frames.full():
                self._blackbox_frames.get()
            self._blackbox_frames.put(self.capture())
            sleep(self.__RECORDING_WAIT)

    def dump_blackbox(self):
        """ Writes an .avi file of last-N-seconds blackbox recording to project captures directory """
        if self._blackbox_frames.empty():
            print(f'Cannot dump empty black-box feed.')
            return

        blackbox = list(self._blackbox_frames.queue)  # create a "frozen" copy for us to dump
        shape = tuple(reversed(blackbox[0].shape[:2]))
        blackbox_file = f'captures\\blackbox_{get_current_timestamp()}.avi'
        blackbox_output = cv2.VideoWriter(blackbox_file, VideoUtils.fourcc(), self.__RECORDING_FPS, shape)

        for frame in blackbox:
            blackbox_output.write(frame)
        blackbox_output.release()


# functions
def register_cam(cam_id, verbose=False):
    """
    Registers a camera feed for memory-map updates.

    Parameters
    ----------
    cam_id: int
        Camera number to register.
    verbose: bool
        If True, will log and print progress and error messages.

    Returns
    -------
    success: bool
        True if registration was successful.
    registrations: int, optional
        The number of registrations which have been made for `cam_id` (after success)
    """
    assert isinstance(cam_id, int)
    assert isinstance(verbose, bool)
    if verbose:
        msg = f'register_cam(): Registering camera feed {cam_id}...';
        print(msg);
        logging.info(msg)
    retcode, retdata = send_cmd(b'VREG', data=struct.pack('i', cam_id))
    if retcode == b'DATA':
        registrations, = struct.unpack('i', retdata)
        return True, registrations
    else:
        if verbose:
            logging.error(f'register_cam(): Registering camera feed {cam_id} failed ({retcode}): {retdata}.')
        return False, None


def unregister_cam(cam_id, verbose=False) -> bool:
    """
    Unregisters a camera feed from memory-map updates.

    Parameters
    ----------
    cam_id: int
        Camera number to un-register.
    verbose: bool
        If True, will log and print progress and error messages.

    Returns
    -------
    success: bool
        True if un-registration was successful.
    registrations: int, optional
        The number of registrations which have been made for `cam_id` (after success)
    """
    assert isinstance(cam_id, int)
    assert isinstance(verbose, bool)
    if verbose:
        msg = f'unregister_cam(): Unregistering camera feed {cam_id}...';
        print(msg);
        logging.info(msg)
    retcode, retdata = send_cmd(b'VUNR', data=struct.pack('i', cam_id), verbose=verbose)
    if retcode == b'DATA':
        registrations, = struct.unpack('i', retdata)
        return True, registrations
    else:
        if verbose:
            logging.error(f'unregister_cam(): Unregistering camera feed {cam_id} failed: {retcode}, {retdata}.')
        return False, None


def get_cam_control(cam_id, ctrl_id) -> tuple:
    """
    Get the current UVC settings of the specified camera.

    Parameters
    ----------
    cam_id: int
        Camera number to get settings for.
    ctrl_id: int
        OpenCV constant ID for the desired setting.
        See `UVCControl.UVC_CONTROLS`

    Returns
    -------
    ctrl_values: tuple
        See `UVCControl.names`
    """
    assert isinstance(cam_id, int)
    assert isinstance(ctrl_id, int)
    ctrl_name = UVCControl.UVC_CONTROLS[ctrl_id]
    retcode, retdata = send_cmd(b'VGET', data=struct.pack('ii', cam_id, ctrl_id))
    if retcode != b'DATA':
        if retdata == b'BADCTRL':
            logging.warning(f'get_cam_control():'
                            f'Failed because ({ctrl_id}){ctrl_name} is not a valid control for cam {cam_id}')
        else:
            logging.error(f'get_cam_control(): '
                          f'Get cam {cam_id} ({ctrl_id}){ctrl_name} controls failed: {retcode}, {retdata}.')
        return None
    return struct.unpack(f'{len(UVCControl.names)}i', retdata)


def set_cam_control(cam_id, ctrl_id, value):
    """
    Sets the given UVC setting of the specified camera to a given value.

    Parameters
    ----------
    cam_id: int
        Camera number to set value on.
    ctrl_id: int
        OpenCV constant ID for the desired setting.
        See `UVCControl.UVC_CONTROLS`
    value: int
        The new value for `ctrl_id` on `cam_id`

    Returns
    -------
    bool
        True if setting camera value was successful.
    """
    assert isinstance(cam_id, int)
    assert isinstance(ctrl_id, int)
    assert isinstance(value, int)
    retcode, retdata = send_cmd(b'VSET', data=struct.pack('iii', cam_id, ctrl_id, value))
    if retcode != b'OKAY':
        logging.warning(f'set_cam_control(): '
                        f'Setting camera {cam_id} controls failed: {retcode}, {retdata}.')
        return False
    return True


def set_cam_auto(cam_id, ctrl_id, auto=True):
    """
    Sets the 'auto' setting on given camera setting.
    If `auto`=True, other settings are determined by camera firmware automatically.
    If `auto`=False, other settings can be user-set through `set_cam_control()`

    Parameters
    ----------
    cam_id: int
        Camera number to set `auto` on.
    ctrl_id: int
        OpenCV constant ID for the desired setting.
        See `UVCControl.UVC_CONTROLS`
    auto: bool
        If True, the desired setting will have its values determined automatically.

    Returns
    -------
    ctrl_values: tuple
        See `UVCControl.names`
    """
    assert isinstance(cam_id, int)
    assert isinstance(ctrl_id, int)
    assert isinstance(auto, bool)
    retcode, retdata = send_cmd(b'VAUT', data=struct.pack('ii?', cam_id, ctrl_id, auto))
    if retcode != b'DATA':
        logging.error(f'set_cam_auto(): '
                      f'Setting camera {cam_id} auto failed: {retcode}, {retdata}.')
        return None
    return struct.unpack(f'{len(UVCControl.names)}i', retdata)


def get_captures_path(proj_path=None) -> Path:
    """
    Returns the filepath to a captures directory, given a project folder path.

    Parameters
    ----------
    proj_path: Path, optional
        The project folder path.

    Returns
    -------
    Path
        Returns a path looking like `proj_path`/captures
    """
    if proj_path is None:
        # TODO: default to user_data/captures on None proj_path, in case no project open...
        raise NotImplementedError()
    return proj_path.joinpath('captures')


def show_image(image):
    """
    Displays an image using pyplot's `plt.imshow()`

    Parameters
    ----------
    image: np.ndarray
        The image to display.
    """
    from matplotlib import pyplot as plt
    plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    plt.show()


def save_capture(image, filename,
                 proj_path=None,
                 no_duplicates=True,
                 extension='png') -> Path:
    """
    Saves an image as given filename.

    Parameters
    ----------
    image: Union[np.ndarray, ImageTk.PhotoImage]
        The image to save.
    filename: str
        Name for the file. Should not include the `extension` in the filename.
    proj_path: Path, optional
        Path to the project. If not set, will probably produce an error!!!! TODO get the proj_path automatically?
    no_duplicates: bool
        If True, and given filename exists, will save as {filename}_# where # is an index of similarly named files.
    extension: str
        Can specify a different file format to save as.

    Returns
    -------
    filepath: Path
        Filepath of the saved capture, or None if not successfully saved
    """
    assert type(image) in [np.ndarray, ImageTk.PhotoImage]
    if proj_path is None:
        proj_path = Path(os.getcwd())
    # ensure captures directory exists
    if not Path.exists(get_captures_path(proj_path)):
        Path.mkdir(get_captures_path(proj_path))

    filepath = get_captures_path(proj_path).joinpath(f'{filename}.{extension}')

    if no_duplicates:
        i = 2
        while Path.exists(filepath):
            filepath = get_captures_path(proj_path).joinpath(f'{filename}_{i}.{extension}')
            i += 1
    else:
        raise NotImplementedError("TODO: save_capture when no_duplicates == False")

    # save the capture
    if isinstance(image, np.ndarray):
        # cv images are BGR, PIL images are RGB
        img_pil = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    else:
        assert isinstance(image, ImageTk.PhotoImage)
        img_pil = ImageTk.getimage(image)
    img_pil.save(filepath, format=extension)

    print(f'Saved capture: {filepath}')
    logging.info(f'Saved capture: {filepath}')
    return filepath
