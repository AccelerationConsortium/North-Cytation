""" Provides helper functions for accessing various locations within the NorthIDE software """

import inspect
import shutil
import os

from pathlib import Path


def get_base_path() -> Path:
    """ ~/NorthIDE/ """
    return Path(inspect.stack()[0][1]).parents[3]


def get_user_data_path() -> Path:
    """ ~/NorthIDE/user_data/ """
    return get_base_path().joinpath('user_data')


def get_northIDE_pkg_path() -> Path:
    """ ~/NorthIDE/Lib/site-packages/northIDE/ """
    return get_base_path().joinpath('Lib\\site-packages\\northIDE')


def get_base_res_path() -> Path:
    """ ~/NorthIDE/Lib/site-packages/northIDE/res/ """
    return get_northIDE_pkg_path().joinpath('res')


def get_default_proj_path() -> Path:
    """ ~/NorthIDE/Lib/site-packages/northIDE/default_proj.nproj """
    return get_northIDE_pkg_path().joinpath('default_proj.nproj')


def get_north_res_path() -> Path:
    """ ~/res/north/ """
    return get_base_res_path().joinpath('north')


def get_user_res_path() -> Path:
    """ ~/res/user/ """
    return get_base_res_path().joinpath('user')


def get_fonts_path() -> Path:
    """ ~/res/north/fonts/ """
    return get_north_res_path().joinpath('fonts')


def get_north_modules_path() -> Path:
    """ ~/res/north/modules/ """
    return get_north_res_path().joinpath('modules')


def get_n9_path() -> Path:
    """ ~/res/north/modules/n9/ """
    return get_north_modules_path().joinpath('n9')


def get_pump_path() -> Path:
    """ ~/res/north/modules/pump/ """
    return get_north_modules_path().joinpath('pump')


def get_north_moveables_path() -> Path:
    """ ~/res/north/moveables/ """
    return get_north_res_path().joinpath('moveables')


def get_proj_res_path() -> Path:
    """
    Get base project resource directory.

    Returns
    -------
    Path
        Resource directory for the project currently open in the NorthIDE
    """
    from northIDE import MVC
    return Path(MVC.project().current_proj.res_dir)


def get_proj_modules_path() -> Path:
    """
    Get project module resource directory.

    Returns
    -------
    Path
        Module resource directory for the project currently open in the NorthIDE
    """
    from northIDE import MVC
    return Path(MVC.project().current_proj.modules_dir)


def get_proj_moveables_path() -> Path:
    """
    Get project moveable resource directory.

    Returns
    -------
    Path
        Moveable resource directory for the project currently open in the NorthIDE
    """
    from northIDE import MVC
    return Path(MVC.project().current_proj.moveables_dir)


def copy_resource(res_path: Path, dest: Path, overwrite=False):
    """
    Copies all files from folder given by `res_path` to folder given by `dest`.

    Parameters
    ----------
    res_path: Path
        Source resource directory.
    dest: Path
        Target resource directory.
    overwrite: bool
        If True, will overwrite any files in `dest` that have the same name.

    Raises
    ------
    FileNotFoundError
        If `res_path` is not a directory.
    """
    if overwrite and Path.exists(dest):
        base_res_path = get_base_res_path()
        # disallows deleting NorthIDE res
        assert os.path.abspath(base_res_path) != os.path.commonpath([dest, base_res_path])
        shutil.rmtree(dest)

    # ensure that the source files actually exist
    if not res_path.is_dir():
        raise FileNotFoundError(f'"{res_path}" does not exist.')
    shutil.copytree(res_path, dest)

    # copy source files to destination (do not overwrite if exists)
    # if not destination.is_file():
    #     shutil.copyfile(obj_src_fp, obj_dst_fp)
    # if not mtl_dst_fp.is_file():
    #     shutil.copyfile(mtl_src_fp, mtl_dst_fp)


def delete_resource(res_path: Path, project_dir: Path):
    """
    Deletes all files from folder given by `res_path` which must be a sub-folder of `project_dir`.

    Parameters
    ----------
    res_path: Path
        Resource directory to delete.
    project_dir: Path
        Project directory. Must be a parent (or grand-parent) directory of `res_path`.

    Raises
    ------
    RuntimeError
        If `res_path` is not within project directory.
    """
    if not res_path.is_dir():
        return

    # don't delete something outside project path
    if os.path.abspath(project_dir) != os.path.commonpath([res_path, project_dir]):
        raise RuntimeError(
            "Project error: Attempted to delete directory " + str(res_path) + "that is not in project path")

    # raise RuntimeError(project_dir.name, list(res_path.parents)) if project_dir.name not in res_path.parents: raise
    # RuntimeError("Project error: Attempted to delete directory " + str(res_path) + "that is not in project path")

    # raise RuntimeError("deleting" + str(res_path))
    shutil.rmtree(res_path)
